/*********************************************************************
  Blosc - Blocked Shuffling and Compression Library

  Copyright (c) 2021  Blosc Development Team <blosc@blosc.org>
  https://blosc.org
  License: BSD 3-Clause (see LICENSE.txt)

  See LICENSE.txt for details about copyright and rights to use.
**********************************************************************/

#if !defined(_WIN32)
// Make flock() and O_CLOEXEC visible despite -D_XOPEN_SOURCE=600 (as in blosc2-stdio.c)
#if !defined(_GNU_SOURCE)
#define _GNU_SOURCE
#endif
#define _DARWIN_C_SOURCE
// The BSDs honour neither of the above.  There, <sys/cdefs.h> derives
// _POSIX_C_SOURCE from _XOPEN_SOURCE and then leaves __BSD_VISIBLE undefined,
// which reads as 0 in the `#if __BSD_VISIBLE` that guards both flock() and the
// LOCK_* constants in <sys/fcntl.h> --- so they stay hidden even though
// <sys/file.h> is included below (see #794).  Dropping _XOPEN_SOURCE for this
// file restores their default environment, which is a superset of what it asks
// for: POSIX 200809 and XSI 700, plus the BSD extensions.  It has to be done per
// file rather than in CMakeLists.txt, because my_malloc() in blosc2.c keys its
// posix_memalign() path off _XOPEN_SOURCE and would fall back to malloc().
#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__) || \
    defined(__DragonFly__)
#undef _XOPEN_SOURCE
#endif
#endif

#include "frame.h"
#include "prefetch.h"
#include "sframe.h"
#include "context.h"
#include "blosc-private.h"
#include "blosc-checked.h"
#include "blosc2.h"

#include <sys/stat.h>
#if defined(_WIN32)
#include <windows.h>
#include <malloc.h>
// See https://github.com/Blosc/python-blosc2/issues/359#issuecomment-2625380236
#define stat _stat64
#else
#include <errno.h>
#include <fcntl.h>
#if defined(__linux__)
#include <sys/sysmacros.h>
#endif
#include <sys/file.h>
#include <sys/resource.h>
#include <unistd.h>
#if !defined(O_CLOEXEC)
#define O_CLOEXEC 0
#endif
#endif  /* _WIN32 */

#include <inttypes.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* If C11 is supported, use it's built-in aligned allocation. */
#if __STDC_VERSION__ >= 201112L
#include <stdalign.h>
#endif


#if !defined(_WIN32)
/* A cached read handle is held for the whole life of its frame, so the process
   pays one descriptor per *open* frame rather than one per in-flight read.  A
   caller that keeps many frames open at once (python-blosc2's ctable indexes
   hold half a dozen arrays each) can walk into EMFILE that way, and on macOS
   the soft limit is 256 by default.  So cache only while under a cap; frames
   past it fall back to the open-per-operation path, which is exactly how this
   worked before the cache existed.  Deliberately not an LRU: evicting means
   closing a handle other threads may be mid-pread on, and this degrades
   instead of breaking. */
/* Ceiling on the cap, and the share of the process's descriptor budget we are
   willing to sit on.  A fixed number cannot work: blosc2 itself already holds a
   descriptor per memory-mapped frame, and python-blosc2's indexes open a couple
   of hundred of those, so on a 256-descriptor macOS default a generous cache
   here is what tips the process into EMFILE.  A sixteenth of the budget is what
   python-blosc2's suite tolerates at that limit (an eighth does not), and small
   working sets -- where caching actually pays -- fit in it comfortably. */
#define FRAME_READER_CACHE_MAX 96
#define FRAME_READER_CACHE_SHARE 16

/* Plain pthread type so it can be statically initialised; this block is
   POSIX-only anyway, and there the blosc2_pthread_* macros are pthread_*.
   No atomics needed: the counter is only touched when a handle is actually
   opened or closed, or once more when a frame is first refused one (see
   read_fp_nocache) -- never per read.  A fork() while another thread holds it
   would leave it locked in the child, so it is held across fork() (the child
   keeps the cached descriptors, so the count stays right). */
static pthread_mutex_t reader_cache_mutex = PTHREAD_MUTEX_INITIALIZER;
static int reader_cache_count = 0;
static pthread_once_t reader_cache_atfork_once = PTHREAD_ONCE_INIT;

static void reader_cache_atfork_prepare(void) {
  pthread_mutex_lock(&reader_cache_mutex);
}

static void reader_cache_atfork_parent(void) {
  pthread_mutex_unlock(&reader_cache_mutex);
}

static void reader_cache_atfork_child(void) {
  /* Locked in the prepare handler; a new one for this process (as in prefetch.c) */
  pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  reader_cache_mutex = mutex;
}

static void reader_cache_register_atfork(void) {
  if (pthread_atfork(reader_cache_atfork_prepare, reader_cache_atfork_parent, reader_cache_atfork_child) != 0) {
    BLOSC_TRACE_WARNING("pthread_atfork() failed: a fork()ed child may find the reader cache locked");
  }
}

static int reader_cache_max(void) {
  static int cached_max = -1;
  if (cached_max >= 0) {
    return cached_max;
  }
  char* envvar = getenv("BLOSC_MAX_CACHED_READERS");
  if (envvar != NULL && envvar[0] != '\0') {
    long value = strtol(envvar, NULL, 10);
    if (value >= 0 && value <= INT_MAX) {
      cached_max = (int)value;
      return cached_max;
    }
  }
  cached_max = FRAME_READER_CACHE_MAX;
  struct rlimit rl;
  if (getrlimit(RLIMIT_NOFILE, &rl) == 0 && rl.rlim_cur != RLIM_INFINITY) {
    rlim_t share = rl.rlim_cur / FRAME_READER_CACHE_SHARE;
    if (share < (rlim_t)cached_max) {
      cached_max = (int)share;
    }
  }
  /* A budget below FRAME_READER_CACHE_SHARE lands on 0, i.e. no caching at all;
     that is the right answer there -- a descriptor held for a frame's lifetime
     is exactly what such a process cannot spare. */
  return cached_max;
}

/* Claim a slot for one more cached handle, or report that the cache is full */
static bool reader_cache_claim(void) {
  bool claimed = false;
  pthread_once(&reader_cache_atfork_once, reader_cache_register_atfork);
  blosc2_pthread_mutex_lock(&reader_cache_mutex);
  if (reader_cache_count < reader_cache_max()) {
    reader_cache_count++;
    claimed = true;
  }
  blosc2_pthread_mutex_unlock(&reader_cache_mutex);
  return claimed;
}

static void reader_cache_return(void) {
  blosc2_pthread_mutex_lock(&reader_cache_mutex);
  if (reader_cache_count > 0) {
    reader_cache_count--;
  }
  blosc2_pthread_mutex_unlock(&reader_cache_mutex);
}

/* Device and inode of the open @p fd, or of @p path when it is not NULL.  Only
   identity is wanted, so on Linux ask statx() for exactly that: a plain (f)stat
   requests mtime too, and an NFS client answers that by first flushing the
   file's dirty pages to the server -- a synchronous round trip on every header
   read while the frame is being written through its cached writer. */
static int file_identity(int fd, const char* path, uint64_t* dev, uint64_t* ino) {
#if defined(__linux__) && defined(STATX_INO)
  struct statx stx;
  int rc = path == NULL ? statx(fd, "", AT_EMPTY_PATH, STATX_INO, &stx)
                        : statx(AT_FDCWD, path, 0, STATX_INO, &stx);
  if (rc == 0) {
    /* Same encoding as st_dev, so a statx() and a (f)stat() result compare fine */
    *dev = (uint64_t)makedev(stx.stx_dev_major, stx.stx_dev_minor);
    *ino = stx.stx_ino;
    return 0;
  }
  if (path != NULL && (errno == ENOENT || errno == ENOTDIR)) {
    *dev = 0;
    *ino = 0;
    return -1;
  }
  /* Anything else (ENOSYS before Linux 4.11, EPERM from a seccomp filter that
     does not know statx, ...): ask (f)stat instead */
#endif
  struct stat st;
  if ((path == NULL ? fstat(fd, &st) : stat(path, &st)) != 0) {
    *dev = 0;
    *ino = 0;
    return -1;
  }
  *dev = (uint64_t)st.st_dev;
  *ino = (uint64_t)st.st_ino;
  return 0;
}

/* A read-only stdio handle on a duplicate of @p fp's descriptor, or NULL.  It
   shares the open file description, so it costs no open on the server. */
static void* stdio_dup_reader(void* fp) {
  blosc2_stdio_file* sfp = (blosc2_stdio_file*)fp;
  int fd = sfp->file != NULL ? fileno(sfp->file) : -1;
  int dupfd = fd >= 0 ? fcntl(fd, F_DUPFD_CLOEXEC, 0) : -1;
  if (dupfd < 0) {
    return NULL;
  }
  blosc2_stdio_file* dup_fp = malloc(sizeof(blosc2_stdio_file));
  FILE* file = dup_fp != NULL ? fdopen(dupfd, "rb") : NULL;
  if (file == NULL) {
    free(dup_fp);
    close(dupfd);
    return NULL;
  }
  dup_fp->file = file;
  return dup_fp;
}

static void record_handle_identity(void* fp, uint64_t* dev, uint64_t* ino) {
  *dev = 0;
  *ino = 0;
  if (fp != NULL) {
    blosc2_stdio_file* sfp = (blosc2_stdio_file*)fp;
    int fd = sfp->file != NULL ? fileno(sfp->file) : -1;
    if (fd >= 0) {
      file_identity(fd, NULL, dev, ino);
    }
  }
}

/* Whether the handle cache may take one more handle for the empty slot of a
   frame whose `nocache` flag is clear; caller must hold read_fp_mutex.  When the
   process-wide budget is spent, the frame is flagged, so the budget is asked
   once rather than on every access for the rest of its life. */
static bool cache_slot_claim(const void* slot, bool* nocache) {
  if (slot != NULL || *nocache) {
    return false;
  }
  if (!reader_cache_claim()) {
    *nocache = true;
    return false;
  }
  return true;
}

/* Put @p fp in a slot claimed with cache_slot_claim(), with the identity of its
   file; a NULL @p fp (a failed open) gives the claim back instead. */
static void cache_install(void** slot, uint64_t* dev, uint64_t* ino, void* fp) {
  *slot = fp;
  if (fp == NULL) {
    reader_cache_return();
  }
  else {
    record_handle_identity(fp, dev, ino);
  }
}
#endif  /* !_WIN32 */


/* Whether the readers of a frame opened through @p io may be cached.  Third-party
   backends keep the documented one-handle-per-reader contract (and the mmap one
   already makes open() a cheap pointer return). */
static bool reader_cacheable(const blosc2_io* io) {
  return io->id == BLOSC2_IO_FILESYSTEM;
}

#if !defined(_WIN32)
/* Whether the writer of @p frame may be cached now.  With locking on, the
   writer is only cached while the lock is held, as the unlock is what closes it
   and so publishes the writes to the next lock holder.  Any write outside a lock
   would have nothing to close it, so it keeps a per-call handle. */
static bool writer_cacheable(const blosc2_frame_s* frame, const blosc2_io* io) {
  return reader_cacheable(io) && !(frame->locking && frame->lock_depth == 0);
}
#endif


/* Allocate a zeroed frame with its internal mutex ready */
static blosc2_frame_s* frame_alloc(void) {
  blosc2_frame_s* frame = calloc(1, sizeof(blosc2_frame_s));
  if (frame != NULL) {
    blosc2_pthread_mutex_init(&frame->read_fp_mutex, NULL);
  }
  return frame;
}


/* See frame.h */
void* frame_reader_acquire(blosc2_frame_s* frame, const blosc2_io* io) {
  blosc2_io_cb *io_cb = blosc2_get_io_cb(io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return NULL;
  }
  if (!reader_cacheable(io)) {
    return io_cb->open(frame->urlpath, "rb", io->params);
  }
#if defined(_WIN32)
  // No handle caching on Windows.  The CRT opens files without
  // FILE_SHARE_DELETE, so a cached handle turns every unlink or rename of the
  // frame file into a sharing violation.  Callers that replace a frame rather
  // than rewrite it in place -- python-blosc2 does, both via os.replace and via
  // remove-then-recreate for mode="w" -- would get hard errors instead of the
  // stale read that frame_reader_revalidate() handles elsewhere.  Caching here
  // needs CreateFileW(..., FILE_SHARE_DELETE) plus POSIX-semantics deletion
  // (Win10 1709+), which is only worth its cost once measured on Windows.
  return io_cb->open(frame->urlpath, "rb", io->params);
#else
  // The cached handle pins the inode it was opened on, so a frame file that is
  // replaced instead of rewritten in place would keep serving the old bytes.
  // frame_reader_revalidate() catches that ahead of each header read.
  //
  // No unlocked fast path on read_fp: reading it outside the mutex races the
  // store below (C11 data race, and TSan says so).  An uncontended lock is a
  // handful of ns against the ~600 ns pread this hands a handle to.
  blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
  if (cache_slot_claim(frame->read_fp, &frame->read_fp_nocache)) {
    cache_install(&frame->read_fp, &frame->read_fp_dev, &frame->read_fp_ino,
                  io_cb->open(frame->urlpath, "rb", io->params));
  }
  void* fp = frame->read_fp;
  if (fp != NULL) {
    // Held until the matching release, so nothing can close it underneath a
    // caller that keeps it across several reads (frame_to_schunk does)
    frame->read_fp_refs++;
  }
  blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
  if (fp == NULL) {
    // Cache full (or the cached open failed): hand out a private handle, which
    // the matching frame_reader_release() closes since it is not frame->read_fp
    fp = io_cb->open(frame->urlpath, "rb", io->params);
  }
  return fp;
#endif
}


/* See frame.h */
void frame_reader_release(blosc2_frame_s* frame, const blosc2_io_cb* io_cb, void* fp) {
  if (fp == NULL) {
    return;
  }
  // Same reasoning as in frame_reader_acquire(): read_fp is only ever read
  // under the mutex, so a concurrent first open cannot race this comparison.
  blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
  bool is_cached = (fp == frame->read_fp);
  if (is_cached) {
    frame->read_fp_refs--;
  }
  blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
  if (!is_cached) {
    io_cb->close(fp);
  }
}


/* Keep @p fp, a "rb" handle on the frame's file that the caller opened and no
   longer needs, as the frame's cached reader instead of closing it, so that the
   first read does not open the file again: on NFS each open and close is a
   synchronous round trip to the server.  The frame must not be shared yet. */
static void frame_reader_adopt(blosc2_frame_s* frame, const blosc2_io* io,
                               const blosc2_io_cb* io_cb, void* fp) {
#if !defined(_WIN32)
  bool adopted = false;
  if (reader_cacheable(io) && !frame->sframe) {
    blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
    adopted = cache_slot_claim(frame->read_fp, &frame->read_fp_nocache);
    if (adopted) {
      cache_install(&frame->read_fp, &frame->read_fp_dev, &frame->read_fp_ino, fp);
    }
    blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
  }
  if (adopted) {
    return;
  }
#else
  BLOSC_UNUSED_PARAM(frame);
  BLOSC_UNUSED_PARAM(io);
#endif
  io_cb->close(fp);
}


/* Drop the cached handle; caller must hold read_fp_mutex.  Returns false when
   the handle is checked out and @p force is not set, i.e. nothing was closed. */
static bool frame_reader_close_locked(blosc2_frame_s* frame, bool force) {
  if (frame->read_fp == NULL) {
    return true;
  }
  if (frame->read_fp_refs > 0 && !force) {
    /* A caller up the stack is reading through it (frame_to_schunk holds it
       across its whole chunk loop, and that loop re-enters get_header_info).
       Closing it here would hand that caller a dangling handle, and its own
       release would then close it a second time.  Leave it: the operation in
       flight finishes on the file it started on, and the next revalidate --
       past that release -- drops it. */
    return false;
  }
  /* read_fp only ever comes from the filesystem backend, so close it directly:
     blosc2_get_io_cb() would return NULL after a blosc2_destroy(), and then the
     descriptor would leak while its cache slot got handed back anyway. */
  blosc2_stdio_close(frame->read_fp);
  frame->read_fp = NULL;
  frame->read_fp_refs = 0;
#if !defined(_WIN32)
  reader_cache_return();
#endif
  return true;
}


/* Drop the cached writable handle (which flushes it on NFS) and forget the file
   size; caller must hold read_fp_mutex.  Writes to a frame are serialized by
   its callers, so no write can be using the handle meanwhile. */
static void frame_writer_close_locked(blosc2_frame_s* frame) {
  if (frame->write_fp != NULL) {
    /* Only the filesystem backend ever populates write_fp */
    blosc2_stdio_close(frame->write_fp);
    frame->write_fp = NULL;
#if !defined(_WIN32)
    reader_cache_return();
#endif
  }
  frame->write_fp_stale = false;
  frame->file_end = 0;
}


/* See frame.h */
void frame_reader_invalidate(blosc2_frame_s* frame) {
  blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
  frame_writer_close_locked(frame);
  frame_reader_close_locked(frame, true);
  blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
}


#if !defined(_WIN32)
/* Whether the cached handle with recorded identity (@p fd_dev, @p fd_ino) no
   longer refers to the file at the frame's urlpath, whose identity is
   (@p path_dev, @p path_ino), or unknown when @p path_found is false. */
static bool cached_handle_is_stale(uint64_t fd_dev, uint64_t fd_ino, bool path_found,
                                   uint64_t path_dev, uint64_t path_ino) {
  if (fd_dev == 0 && fd_ino == 0) {
    /* Cannot vouch for the handle; drop it and let the next acquire reopen */
    return true;
  }
  if (!path_found) {
    /* The path is gone but the inode we hold open is still perfectly valid, so
       keep using it -- exactly what an already-open fd does on POSIX. */
    return false;
  }
  /* A different file at urlpath means unlink-then-recreate (mode="w") or a
     rename over it (os.replace) */
  return fd_dev != path_dev || fd_ino != path_ino;
}
#endif


/* See frame.h */
void frame_reader_revalidate(blosc2_frame_s* frame) {
#if defined(_WIN32)
  /* No handle is ever cached here, so none can go stale */
  BLOSC_UNUSED_PARAM(frame);
#else
  if (frame->urlpath == NULL) {
    return;
  }
  /* The whole inspection runs under read_fp_mutex: reading the pointer and then
     dereferencing it outside the lock would let a concurrent invalidate close
     the handle in between.  The few statx() calls under the lock (one for the
     path, one per cached handle) cost nothing here, as this runs once per
     header read rather than per block. */
  blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
  /* Only the filesystem backend ever populates read_fp and write_fp, so these
     casts are safe */
  blosc2_stdio_file* my_fp = (blosc2_stdio_file*)frame->read_fp;
  blosc2_stdio_file* my_wfp = (blosc2_stdio_file*)frame->write_fp;
  if (my_fp == NULL && my_wfp == NULL) {
    blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
    return;
  }
  /* Check each cached handle on its own: one of them may have been opened
     after the file was replaced, and a frame can hold a cached writer but no
     cached reader when the handle budget ran out in between. */
  uint64_t path_dev = 0, path_ino = 0;
  bool path_found = file_identity(-1, frame->urlpath, &path_dev, &path_ino) == 0;
  bool read_stale = my_fp != NULL && cached_handle_is_stale(frame->read_fp_dev, frame->read_fp_ino,
                                                            path_found, path_dev, path_ino);
  /* Unlike a reader, a writer must not outlive its path: writes to an unlinked
     inode would vanish silently, where the per-call open used to fail. */
  bool write_stale = my_wfp != NULL &&
                     (!path_found || cached_handle_is_stale(frame->write_fp_dev, frame->write_fp_ino,
                                                            path_found, path_dev, path_ino));
  if (read_stale) {
    frame_reader_close_locked(frame, false);
  }
  if (write_stale) {
    /* Only flag the writer: a write in flight on another thread may be using it
       right now.  It reopens the path on its next acquire. */
    frame->write_fp_stale = true;
  }
  blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
  if (read_stale || write_stale) {
    /* Force the metadata refresh too: the replacement is often the same length
       as the old frame, and then the trailer poll in frame_refresh_if_stale()
       never fires by itself. */
    frame->force_refresh = true;
  }
#endif
}


/* See frame.h */
void* frame_writer_acquire(blosc2_frame_s* frame, const blosc2_io_cb* io_cb) {
  const blosc2_io* io = frame->schunk->storage->io;
#if defined(_WIN32)
  // Same reason as for readers: a cached handle would block unlink/rename
  return io_cb->open(frame->urlpath, "rb+", io->params);
#else
  if (!writer_cacheable(frame, io)) {
    return io_cb->open(frame->urlpath, "rb+", io->params);
  }
  // Writes to one frame are serialized by its callers; the mutex only guards
  // against readers flagging the handle stale (and teardown) meanwhile
  blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
  if (frame->write_fp_stale) {
    frame_writer_close_locked(frame);
  }
  // Cached writers draw on the same descriptor budget as cached readers
  if (cache_slot_claim(frame->write_fp, &frame->write_fp_nocache)) {
    cache_install(&frame->write_fp, &frame->write_fp_dev, &frame->write_fp_ino,
                  io_cb->open(frame->urlpath, "rb+", io->params));
  }
  void* fp = frame->write_fp;
  blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
  if (fp != NULL) {
    return fp;
  }
  // Budget exhausted (or the cached open failed): a private per-call handle,
  // which frame_writer_release() closes
  return io_cb->open(frame->urlpath, "rb+", io->params);
#endif
}


/* Keep @p fp, a writable handle the caller just created the frame's file with,
   as the frame's cached writer instead of closing it: closing flushes the data
   synchronously on NFS, and the next write would open the file again anyway.
   Returns false (and leaves @p fp to the caller) when it cannot be cached. */
static bool frame_writer_adopt(blosc2_frame_s* frame, const blosc2_io* io, void* fp) {
#if defined(_WIN32)
  BLOSC_UNUSED_PARAM(frame);
  BLOSC_UNUSED_PARAM(io);
  BLOSC_UNUSED_PARAM(fp);
  return false;
#else
  if (!writer_cacheable(frame, io) || frame->sframe) {
    return false;
  }
  blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
  bool adopted = cache_slot_claim(frame->write_fp, &frame->write_fp_nocache);
  if (adopted) {
    cache_install(&frame->write_fp, &frame->write_fp_dev, &frame->write_fp_ino, fp);
    frame->write_fp_stale = false;
    /* Each update reads the header first, and the first read would open the
       file once more for the cached reader (another OPEN, and a CLOSE at the
       end, on NFS).  A duplicate of the writer's descriptor serves as well. */
    if (cache_slot_claim(frame->read_fp, &frame->read_fp_nocache)) {
      frame->read_fp = stdio_dup_reader(fp);
      if (frame->read_fp == NULL) {
        reader_cache_return();
      }
      else {
        frame->read_fp_dev = frame->write_fp_dev;
        frame->read_fp_ino = frame->write_fp_ino;
      }
    }
  }
  blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
  return adopted;
#endif
}


/* See frame.h */
void frame_writer_release(blosc2_frame_s* frame, const blosc2_io_cb* io_cb, void* fp) {
  if (fp == NULL) {
    return;
  }
  // write_fp is only ever read under the mutex, as read_fp is
  blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
  bool is_cached = (fp == frame->write_fp);
  blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
  if (!is_cached) {
    io_cb->close(fp);
  }
}


/* See frame.h */
void frame_writer_close(blosc2_frame_s* frame) {
  blosc2_pthread_mutex_lock(&frame->read_fp_mutex);
  frame_writer_close_locked(frame);
  blosc2_pthread_mutex_unlock(&frame->read_fp_mutex);
}


/* Create a new (empty) frame */
blosc2_frame_s* frame_new(const char* urlpath) {
  blosc2_frame_s* new_frame = frame_alloc();
  if (new_frame == NULL) {
    return NULL;
  }
  if (urlpath != NULL) {
    char* new_urlpath = malloc(strlen(urlpath) + 1);  // + 1 for the trailing NULL
    if (new_urlpath == NULL) {
      blosc2_pthread_mutex_destroy(&new_frame->read_fp_mutex);
      free(new_frame);
      return NULL;
    }
    new_frame->urlpath = strcpy(new_urlpath, urlpath);
    new_frame->file_offset = 0;
  }
  return new_frame;
}


/* Whether `io` requests locking, either explicitly (blosc2_stdio_params.locking)
   or via the fleet-wide BLOSC_LOCKING environment variable.  Factored out of
   frame_set_locking() so callers without a frame object yet (e.g. the open
   path's pre-frame bootstrap read) can also ask the question. */
bool frame_locking_requested(const blosc2_io* io) {
  if (io == NULL || io->id != BLOSC2_IO_FILESYSTEM) {
    return false;
  }
  bool locking = io->params != NULL && ((blosc2_stdio_params*)io->params)->locking;
  if (!locking) {
    // "0" or an empty value leave it off
    char* envvar = getenv("BLOSC_LOCKING");
    locking = envvar != NULL && envvar[0] != '\0' && strcmp(envvar, "0") != 0;
  }
  return locking;
}


void frame_set_locking(blosc2_frame_s* frame, const blosc2_io* io) {
  if (frame->urlpath == NULL) {
    return;
  }
  if (frame_locking_requested(io)) {
    frame->locking = true;
    frame->lock_fd = -1;
  }
}


/* Path of the sidecar lock file: inside the directory for sframes (removed for
   free by blosc2_remove_dir), alongside the file for cframes. */
static char* frame_lock_path(blosc2_frame_s* frame) {
  const char* suffix = frame->sframe ? "/.b2lock" : ".b2lock";
  char* path = malloc(strlen(frame->urlpath) + strlen(suffix) + 1);
  if (path == NULL) {
    return NULL;
  }
  strcpy(path, frame->urlpath);
  strcat(path, suffix);
  return path;
}


// Where the generation counter lives in the sidecar (past the byte range
// locked by LockFileEx on Windows)
#define FRAME_LOCK_SEQ_OFFSET 8


static int frame_os_lock(blosc2_frame_s* frame, bool exclusive) {
#if defined(_WIN32)
  OVERLAPPED ov;
  memset(&ov, 0, sizeof(ov));
  if (!LockFileEx((HANDLE)frame->lock_fd, exclusive ? LOCKFILE_EXCLUSIVE_LOCK : 0,
                  0, 1, 0, &ov)) {
    return BLOSC2_ERROR_LOCK;
  }
#else
  int rc;
  do {
    rc = flock((int)frame->lock_fd, exclusive ? LOCK_EX : LOCK_SH);
  } while (rc != 0 && errno == EINTR);
  if (rc != 0) {
    return BLOSC2_ERROR_LOCK;
  }
#endif
  return BLOSC2_ERROR_SUCCESS;
}


static int frame_os_unlock(blosc2_frame_s* frame) {
#if defined(_WIN32)
  OVERLAPPED ov;
  memset(&ov, 0, sizeof(ov));
  if (!UnlockFileEx((HANDLE)frame->lock_fd, 0, 1, 0, &ov)) {
    return BLOSC2_ERROR_LOCK;
  }
#else
  if (flock((int)frame->lock_fd, LOCK_UN) != 0) {
    return BLOSC2_ERROR_LOCK;
  }
#endif
  return BLOSC2_ERROR_SUCCESS;
}


/* Read the sidecar's generation counter (must be called with the lock held).
   A fresh (short) sidecar reads as 0. */
static int frame_lock_read_seq(blosc2_frame_s* frame, uint64_t* seq) {
  *seq = 0;
#if defined(_WIN32)
  OVERLAPPED ov;
  memset(&ov, 0, sizeof(ov));
  ov.Offset = FRAME_LOCK_SEQ_OFFSET;
  DWORD nread = 0;
  if (!ReadFile((HANDLE)frame->lock_fd, seq, sizeof(*seq), &nread, &ov)) {
    if (GetLastError() != ERROR_HANDLE_EOF) {
      return BLOSC2_ERROR_LOCK;
    }
  }
  if (nread != sizeof(*seq)) {
    *seq = 0;
  }
#else
  int64_t nread = pread((int)frame->lock_fd, seq, sizeof(*seq), FRAME_LOCK_SEQ_OFFSET);
  if (nread < 0) {
    return BLOSC2_ERROR_LOCK;
  }
  if (nread != (int64_t)sizeof(*seq)) {
    *seq = 0;
  }
#endif
  return BLOSC2_ERROR_SUCCESS;
}


/* Write the sidecar's generation counter (must be called with the exclusive
   lock held). */
static int frame_lock_write_seq(blosc2_frame_s* frame, uint64_t seq) {
#if defined(_WIN32)
  OVERLAPPED ov;
  memset(&ov, 0, sizeof(ov));
  ov.Offset = FRAME_LOCK_SEQ_OFFSET;
  DWORD nwritten = 0;
  if (!WriteFile((HANDLE)frame->lock_fd, &seq, sizeof(seq), &nwritten, &ov) ||
      nwritten != sizeof(seq)) {
    return BLOSC2_ERROR_LOCK;
  }
#else
  if (pwrite((int)frame->lock_fd, &seq, sizeof(seq), FRAME_LOCK_SEQ_OFFSET) !=
      (int64_t)sizeof(seq)) {
    return BLOSC2_ERROR_LOCK;
  }
#endif
  return BLOSC2_ERROR_SUCCESS;
}


int frame_lock(blosc2_frame_s* frame, bool exclusive) {
  if (frame == NULL || !frame->locking) {
    return BLOSC2_ERROR_SUCCESS;
  }
  if (frame->lock_depth > 0) {
    // Already held by this handle (a nested call); the outer lock covers us
    frame->lock_depth++;
    return BLOSC2_ERROR_SUCCESS;
  }
  if (frame->lock_fd == -1) {
    // Lazily open the sidecar, kept for the frame's lifetime
    char* path = frame_lock_path(frame);
    if (path == NULL) {
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
#if defined(_WIN32)
    HANDLE h = CreateFileA(path, GENERIC_READ | GENERIC_WRITE,
                           FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
      BLOSC_TRACE_ERROR("Cannot open the lock file in: %s", path);
      free(path);
      return BLOSC2_ERROR_LOCK;
    }
    frame->lock_fd = (intptr_t)h;
#else
    int fd = open(path, O_CREAT | O_RDWR | O_CLOEXEC, 0666);
    if (fd < 0) {
      BLOSC_TRACE_ERROR("Cannot open the lock file in: %s", path);
      free(path);
      return BLOSC2_ERROR_LOCK;
    }
    frame->lock_fd = fd;
#endif
    free(path);
  }
  if (frame_os_lock(frame, exclusive) < 0) {
    BLOSC_TRACE_ERROR("Cannot lock the frame.");
    return BLOSC2_ERROR_LOCK;
  }
  // Generation counter: writers bump it, everyone compares it with the last
  // value it saw.  This detects mutations by other handles exactly, even when
  // the frame length on disk ends up unchanged (which the length-based
  // staleness check in frame_refresh_if_stale() cannot see).
  uint64_t seq;
  if (frame_lock_read_seq(frame, &seq) < 0 ||
      (exclusive && frame_lock_write_seq(frame, seq + 1) < 0)) {
    BLOSC_TRACE_ERROR("Cannot access the frame lock generation counter.");
    frame_os_unlock(frame);
    return BLOSC2_ERROR_LOCK;
  }
  if (seq != frame->lock_seq) {
    frame->force_refresh = true;
  }
  if (exclusive) {
    seq++;
  }
  frame->lock_seq = seq;
  frame->lock_depth = 1;
  return BLOSC2_ERROR_SUCCESS;
}


int frame_unlock(blosc2_frame_s* frame) {
  if (frame == NULL || !frame->locking || frame->lock_depth == 0) {
    return BLOSC2_ERROR_SUCCESS;
  }
  if (--frame->lock_depth > 0) {
    return BLOSC2_ERROR_SUCCESS;
  }
  // Hand our writes over before the next lock holder looks: closing the cached
  // writer is what pushes them to the server on NFS (close-to-open consistency).
  // A no-op unless this handle wrote since it last let go of the lock.
  frame_writer_close(frame);
  if (frame_os_unlock(frame) < 0) {
    BLOSC_TRACE_ERROR("Cannot unlock the frame.");
    return BLOSC2_ERROR_LOCK;
  }
  return BLOSC2_ERROR_SUCCESS;
}


/* Free memory from a frame. */
int frame_free(blosc2_frame_s* frame) {

  frame_reader_invalidate(frame);
  blosc2_pthread_mutex_destroy(&frame->read_fp_mutex);

  if (frame->locking && frame->lock_fd != -1) {
#if defined(_WIN32)
    CloseHandle((HANDLE)frame->lock_fd);
#else
    close((int)frame->lock_fd);
#endif
  }

  if (frame->cframe != NULL && !frame->avoid_cframe_free) {
    free(frame->cframe);
  }

  if (frame->coffsets != NULL && frame->coffsets_needs_free) {
    free(frame->coffsets);
  }

  if (frame->urlpath != NULL) {
    free(frame->urlpath);
  }
  free(frame->holes);

  free(frame);

  return 0;
}


void *new_header_frame(blosc2_schunk *schunk, blosc2_frame_s *frame) {
  if (frame == NULL) {
    return NULL;
  }
  uint8_t* h2 = calloc(FRAME_HEADER_MINLEN, 1);
  uint8_t* h2p = h2;

  // The msgpack header starts here
  *h2p = 0x90;  // fixarray...
  *h2p += 14;   // ...with 13 elements
  h2p += 1;

  // Magic number
  *h2p = 0xa0 + 8;  // str with 8 elements
  h2p += 1;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }
  strcpy((char*)h2p, "b2frame");
  h2p += 8;

  // Header size
  *h2p = 0xd2;  // int32
  h2p += 1 + 4;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Total frame size
  *h2p = 0xcf;  // uint64
  // Fill it with frame->len which is known *after* the creation of the frame (e.g. when updating the header)
  int64_t flen = frame->len;
  to_big(h2 + FRAME_LEN, &flen, sizeof(flen));
  h2p += 1 + 8;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Flags
  *h2p = 0xa0 + 4;  // str with 4 elements
  h2p += 1;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }
  // General flags
  if (schunk->chunksize == 0 || (schunk->flags2 & BLOSC2_VL_BLOCKS)) {
    *h2p = BLOSC2_VERSION_FRAME_FORMAT_VL_BLOCKS;  // version
  }
  else {
    *h2p = BLOSC2_VERSION_FRAME_FORMAT_RC1;  // version
  }
  *h2p += 0x10;  // 64-bit offsets.  We only support this for now.
  if (schunk->chunksize == 0) {
    *h2p |= FRAME_VARIABLE_CHUNKS;
  }
  if (schunk->flags2 & BLOSC2_VL_BLOCKS) {
    *h2p |= FRAME_VL_BLOCKS;
  }
  h2p += 1;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Frame type
  // We only support contiguous and sparse directories frames currently
  *h2p = frame->sframe ? 1 : 0;
  h2p += 1;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Codec flags
  *h2p = schunk->compcode;
  if (schunk->compcode >= BLOSC_LAST_CODEC) {
    *h2p = BLOSC_UDCODEC_FORMAT;
  }
  *h2p += (schunk->clevel) << 4u;  // clevel
  h2p += 1;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Other flags
  *h2p = schunk->splitmode - 1;
  h2p += 1;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Uncompressed size
  *h2p = 0xd3;  // int64
  h2p += 1;
  int64_t nbytes = schunk->nbytes;
  to_big(h2p, &nbytes, sizeof(nbytes));
  h2p += 8;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Compressed size
  *h2p = 0xd3;  // int64
  h2p += 1;
  int64_t cbytes = schunk->cbytes;
  to_big(h2p, &cbytes, sizeof(cbytes));
  h2p += 8;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Type size
  *h2p = 0xd2;  // int32
  h2p += 1;
  int32_t typesize = schunk->typesize;
  to_big(h2p, &typesize, sizeof(typesize));
  h2p += 4;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Block size
  *h2p = 0xd2;  // int32
  h2p += 1;
  int32_t blocksize = schunk->blocksize;
  to_big(h2p, &blocksize, sizeof(blocksize));
  h2p += 4;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Chunk size
  *h2p = 0xd2;  // int32
  h2p += 1;
  int32_t chunksize = schunk->chunksize;
  to_big(h2p, &chunksize, sizeof(chunksize));
  h2p += 4;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Number of threads for compression
  *h2p = 0xd1;  // int16
  h2p += 1;
  int16_t nthreads = (int16_t)schunk->cctx->nthreads;
  to_big(h2p, &nthreads, sizeof(nthreads));
  h2p += 2;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // Number of threads for decompression
  *h2p = 0xd1;  // int16
  h2p += 1;
  nthreads = (int16_t)schunk->dctx->nthreads;
  to_big(h2p, &nthreads, sizeof(nthreads));
  h2p += 2;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // The boolean for variable-length metalayers
  *h2p = (schunk->nvlmetalayers > 0) ? (uint8_t)0xc3 : (uint8_t)0xc2;
  h2p += 1;
  if (h2p - h2 >= FRAME_HEADER_MINLEN) {
    return NULL;
  }

  // The space for FRAME_FILTER_PIPELINE
  *h2p = 0xd8;  //  fixext 16
  h2p += 1;
  if (BLOSC2_MAX_FILTERS > FRAME_FILTER_PIPELINE_MAX) {
    return NULL;
  }
  // Store the filter pipeline in header
  uint8_t* mp_filters = h2 + FRAME_FILTER_PIPELINE + 1;
  uint8_t* mp_meta = h2 + FRAME_FILTER_PIPELINE + 1 + FRAME_FILTER_PIPELINE_MAX;
  for (int i = 0; i < BLOSC2_MAX_FILTERS; i++) {
      mp_filters[i] = schunk->filters[i];
      mp_meta[i] = schunk->filters_meta[i];
  }
  *h2p = (uint8_t) BLOSC2_MAX_FILTERS;
  h2p += 1;
  h2p += 16;

  // User-defined codec and codec metadata
  uint8_t* udcodec = h2 + FRAME_UDCODEC;
  *udcodec = schunk->compcode;
  uint8_t* codec_meta = h2 + FRAME_CODEC_META;
  *codec_meta = schunk->compcode_meta;

  // Other flags 2 (byte 0x55): bit 0 = use_dict
  h2[FRAME_OTHER_FLAGS2] = schunk->use_dict ? FRAME_USE_DICT : 0;

  if (h2p - h2 != FRAME_HEADER_MINLEN) {
    return NULL;
  }

  int32_t hsize = FRAME_HEADER_MINLEN;

  // Now, deal with metalayers
  uint16_t nmetalayers = schunk->nmetalayers;
  if (nmetalayers > BLOSC2_MAX_METALAYERS) {
    return NULL;
  }

  // Make space for the header of metalayers (array marker, size, map of offsets)
  h2 = realloc(h2, (size_t)hsize + 1 + 1 + 2 + 1 + 2);
  h2p = h2 + hsize;

  // The msgpack header for the metalayers (array_marker, size, map of offsets, list of metalayers)
  *h2p = 0x90 + 3;  // array with 3 elements
  h2p += 1;

  // Size for the map (index) of offsets, including this uint16 size (to be filled out later on)
  *h2p = 0xcd;  // uint16
  h2p += 1 + 2;

  // Map (index) of offsets for optional metalayers
  *h2p = 0xde;  // map 16 with N keys
  h2p += 1;
  to_big(h2p, &nmetalayers, sizeof(nmetalayers));
  h2p += sizeof(nmetalayers);
  int32_t current_header_len = (int32_t)(h2p - h2);
  int32_t *offtooff = malloc(nmetalayers * sizeof(int32_t));
  if (offtooff == NULL) {
    free(h2);
    return NULL;
  }
  for (int nmetalayer = 0; nmetalayer < nmetalayers; nmetalayer++) {
    if (frame == NULL) {
      free(offtooff);
      free(h2);
      return NULL;
    }
    blosc2_metalayer *metalayer = schunk->metalayers[nmetalayer];
    uint8_t namelen = (uint8_t) strlen(metalayer->name);
    h2 = realloc(h2, (size_t)current_header_len + 1 + namelen + 1 + 4);
    h2p = h2 + current_header_len;
    // Store the metalayer
    if (namelen >= (1U << 5U)) {  // metalayer strings cannot be longer than 32 bytes
      free(offtooff);
      free(h2);
      return NULL;
    }
    *h2p = (uint8_t)0xa0 + namelen;  // str
    h2p += 1;
    memcpy(h2p, metalayer->name, namelen);
    h2p += namelen;
    // Space for storing the offset for the value of this metalayer
    *h2p = 0xd2;  // int32
    h2p += 1;
    offtooff[nmetalayer] = (int32_t)(h2p - h2);
    h2p += 4;
    current_header_len += 1 + namelen + 1 + 4;
  }
  int32_t hsize2 = (int32_t)(h2p - h2);
  if (hsize2 != current_header_len) {  // sanity check
    free(offtooff);
    free(h2);
    return NULL;
  }

  // Map size + int16 size
  if ((uint32_t) (hsize2 - hsize) >= (1U << 16U)) {
    free(offtooff);
    free(h2);
    return NULL;
  }
  uint16_t map_size = (uint16_t) (hsize2 - hsize);
  to_big(h2 + FRAME_IDX_SIZE, &map_size, sizeof(map_size));

  // Make space for an (empty) array
  hsize = (int32_t)(h2p - h2);
  h2 = realloc(h2, (size_t)hsize + 2 + 1 + 2);
  h2p = h2 + hsize;

  // Now, store the values in an array
  *h2p = 0xdc;  // array 16 with N elements
  h2p += 1;
  to_big(h2p, &nmetalayers, sizeof(nmetalayers));
  h2p += sizeof(nmetalayers);
  current_header_len = (int32_t)(h2p - h2);
  for (int nmetalayer = 0; nmetalayer < nmetalayers; nmetalayer++) {
    if (frame == NULL) {
      free(offtooff);
      free(h2);
      return NULL;
    }
    blosc2_metalayer *metalayer = schunk->metalayers[nmetalayer];
    h2 = realloc(h2, (size_t)current_header_len + 1 + 4 + metalayer->content_len);
    h2p = h2 + current_header_len;
    // Store the serialized contents for this metalayer
    *h2p = 0xc6;  // bin32
    h2p += 1;
    to_big(h2p, &(metalayer->content_len), sizeof(metalayer->content_len));
    h2p += 4;
    memcpy(h2p, metalayer->content, metalayer->content_len);  // buffer, no need to swap
    h2p += metalayer->content_len;
    // Update the offset now that we know it
    to_big(h2 + offtooff[nmetalayer], &current_header_len, sizeof(current_header_len));
    current_header_len += 1 + 4 + metalayer->content_len;
  }
  free(offtooff);
  hsize = (int32_t)(h2p - h2);
  if (hsize != current_header_len) {  // sanity check
    free(h2);
    return NULL;
  }

  // Set the length of the whole header now that we know it
  to_big(h2 + FRAME_HEADER_LEN, &hsize, sizeof(hsize));

  return h2;
}


static int get_coffsets_nbytes(blosc2_frame_s *frame, int32_t header_len, int64_t cbytes,
                               int32_t *coffsets_nbytes, const blosc2_io *io);

int get_header_info(blosc2_frame_s *frame, int32_t *header_len, int64_t *frame_len, int64_t *nbytes, int64_t *cbytes,
                    int32_t *blocksize, int32_t *chunksize, int64_t *nchunks, int32_t *typesize, uint8_t *compcode,
                    uint8_t *compcode_meta, uint8_t *clevel, uint8_t *filters, uint8_t *filters_meta,
                    uint8_t *splitmode, uint8_t *use_dict, const blosc2_io *io) {
  uint8_t* framep = frame->cframe;
  uint8_t* header_ptr;
  uint8_t header[FRAME_HEADER_MINLEN];

  blosc2_io_cb *io_cb = blosc2_get_io_cb(io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }

  if (frame->len <= 0) {
    return BLOSC2_ERROR_READ_BUFFER;
  }

  if (frame->cframe == NULL) {
    int64_t rbytes = 0;
    void* fp = NULL;
    int64_t io_pos = 0;
    if (frame->sframe) {
      fp = sframe_open_index(frame->urlpath, "rb", io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
    }
    else {
      /* Ahead of the header read, not after it: everything downstream (and
         frame_refresh_if_stale in particular) trusts the length this read
         returns, so a stale handle here would pair old metadata with the
         replacement's bytes. */
      frame_reader_revalidate(frame);
      fp = frame_reader_acquire(frame, io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset;
    }
    if (io_cb->is_allocation_necessary)
      header_ptr = header;
    rbytes = io_cb->read((void**)&header_ptr, 1, FRAME_HEADER_MINLEN, io_pos, fp);
    frame_reader_release(frame, io_cb, fp);
    if (rbytes != FRAME_HEADER_MINLEN) {
      return BLOSC2_ERROR_FILE_READ;
    }
    framep = header_ptr;
  }

  // Consistency check for frame type
  uint8_t frame_type = framep[FRAME_TYPE];
  uint8_t frame_version = framep[FRAME_FLAGS] & 0x0fu;
  if (frame_version > BLOSC2_VERSION_FRAME_FORMAT) {
    BLOSC_TRACE_ERROR("Unsupported cframe version: %u", frame_version);
    return BLOSC2_ERROR_VERSION_SUPPORT;
  }
  if (frame->sframe) {
    if (frame_type != FRAME_DIRECTORY_TYPE) {
      return BLOSC2_ERROR_FRAME_TYPE;
    }
  } else {
    if (frame_type != FRAME_CONTIGUOUS_TYPE) {
      return BLOSC2_ERROR_FRAME_TYPE;
    }
  }

  // Fetch some internal lengths
  from_big(header_len, framep + FRAME_HEADER_LEN, sizeof(*header_len));
  if (*header_len < FRAME_HEADER_MINLEN) {
    BLOSC_TRACE_ERROR("Header length is zero or smaller than min allowed.");
    return BLOSC2_ERROR_INVALID_HEADER;
  }
  from_big(frame_len, framep + FRAME_LEN, sizeof(*frame_len));
  if (*header_len > *frame_len) {
    BLOSC_TRACE_ERROR("Header length exceeds length of the frame.");
    return BLOSC2_ERROR_INVALID_HEADER;
  }
  from_big(nbytes, framep + FRAME_NBYTES, sizeof(*nbytes));
  from_big(cbytes, framep + FRAME_CBYTES, sizeof(*cbytes));
  from_big(blocksize, framep + FRAME_BLOCKSIZE, sizeof(*blocksize));
  if (chunksize != NULL) {
    from_big(chunksize, framep + FRAME_CHUNKSIZE, sizeof(*chunksize));
  }
  if (typesize != NULL) {
    from_big(typesize, framep + FRAME_TYPESIZE, sizeof(*typesize));
    if (*typesize <= 0) {
      BLOSC_TRACE_ERROR("`typesize` cannot be zero or negative.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
  }

  // Codecs
  uint8_t frame_codecs = framep[FRAME_CODECS];
  if (clevel != NULL) {
    *clevel = frame_codecs >> 4u;
  }
  if (compcode != NULL) {
    *compcode = frame_codecs & 0xFu;
    if (*compcode == BLOSC_UDCODEC_FORMAT) {
      from_big(compcode, framep + FRAME_UDCODEC, sizeof(*compcode));
    }
  }

  // Other flags
  uint8_t other_flags = framep[FRAME_OTHER_FLAGS];
  if (splitmode != NULL) {
    *splitmode = (other_flags & 0x03u) + 1;
  }

  // Other flags 2: bit 0 = use_dict
  if (use_dict != NULL) {
    *use_dict = (framep[FRAME_OTHER_FLAGS2] & FRAME_USE_DICT) ? 1 : 0;
  }

  if (compcode_meta != NULL) {
    from_big(compcode_meta, framep + FRAME_CODEC_META, sizeof(*compcode_meta));
  }

  // Filters
  if (filters != NULL && filters_meta != NULL) {
    uint8_t nfilters = framep[FRAME_FILTER_PIPELINE];
    if (nfilters > BLOSC2_MAX_FILTERS) {
      BLOSC_TRACE_ERROR("The number of filters in frame header are too large for Blosc2.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    uint8_t *filters_ = framep + FRAME_FILTER_PIPELINE + 1;
    uint8_t *filters_meta_ = framep + FRAME_FILTER_PIPELINE + 1 + FRAME_FILTER_PIPELINE_MAX;
    for (int i = 0; i < nfilters; i++) {
      filters[i] = filters_[i];
      filters_meta[i] = filters_meta_[i];
    }
  }

  if (*nbytes > 0) {
    if (*chunksize > 0) {
      // We can compute the number of chunks directly when there is a fixed chunk size.
      *nchunks = *nbytes / *chunksize;
      if (*nbytes % *chunksize > 0) {
        *nchunks += 1;
      }

      // Sanity check for compressed sizes
      if ((*cbytes < 0) || ((int64_t)*nchunks * *chunksize < *nbytes)) {
        BLOSC_TRACE_ERROR("Invalid compressed size in frame header.");
        return BLOSC2_ERROR_INVALID_HEADER;
      }
    }
    else if (*chunksize == 0) {
      int32_t coffsets_nbytes;
      int rc2 = get_coffsets_nbytes(frame, *header_len, *cbytes, &coffsets_nbytes, io);
      if (rc2 < 0) {
        return rc2;
      }
      if (coffsets_nbytes < 0 || coffsets_nbytes % (int32_t)sizeof(int64_t) != 0) {
        BLOSC_TRACE_ERROR("Invalid offsets chunk in frame header.");
        return BLOSC2_ERROR_INVALID_HEADER;
      }
      *nchunks = coffsets_nbytes / (int32_t)sizeof(int64_t);
    }
    else {
      BLOSC_TRACE_ERROR("Invalid chunk size in frame header.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
  } else {
    *nchunks = 0;
  }

  if (*nchunks > 0) {
    int32_t off_nbytes;
    if (!blosc2_nchunks_to_offsets_nbytes(*nchunks, &off_nbytes)) {
      BLOSC_TRACE_ERROR("Invalid number of chunks in frame header.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
  }

  return 0;
}


int64_t get_trailer_offset(blosc2_frame_s *frame, int32_t header_len, bool has_coffsets) {
  if (!has_coffsets) {
    // No data chunks yet
    return header_len;
  }
  return frame->len - frame->trailer_len;
}


/* If the on-disk frame length (as just re-read by get_header_info) differs from the
 * cached one, another handle (or process) has rewritten the frame behind our back.
 * Drop the cached offsets index and refresh len/trailer_len so that subsequent
 * accesses re-read the current on-disk state.  In-memory frames cannot go stale
 * this way, and single-handle flows always match, so this is a no-op for them.
 * Returns 1 if a refresh took place, 0 if none was needed, or a negative error. */
static int frame_refresh_if_stale(blosc2_frame_s *frame, int64_t frame_len_on_disk) {
  if (frame->cframe != NULL || frame->schunk == NULL ||
      (!frame->force_refresh && frame_len_on_disk == frame->len)) {
    return 0;
  }
  // Saved so the metalayer-reload retry loop below can roll back to a fully
  // consistent state on exhaustion, rather than leaving frame->len/trailer_len
  // committed to the new value with no metalayers to match it.
  int64_t old_len = frame->len;
  uint32_t old_trailer_len = frame->trailer_len;

  if (frame_len_on_disk < FRAME_HEADER_MINLEN + FRAME_TRAILER_MINLEN) {
    BLOSC_TRACE_ERROR("Invalid on-disk frame length (%" PRId64 ").", frame_len_on_disk);
    return BLOSC2_ERROR_FILE_READ;
  }

  // Read and validate the trailer *before* mutating any frame state below,
  // so a transient torn read (a writer without locking has no coordination
  // preventing a reader from landing mid-rewrite here -- the documented
  // SWMR-without-locking tradeoff) can be handled opportunistically: keep
  // the old cached view and let the next access retry, the same way
  // frame_check_stale()'s header read already does a few lines up in the
  // caller. Once frame->len/coffsets are overwritten below, a failure
  // partway through would leave the frame in a self-inconsistent state
  // (new length, stale trailer/offsets), so those mutations only happen
  // after the trailer is confirmed good.
  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }
  void* fp;
  if (frame->sframe) {
    fp = sframe_open_index(frame->urlpath, "rb", frame->schunk->storage->io);
  }
  else {
    fp = frame_reader_acquire(frame, frame->schunk->storage->io);
  }
  if (fp == NULL) {
    BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
    return BLOSC2_ERROR_FILE_OPEN;
  }
  uint8_t trailer[FRAME_TRAILER_MINLEN];
  uint8_t* trailer_ptr = trailer;
  int64_t io_pos = frame->file_offset + frame_len_on_disk - FRAME_TRAILER_MINLEN;
  int64_t rbytes = io_cb->read((void**)&trailer_ptr, 1, FRAME_TRAILER_MINLEN, io_pos, fp);
  frame_reader_release(frame, io_cb, fp);
  if (rbytes != FRAME_TRAILER_MINLEN) {
    BLOSC_TRACE_ERROR("Cannot read the trailer out of the frame.");
    return 0;  // opportunistic: transient, keep the cached view, retry later
  }
  int trailer_offset = FRAME_TRAILER_MINLEN - FRAME_TRAILER_LEN_OFFSET;
  if (trailer_ptr[trailer_offset - 1] != 0xce) {
    // Not a valid trailer; most likely we are reading a frame in the middle of
    // being rewritten by another handle without locking (locked handles
    // fully serialize, so this only happens under the no-locking contract).
    BLOSC_TRACE_ERROR("Invalid trailer in frame.");
    return 0;  // opportunistic, same reasoning as above
  }
  uint32_t trailer_len;
  from_big(&trailer_len, trailer_ptr + trailer_offset, sizeof(trailer_len));
  if (trailer_len < FRAME_TRAILER_MINLEN || trailer_len > INT32_MAX ||
      (int64_t)trailer_len > frame_len_on_disk - FRAME_HEADER_MINLEN) {
    BLOSC_TRACE_ERROR("Invalid trailer length (%" PRIu32 ") in frame.", trailer_len);
    return 0;  // opportunistic, same reasoning as above
  }

  // Trailer confirmed good: now safe to commit the new length. The lock
  // generation counter (see frame_lock) may have flagged a mutation that
  // left the frame length unchanged; only clear that flag here, once a
  // refresh has actually happened -- clearing it earlier and then bailing
  // out opportunistically above would permanently lose a same-length
  // mutation notification on a torn-read retry. The cached offsets index is
  // dropped further down, only once the metalayer/vlmetalayer reload below
  // has actually succeeded -- neither of those touches frame->coffsets, so
  // deferring this keeps the old view of it fully intact for the
  // opportunistic rollback path below, exactly as strong as the trailer
  // read's own bail-outs above.
  frame->force_refresh = false;
  frame->len = frame_len_on_disk;
  frame->file_end = 0;  // another handle wrote the file; its size is unknown again
  if (frame->nholes > 0) {
    // Nor do we know its free space any more (only an unlocked writer gets here inside frame_begin_updates())
    frame->nholes = 0;
    frame->holes_lost = true;
  }
  frame->trailer_len = trailer_len;

  // The header metalayers and trailer vlmetalayers were cached at open time;
  // reload them so metadata changes made by another handle (e.g. a b2nd shape
  // update) become visible too.  The guard protects against re-entering from
  // the reload path itself (get_header_info does not refresh, but cheap
  // insurance against future changes there).
  //
  // frame_get_metalayers()/frame_get_vlmetalayers() each do their own fully
  // independent header/trailer re-read (separate from the trailer read
  // above), so without locking they can hit the same transient torn-read
  // window. Unlike that trailer read, there's no way to validate first and
  // commit after: schunk_free_metalayers()/schunk_free_vlmetalayers() must
  // run before a reload attempt (the parsers write straight into
  // schunk->metalayers[]/vlmetalayers[] as they go), so a single failed
  // attempt already discards the old cached set. Retry a bounded number of
  // times -- both free helpers are NULL-safe and re-run cleanly against a
  // partial prior attempt, and each attempt is a fresh independent read, so
  // this self-heals once the writer's rewrite stabilizes.
  //
  // This reasoning only holds without locking, though: frame_check_stale()
  // (the only caller) holds the shared frame lock across this entire call
  // when frame->locking is set, which fully excludes writers for its
  // duration -- so under locking a reload failure here cannot be a torn
  // read, it is a genuine problem (corruption or a real I/O error), and
  // retrying 50 times would just waste ~50ms holding that shared lock
  // before silently masking it. Retry once (i.e. don't retry) and propagate
  // the error under locking; keep the opportunistic bounded retry + silent
  // rollback for the no-locking case only.
  //
  // On exhaustion in the no-locking case, roll back frame->len/trailer_len
  // to what they were before this call and force a full retry on the next
  // poll (frame->force_refresh = true) -- otherwise frame_len_on_disk ==
  // frame->len would short-circuit every subsequent call at the top of this
  // function, permanently stranding this handle with an empty metalayer set.
  if (!frame->refreshing) {
    frame->refreshing = true;
    int rc = -1;
    const int max_attempts = frame->locking ? 1 : 50;
    for (int attempt = 0; attempt < max_attempts; attempt++) {
      schunk_free_metalayers(frame->schunk);
      rc = frame_get_metalayers(frame, frame->schunk);
      if (rc >= 0) {
        schunk_free_vlmetalayers(frame->schunk);
        rc = frame_get_vlmetalayers(frame, frame->schunk);
      }
      if (rc >= 0 || attempt + 1 == max_attempts) {
        break;
      }
#if defined(_WIN32)
      Sleep(1);
#else
      usleep(1000);
#endif
    }
    frame->refreshing = false;
    if (rc < 0) {
      if (frame->locking) {
        BLOSC_TRACE_ERROR("Cannot reload the metalayers from the refreshed frame "
                          "(locked handle: this is not a transient race).");
        return rc;
      }
      BLOSC_TRACE_ERROR("Cannot reload the metalayers from the refreshed frame "
                        "after retries; rolling back to the previous cached view.");
      frame->len = old_len;
      frame->trailer_len = old_trailer_len;
      frame->force_refresh = true;
      return 0;
    }
  }
  frame->schunk->change_tick++;

  // Cached offsets index invalidated only now, after a fully successful
  // refresh: recomputed lazily from the fresh trailer on demand.
  if (frame->coffsets != NULL) {
    if (frame->coffsets_needs_free) {
      free(frame->coffsets);
    }
    frame->coffsets = NULL;
  }

  return 1;
}


/* Poll the on-disk frame for staleness; see frame.h.  Mirrors the
 * get_header_info + frame_refresh_if_stale + counter re-sync sequence that
 * read paths like frame_get_chunk perform, but standalone, so upper layers
 * (b2nd geometry checks, vlmeta reads) can sync before trusting cached
 * metadata.  The shared lock makes the sidecar generation counter flag
 * same-length mutations via force_refresh. */
int frame_check_stale(blosc2_frame_s *frame) {
  if (frame == NULL || frame->cframe != NULL || frame->schunk == NULL) {
    return 0;
  }
  if (frame_lock(frame, false) < 0) {
    return BLOSC2_ERROR_LOCK;
  }
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                           &blocksize, &chunksize, &nchunks,
                           NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                           frame->schunk->storage->io);
  if (rc < 0) {
    // The on-disk header cannot be read right now (e.g. a freshly created
    // frame not yet flushed to disk, or another process mid-write).  The
    // poll is opportunistic: keep the cached view, exactly as before polling
    // existed.  A genuinely torn frame still errors out in the data-access
    // paths that need it.
    frame_unlock(frame);
    return 0;
  }
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc > 0) {
    frame->schunk->nbytes = nbytes;
    frame->schunk->cbytes = cbytes;
    frame->schunk->nchunks = nchunks;
  }
  frame_unlock(frame);
  return rc;
}

static int get_coffsets_nbytes(blosc2_frame_s *frame, int32_t header_len, int64_t cbytes,
                               int32_t *coffsets_nbytes, const blosc2_io *io) {
  int32_t chunk_cbytes;
  int rc;
  int64_t off_pos = header_len;
  if (!frame->sframe) {
    if (cbytes < INT64_MAX - header_len) {
      off_pos += cbytes;
    }
  }

  if (off_pos < 0 || off_pos > INT64_MAX - BLOSC_EXTENDED_HEADER_LENGTH ||
      off_pos + BLOSC_EXTENDED_HEADER_LENGTH > frame->len) {
    BLOSC_TRACE_ERROR("Cannot read the offsets outside of frame boundary.");
    return BLOSC2_ERROR_INVALID_HEADER;
  }

  if (frame->cframe != NULL) {
    uint8_t *off_start = frame->cframe + off_pos;
    rc = blosc2_cbuffer_sizes(off_start, coffsets_nbytes, &chunk_cbytes, NULL);
    if (rc < 0) {
      return rc;
    }
    if (chunk_cbytes < 0 || off_pos + chunk_cbytes > frame->len) {
      BLOSC_TRACE_ERROR("Cannot read the cbytes outside of frame boundary.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    return 0;
  }

  int64_t trailer_offset = get_trailer_offset(frame, header_len, true);
  if (trailer_offset < BLOSC_EXTENDED_HEADER_LENGTH || trailer_offset + FRAME_TRAILER_MINLEN > frame->len) {
    BLOSC_TRACE_ERROR("Cannot read the trailer out of the frame.");
    return BLOSC2_ERROR_INVALID_HEADER;
  }

  blosc2_io_cb *io_cb = blosc2_get_io_cb(io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }

  uint8_t header[BLOSC_EXTENDED_HEADER_LENGTH];
  uint8_t *header_ptr = header;
  void *fp = NULL;
  int64_t io_pos = 0;
  if (frame->sframe) {
    fp = sframe_open_index(frame->urlpath, "rb", io);
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      return BLOSC2_ERROR_FILE_OPEN;
    }
    io_pos = off_pos;
  }
  else {
    fp = frame_reader_acquire(frame, io);
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      return BLOSC2_ERROR_FILE_OPEN;
    }
    io_pos = frame->file_offset + off_pos;
  }
  int64_t rbytes = io_cb->read((void**)&header_ptr, 1, BLOSC_EXTENDED_HEADER_LENGTH, io_pos, fp);
  frame_reader_release(frame, io_cb, fp);
  if (rbytes != BLOSC_EXTENDED_HEADER_LENGTH) {
    BLOSC_TRACE_ERROR("Cannot read the offsets header out of the frame.");
    return BLOSC2_ERROR_FILE_READ;
  }

  rc = blosc2_cbuffer_sizes(header_ptr, coffsets_nbytes, &chunk_cbytes, NULL);
  if (rc < 0) {
    return rc;
  }

  if (chunk_cbytes < 0 || off_pos + chunk_cbytes > trailer_offset) {
    BLOSC_TRACE_ERROR("Cannot read the offsets outside of frame boundary.");
    return BLOSC2_ERROR_INVALID_HEADER;
  }

  return 0;
}


// Update the length in the header
int update_frame_len(blosc2_frame_s* frame, int64_t len) {
  int rc = 1;
  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }

  if (frame->cframe != NULL) {
    to_big(frame->cframe + FRAME_LEN, &len, sizeof(int64_t));
  }
  else {
    void* fp = NULL;
    if (frame->sframe) {
      fp = sframe_open_index(frame->urlpath, "rb+",
                             frame->schunk->storage->io);
    }
    else {
      fp = frame_writer_acquire(frame, io_cb);
    }
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      return BLOSC2_ERROR_FILE_OPEN;
    }
    int64_t io_pos = frame->file_offset + FRAME_LEN;
    int64_t swap_len;
    to_big(&swap_len, &len, sizeof(int64_t));
    int64_t wbytes = io_cb->write(&swap_len, 1, sizeof(int64_t), io_pos, fp);
    frame_writer_release(frame, io_cb, fp);
    if (wbytes != sizeof(int64_t)) {
      BLOSC_TRACE_ERROR("Cannot write the frame length in header.");
      return BLOSC2_ERROR_FILE_WRITE;
    }
  }
  return rc;
}


int frame_update_trailer(blosc2_frame_s* frame, blosc2_schunk* schunk) {
  if (frame != NULL && frame->len == 0) {
    BLOSC_TRACE_ERROR("The trailer cannot be updated on empty frames.");
  }

  // Create the trailer in msgpack (see the frame format document)
  uint32_t trailer_len = FRAME_TRAILER_MINLEN;
  uint8_t* trailer = (uint8_t*)calloc((size_t)trailer_len, 1);
  uint8_t* ptrailer = trailer;
  *ptrailer = 0x90 + 4;  // fixarray with 4 elements
  ptrailer += 1;
  // Trailer format version
  *ptrailer = FRAME_TRAILER_VERSION;
  ptrailer += 1;

  int32_t current_trailer_len = (int32_t)(ptrailer - trailer);

  // Now, deal with variable-length metalayers
  int16_t nvlmetalayers = schunk->nvlmetalayers;
  if (nvlmetalayers < 0 || nvlmetalayers > BLOSC2_MAX_METALAYERS) {
    return -1;
  }

  // Make space for the header of metalayers (array marker, size, map of offsets)
  trailer = realloc(trailer, (size_t) current_trailer_len + 1 + 1 + 2 + 1 + 2);
  ptrailer = trailer + current_trailer_len;

  // The msgpack header for the metalayers (array_marker, size, map of offsets, list of metalayers)
  *ptrailer = 0x90 + 3;  // array with 3 elements
  ptrailer += 1;

  int32_t tsize = (int32_t)(ptrailer - trailer);

  // Size for the map (index) of metalayer offsets, including this uint16 size (to be filled out later on)
  *ptrailer = 0xcd;  // uint16
  ptrailer += 1 + 2;

  // Map (index) of offsets for optional metalayers
  *ptrailer = 0xde;  // map 16 with N keys
  ptrailer += 1;
  to_big(ptrailer, &nvlmetalayers, sizeof(nvlmetalayers));
  ptrailer += sizeof(nvlmetalayers);
  current_trailer_len = (int32_t)(ptrailer - trailer);
  int32_t *offtodata = malloc(nvlmetalayers * sizeof(int32_t));
  for (int nvlmetalayer = 0; nvlmetalayer < nvlmetalayers; nvlmetalayer++) {
    if (frame == NULL) {
      return -1;
    }
    blosc2_metalayer *vlmetalayer = schunk->vlmetalayers[nvlmetalayer];
    uint8_t name_len = (uint8_t) strlen(vlmetalayer->name);
    trailer = realloc(trailer, (size_t)current_trailer_len + 1 + name_len + 1 + 4);
    ptrailer = trailer + current_trailer_len;
    // Store the vlmetalayer
    if (name_len >= (1U << 5U)) {  // metalayer strings cannot be longer than 32 bytes
      free(offtodata);
      return -1;
    }
    *ptrailer = (uint8_t)0xa0 + name_len;  // str
    ptrailer += 1;
    memcpy(ptrailer, vlmetalayer->name, name_len);
    ptrailer += name_len;
    // Space for storing the offset for the value of this vlmetalayer
    *ptrailer = 0xd2;  // int32
    ptrailer += 1;
    offtodata[nvlmetalayer] = (int32_t)(ptrailer - trailer);
    ptrailer += 4;
    current_trailer_len += 1 + name_len + 1 + 4;
  }
  int32_t tsize2 = (int32_t)(ptrailer - trailer);
  if (tsize2 != current_trailer_len) {  // sanity check
    return -1;
  }

  // Map size + int16 size
  if ((uint32_t) (tsize2 - tsize) >= (1U << 16U)) {
    return -1;
  }
  uint16_t map_size = (uint16_t) (tsize2 - tsize);
  to_big(trailer + 4, &map_size, sizeof(map_size));

  // Make space for an (empty) array
  tsize = (int32_t)(ptrailer - trailer);
  trailer = realloc(trailer, (size_t) tsize + 2 + 1 + 2);
  ptrailer = trailer + tsize;

  // Now, store the values in an array
  *ptrailer = 0xdc;  // array 16 with N elements
  ptrailer += 1;
  to_big(ptrailer, &nvlmetalayers, sizeof(nvlmetalayers));
  ptrailer += sizeof(nvlmetalayers);
  current_trailer_len = (int32_t)(ptrailer - trailer);
  for (int nvlmetalayer = 0; nvlmetalayer < nvlmetalayers; nvlmetalayer++) {
    if (frame == NULL) {
      return -1;
    }
    blosc2_metalayer *vlmetalayer = schunk->vlmetalayers[nvlmetalayer];
    trailer = realloc(trailer, (size_t)current_trailer_len + 1 + 4 + vlmetalayer->content_len);
    ptrailer = trailer + current_trailer_len;
    // Store the serialized contents for this vlmetalayer
    *ptrailer = 0xc6;  // bin32
    ptrailer += 1;
    to_big(ptrailer, &(vlmetalayer->content_len), sizeof(vlmetalayer->content_len));
    ptrailer += 4;
    memcpy(ptrailer, vlmetalayer->content, vlmetalayer->content_len);  // buffer, no need to swap
    ptrailer += vlmetalayer->content_len;
    // Update the offset now that we know it
    to_big(trailer + offtodata[nvlmetalayer], &current_trailer_len, sizeof(current_trailer_len));
    current_trailer_len += 1 + 4 + vlmetalayer->content_len;
  }
  free(offtodata);
  tsize = (int32_t)(ptrailer - trailer);
  if (tsize != current_trailer_len) {  // sanity check
    return -1;
  }

  trailer = realloc(trailer, (size_t)current_trailer_len + 23);
  ptrailer = trailer + current_trailer_len;
  trailer_len = (ptrailer - trailer) + 23;

  // Trailer length
  *ptrailer = 0xce;  // uint32
  ptrailer += 1;
  to_big(ptrailer, &trailer_len, sizeof(uint32_t));
  ptrailer += sizeof(uint32_t);
  // Up to 16 bytes for frame fingerprint (using XXH3 included in https://github.com/Cyan4973/xxHash)
  // Maybe someone would need 256-bit in the future, but for the time being 128-bit seems like a good tradeoff
  *ptrailer = 0xd8;  // fixext 16
  ptrailer += 1;
  *ptrailer = 0;  // fingerprint type: 0 -> no fp; 1 -> 32-bit; 2 -> 64-bit; 3 -> 128-bit
  ptrailer += 1;

  // Remove call to memset when we compute an actual fingerprint
  memset(ptrailer, 0, 16);
  // Uncomment call to memcpy when we compute an actual fingerprint
  // memcpy(ptrailer, xxh3_fingerprint, sizeof(xxh3_fingerprint));
  ptrailer += 16;

  // Sanity check
  ptrdiff_t actual_trailer_len = ptrailer - trailer;
  if (actual_trailer_len < 0 || (uint64_t)actual_trailer_len != (uint64_t)trailer_len) {
    return BLOSC2_ERROR_DATA;
  }

  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int ret = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                            &blocksize, &chunksize, &nchunks,
                            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                            frame->schunk->storage->io);
  if (ret < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    return ret;
  }

  int64_t trailer_offset = get_trailer_offset(frame, header_len, nbytes > 0);

  if (trailer_offset < BLOSC_EXTENDED_HEADER_LENGTH) {
    BLOSC_TRACE_ERROR("Unable to get trailer offset in frame.");
    return BLOSC2_ERROR_READ_BUFFER;
  }

  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }
  // Update the trailer.  As there are no internal offsets to the trailer section,
  // and it is always at the end of the frame, we can just write (or overwrite) it
  // at the end of the frame.
  if (frame->cframe != NULL) {
    frame->cframe = realloc(frame->cframe, (size_t)(trailer_offset + trailer_len));
    if (frame->cframe == NULL) {
      BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
      free(trailer);
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    memcpy(frame->cframe + trailer_offset, trailer, trailer_len);
  }
  else {
    void* fp = NULL;
    if (frame->sframe) {
      fp = sframe_open_index(frame->urlpath, "rb+",
                             frame->schunk->storage->io);
    }
    else {
      fp = frame_writer_acquire(frame, io_cb);
    }
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      free(trailer);
      return BLOSC2_ERROR_FILE_OPEN;
    }
    int64_t io_pos = frame->file_offset + trailer_offset;
    int64_t wbytes = io_cb->write(trailer, 1, trailer_len, io_pos, fp);
    if (wbytes != trailer_len) {
      BLOSC_TRACE_ERROR("Cannot write the trailer length in trailer.");
      frame->file_end = 0;  // a partial write may have moved the end of the file
      frame_writer_release(frame, io_cb, fp);
      free(trailer);
      return BLOSC2_ERROR_FILE_WRITE;
    }
    int64_t trunc_pos = frame->file_offset + trailer_offset + trailer_len;
    // Only cut the file when the frame really got shorter than it.  A growing
    // frame leaves no stale bytes behind its trailer, and a truncate is never
    // free: on NFS it is a synchronous flush plus a SETATTR round trip, and XFS
    // flushes the file on the next close after any truncate that does not grow
    // it.  Other backends keep truncating unconditionally.
    //
    // file_end is the size we last left the file at.  A write that failed
    // halfway through an earlier update can have left bytes past it, which are
    // then only cut by the next update that shrinks the frame.  That is
    // harmless: the frame length is read from the header, not the file size.
    bool must_truncate = true;
    if (!frame->sframe && frame->schunk->storage->io->id == BLOSC2_IO_FILESYSTEM) {
      if (frame->file_end <= 0) {
        frame->file_end = io_cb->size(fp);  // once per handle; negative on error
      }
      must_truncate = frame->file_end <= 0 || trunc_pos < frame->file_end;
    }
    if (must_truncate && io_cb->truncate(fp, trunc_pos) != 0) {
      BLOSC_TRACE_ERROR("Cannot truncate the frame.");
      frame->file_end = 0;
      frame_writer_release(frame, io_cb, fp);
      free(trailer);
      return BLOSC2_ERROR_FILE_TRUNCATE;
    }
    frame->file_end = trunc_pos;
    frame_writer_release(frame, io_cb, fp);

  }
  free(trailer);

  int rc = update_frame_len(frame, trailer_offset + trailer_len);
  if (rc < 0) {
    return rc;
  }
  frame->len = trailer_offset + trailer_len;
  frame->trailer_len = trailer_len;

  return 1;
}


// Remove a file:/// prefix
// This is a temporary workaround for allowing to use proper URLs for local files/dirs
static char* normalize_urlpath(const char* urlpath) {
  char* localpath = strstr(urlpath, "file:///");
  if (localpath == urlpath) {
    // There is a file:/// prefix.  Get rid of it.
    localpath += strlen("file:///");
  }
  else {
    localpath = (char*)urlpath;
  }
  return localpath;
}


#if defined(BLOSC_TESTING)
/* Deterministic fault injection for the stat()-vs-header transient race
   handled by frame_from_file_offset_retrying() (schunk.c): rather than
   relying on process-scheduling luck to land a real writer's header write
   inside a reader's stat()-to-read window (see tests/test_frame_lock.c,
   test_fork_open_race_update, which tries exactly that and mostly fails to
   land it), simulate the race directly by tampering with the on-disk
   frame_len field between this function's own stat() (already sampled) and
   its header read.  Armed via blosc2_test_arm_open_race(): on the arm_at'th
   call since arming, frame_len is overwritten with a value that exceeds the
   already-sampled file size, forcing the same "frame length exceeds file
   boundary" error a real race produces; the following call restores the
   correct value before its own read, simulating the writer completing its
   extend.  One-shot: disarms itself after firing once.  A no-op when not
   armed (arm_at == 0, the default), so it costs one integer compare on
   builds that don't use it. */
static int g_open_race_arm_at = 0;
static int g_open_race_calls = 0;
static bool g_open_race_pending_restore = false;
static uint8_t g_open_race_saved_len_be[8];

void blosc2_test_arm_open_race(int arm_at) {
  g_open_race_arm_at = arm_at;
  g_open_race_calls = 0;
  g_open_race_pending_restore = false;
}

static void open_race_test_hook(const char* urlpath, int64_t offset) {
  if (g_open_race_arm_at == 0) {
    return;
  }
  g_open_race_calls++;
  FILE* fp = fopen(urlpath, "rb+");
  if (fp == NULL) {
    return;
  }
  if (g_open_race_pending_restore) {
    fseek(fp, offset + FRAME_LEN, SEEK_SET);
    fwrite(g_open_race_saved_len_be, 1, sizeof(g_open_race_saved_len_be), fp);
    g_open_race_pending_restore = false;
    g_open_race_arm_at = 0;
  }
  else if (g_open_race_calls == g_open_race_arm_at) {
    fseek(fp, offset + FRAME_LEN, SEEK_SET);
    if (fread(g_open_race_saved_len_be, 1, sizeof(g_open_race_saved_len_be), fp) ==
        sizeof(g_open_race_saved_len_be)) {
      int64_t real_len;
      to_big(&real_len, g_open_race_saved_len_be, sizeof(real_len));
      int64_t bogus_len = real_len + 10 * 1024 * 1024;
      uint8_t bogus_be[8];
      to_big(bogus_be, &bogus_len, sizeof(bogus_len));
      fseek(fp, offset + FRAME_LEN, SEEK_SET);
      fwrite(bogus_be, 1, sizeof(bogus_be), fp);
      g_open_race_pending_restore = true;
    }
  }
  fclose(fp);
}
#endif  /* BLOSC_TESTING */


/* Initialize a frame out of a file */
blosc2_frame_s* frame_from_file_offset(const char* urlpath, const blosc2_io *io, int64_t offset) {
    // Get the length of the frame
    uint8_t* header_ptr;
    uint8_t header[FRAME_HEADER_MINLEN];
    uint8_t* trailer_ptr;
    uint8_t trailer[FRAME_TRAILER_MINLEN];

    void* fp = NULL;
    char* urlpath_cpy = NULL;
    blosc2_frame_s* frame = NULL;
    bool sframe = false;
    struct stat path_stat;

    urlpath = normalize_urlpath(urlpath);

    if (offset < 0) {
      BLOSC_TRACE_ERROR("Negative frame offset is not valid: %" PRId64 ".", offset);
      return NULL;
    }

    if(stat(urlpath, &path_stat) < 0) {
        BLOSC_TRACE_ERROR("Cannot get information about the path %s.", urlpath);
        return NULL;
    }

#if defined(BLOSC_TESTING)
    open_race_test_hook(urlpath, offset);
#endif

    blosc2_io_cb *io_cb = blosc2_get_io_cb(io->id);
    if (io_cb == NULL) {
        BLOSC_TRACE_ERROR("Error getting the input/output API");
        return NULL;
    }

    if (path_stat.st_mode & S_IFDIR) {
        urlpath_cpy = malloc(strlen(urlpath) + 1);
      if (urlpath_cpy == NULL) {
        BLOSC_TRACE_ERROR("Cannot allocate memory for path copy of '%s'.", urlpath);
        return NULL;
      }
        strcpy(urlpath_cpy, urlpath);
        char last_char = urlpath[strlen(urlpath) - 1];
        if (last_char == '\\' || last_char == '/') {
            urlpath_cpy[strlen(urlpath) - 1] = '\0';
        }
        else {
        }
        fp = sframe_open_index(urlpath_cpy, "rb", io);
        sframe = true;
    }
    else {
        urlpath_cpy = malloc(strlen(urlpath) + 1);
      if (urlpath_cpy == NULL) {
        BLOSC_TRACE_ERROR("Cannot allocate memory for path copy of '%s'.", urlpath);
        return NULL;
      }
        strcpy(urlpath_cpy, urlpath);
        fp = io_cb->open(urlpath, "rb", io->params);
    }
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", urlpath);
      goto failed;
    }

    if (!sframe) {
      // The header is at the start of the file and the trailer and the chunk index at its end: ask for what is read
      // next now, so that both arrive in one round trip instead of one after the other
      prefetch_open_hint(io, fp, offset, (int64_t) path_stat.st_size);
    }

    if (io_cb->is_allocation_necessary)
      header_ptr = header;
    int64_t io_pos = offset;
    int64_t rbytes = io_cb->read((void**)&header_ptr, 1, FRAME_HEADER_MINLEN, io_pos, fp);
    if (rbytes != FRAME_HEADER_MINLEN) {
        BLOSC_TRACE_ERROR("Cannot read from file '%s'.", urlpath);
        goto failed;
    }
    int64_t frame_len;
    to_big(&frame_len, header_ptr + FRAME_LEN, sizeof(frame_len));
    if (frame_len < FRAME_HEADER_MINLEN + FRAME_TRAILER_MINLEN) {
      BLOSC_TRACE_ERROR("Invalid frame length (%" PRId64 ") in file '%s'.", frame_len, urlpath);
      goto failed;
    }

    int64_t file_size = (int64_t) path_stat.st_size;
    if (!sframe) {
      /* Windows CRT stat can report zero for a symlink even though opening it
         follows a nonempty target. The header was readable, so obtain the
         target's size from the open I/O handle in that case. */
      if (file_size == 0) {
        file_size = io_cb->size(fp);
      }
      if (file_size < 0 || offset > file_size || frame_len > file_size - offset) {
        BLOSC_TRACE_ERROR("Frame length exceeds file boundary in file '%s'.", urlpath);
        goto failed;
      }
    }

    if (offset > INT64_MAX - (frame_len - FRAME_TRAILER_MINLEN)) {
      BLOSC_TRACE_ERROR("Frame offset arithmetic overflows in file '%s'.", urlpath);
      goto failed;
    }

    frame = frame_alloc();
    if (frame == NULL) {
      BLOSC_TRACE_ERROR("Cannot allocate memory for frame metadata.");
      goto failed;
    }
    frame->urlpath = urlpath_cpy;
    frame->len = frame_len;
    frame->sframe = sframe;
    frame->file_offset = offset;
    frame->file_end = sframe ? 0 : file_size;

    // Now, the trailer length
    if (io_cb->is_allocation_necessary)
      trailer_ptr = trailer;
    io_pos = offset + frame_len - FRAME_TRAILER_MINLEN;
    rbytes = io_cb->read((void**)&trailer_ptr, 1, FRAME_TRAILER_MINLEN, io_pos, fp);
    if (rbytes != FRAME_TRAILER_MINLEN) {
        BLOSC_TRACE_ERROR("Cannot read from file '%s'.", urlpath);
        goto failed;
    }
    int trailer_offset = FRAME_TRAILER_MINLEN - FRAME_TRAILER_LEN_OFFSET;
    if (trailer_ptr[trailer_offset - 1] != 0xce) {
        BLOSC_TRACE_ERROR("Invalid trailer in file '%s'.", urlpath);
        goto failed;
    }
    uint32_t trailer_len;
    to_big(&trailer_len, trailer_ptr + trailer_offset, sizeof(trailer_len));
    if (trailer_len < FRAME_TRAILER_MINLEN || trailer_len > INT32_MAX ||
        (int64_t)trailer_len > frame_len ||
        (int64_t)trailer_len > frame_len - FRAME_HEADER_MINLEN) {
      BLOSC_TRACE_ERROR("Invalid trailer length (%" PRIu32 ") in file '%s'.", trailer_len, urlpath);
      goto failed;
    }
    frame->trailer_len = trailer_len;
    frame_set_locking(frame, io);
    frame_reader_adopt(frame, io, io_cb, fp);

    return frame;

  failed:
    if (fp != NULL) {
      io_cb->close(fp);
    }
    free(urlpath_cpy);
    if (frame != NULL) {
      blosc2_pthread_mutex_destroy(&frame->read_fp_mutex);
      free(frame);
    }
    return NULL;
}


/* Initialize a frame out of a contiguous frame buffer */
blosc2_frame_s* frame_from_cframe(uint8_t *cframe, int64_t len, bool copy) {
  // Get the length of the frame
  const uint8_t* header = cframe;
  int64_t frame_len;
  if (len < FRAME_HEADER_MINLEN) {
    return NULL;
  }

  from_big(&frame_len, header + FRAME_LEN, sizeof(frame_len));
  if (frame_len != len) {   // sanity check
    return NULL;
  }

  blosc2_frame_s* frame = frame_alloc();
  if (frame == NULL) {
    return NULL;
  }
  frame->len = frame_len;
  frame->file_offset = 0;

  // Now, the trailer length
  const uint8_t* trailer = cframe + frame_len - FRAME_TRAILER_MINLEN;
  int trailer_offset = FRAME_TRAILER_MINLEN - FRAME_TRAILER_LEN_OFFSET;
  if (trailer[trailer_offset - 1] != 0xce) {
    blosc2_pthread_mutex_destroy(&frame->read_fp_mutex);
    free(frame);
    return NULL;
  }
  uint32_t trailer_len;
  from_big(&trailer_len, trailer + trailer_offset, sizeof(trailer_len));
  if (trailer_len < FRAME_TRAILER_MINLEN || trailer_len > INT32_MAX ||
      (int64_t)trailer_len > frame_len ||
      (int64_t)trailer_len > frame_len - FRAME_HEADER_MINLEN) {
    blosc2_pthread_mutex_destroy(&frame->read_fp_mutex);
    free(frame);
    return NULL;
  }
  frame->trailer_len = trailer_len;

  if (copy) {
    frame->cframe = malloc((size_t)len);
    memcpy(frame->cframe, cframe, (size_t)len);
  }
  else {
    frame->cframe = cframe;
    frame->avoid_cframe_free = true;
  }

  return frame;
}


static int32_t compress_offsets(const int64_t* offsets, int32_t off_nbytes, int32_t dest_nbytes,
                                uint8_t** off_chunk);

/* Create a frame out of a super-chunk. */
int64_t frame_from_schunk(blosc2_schunk *schunk, blosc2_frame_s *frame) {
  frame->file_offset = 0;
  int64_t nchunks = schunk->nchunks;
  int64_t cbytes = schunk->cbytes;
  int32_t chunk_cbytes;
  int32_t chunk_nbytes;
  uint64_t* data_tmp = NULL;
  uint8_t* off_chunk = NULL;
  blosc2_io_cb* io_cb = NULL;
  void* fp = NULL;
  int rc;

  uint8_t* h2 = new_header_frame(schunk, frame);
  if (h2 == NULL) {
    return BLOSC2_ERROR_DATA;
  }
  uint32_t h2len;
  from_big(&h2len, h2 + FRAME_HEADER_LEN, sizeof(h2len));
  // Build the offsets chunk
  int32_t chunksize = -1;
  int32_t off_cbytes = 0;
  uint64_t coffset = 0;
  int32_t off_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &off_nbytes)) {
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    rc = BLOSC2_ERROR_DATA;
    goto failed;
  }
  data_tmp = malloc((size_t)off_nbytes);
  if (data_tmp == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for offset data.");
    rc = BLOSC2_ERROR_MEMORY_ALLOC;
    goto failed;
  }
  for (int64_t i = 0; i < nchunks; i++) {
    rc = blosc2_cbuffer_sizes(schunk->data[i], &chunk_nbytes, &chunk_cbytes, NULL);
    if (rc < 0) {
      goto failed;
    }
    data_tmp[i] = coffset;
    coffset += chunk_cbytes;
    if (i == 0) {
      chunksize = chunk_nbytes;
    }
    else if (chunksize != chunk_nbytes) {
      // Variable size  // TODO: update flags for this (or do not use them at all)
      chunksize = 0;
    }
  }
  if ((int64_t)coffset != cbytes) {
    rc = BLOSC2_ERROR_DATA;
    goto failed;
  }
  if (nchunks > 0) {
    off_cbytes = compress_offsets((const int64_t*)data_tmp, off_nbytes, off_nbytes + BLOSC2_MAX_OVERHEAD,
                                  &off_chunk);
    if (off_cbytes < 0) {
      rc = off_cbytes;
      goto failed;
    }
  }
  else {
    off_cbytes = 0;
  }

  // Now that we know them, fill the chunksize and frame length in header
  to_big(h2 + FRAME_CHUNKSIZE, &chunksize, sizeof(chunksize));
  if (chunksize == 0) {
    h2[FRAME_FLAGS] |= FRAME_VARIABLE_CHUNKS;
  }
  else {
    h2[FRAME_FLAGS] &= (uint8_t)~FRAME_VARIABLE_CHUNKS;
  }
  if (schunk->chunksize == 0 || (schunk->flags2 & BLOSC2_VL_BLOCKS)) {
    h2[FRAME_FLAGS] = (uint8_t)((h2[FRAME_FLAGS] & (uint8_t)~0x0fu) | BLOSC2_VERSION_FRAME_FORMAT_VL_BLOCKS);
    h2[FRAME_FLAGS] |= FRAME_VL_BLOCKS;
  }
  else {
    h2[FRAME_FLAGS] = (uint8_t)((h2[FRAME_FLAGS] & (uint8_t)~0x0fu) | BLOSC2_VERSION_FRAME_FORMAT_RC1);
    h2[FRAME_FLAGS] &= (uint8_t)~FRAME_VL_BLOCKS;
  }
  frame->len = h2len + cbytes + off_cbytes + FRAME_TRAILER_MINLEN;
  if (frame->sframe) {
    frame->len = h2len + off_cbytes + FRAME_TRAILER_MINLEN;
  }
  int64_t tbytes = frame->len;
  to_big(h2 + FRAME_LEN, &tbytes, sizeof(tbytes));

  const blosc2_io* io = frame->schunk->storage->io;
  io_cb = blosc2_get_io_cb(io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    rc = BLOSC2_ERROR_PLUGIN_IO;
    goto failed;
  }

  // Create the frame and put the header at the beginning
  int64_t io_pos = 0;
  if (frame->urlpath == NULL) {
    frame->cframe = malloc((size_t)frame->len);
    memcpy(frame->cframe, h2, h2len);
  }
  else {
    if (frame->sframe) {
      fp = sframe_open_index(frame->urlpath, "wb", io);
    }
    else {
      // The file is about to be recreated from scratch; drop any cached reader
      frame_reader_invalidate(frame);
      // Where the handle can stay open as the cached writer (which is "rb+"
      // everywhere else), open it readable too
      fp = io_cb->open(frame->urlpath, reader_cacheable(io) ? "wb+" : "wb", io->params);
    }
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error creating file in: %s", frame->urlpath);
      rc = BLOSC2_ERROR_FILE_OPEN;
      goto failed;
    }
    io_cb->write(h2, h2len, 1, io_pos, fp);
    io_pos += h2len;
  }

  // Fill the frame with the actual data chunks
  if (!frame->sframe) {
    coffset = 0;
    for (int64_t i = 0; i < nchunks; i++) {
      uint8_t* data_chunk = schunk->data[i];
      rc = blosc2_cbuffer_sizes(data_chunk, NULL, &chunk_cbytes, NULL);
      if (rc < 0) {
        goto failed;
      }
      if (frame->urlpath == NULL) {
        memcpy(frame->cframe + h2len + coffset, data_chunk, (size_t)chunk_cbytes);
      } else {
        io_cb->write(data_chunk, chunk_cbytes, 1, io_pos, fp);
        io_pos += chunk_cbytes;
      }
      coffset += chunk_cbytes;
    }
    if ((int64_t)coffset != cbytes) {
      rc = BLOSC2_ERROR_FAILURE;
      goto failed;
    }
  }

  // Copy the offsets chunk at the end of the frame (there is none without chunks)
  if (frame->urlpath == NULL) {
    if (off_cbytes > 0) {
      memcpy(frame->cframe + h2len + cbytes, off_chunk, off_cbytes);
    }
  }
  else {
    if (off_cbytes > 0) {
      io_cb->write(off_chunk, off_cbytes, 1, io_pos, fp);
    }
    // Only a handle opened readable above can be adopted
    if (!frame_writer_adopt(frame, io, fp)) {
      io_cb->close(fp);
    }
    fp = NULL;
    // The file was created from scratch, so its size is exactly what we wrote
    frame->file_end = frame->sframe ? 0 : io_pos + off_cbytes;
  }
  free(off_chunk);
  free(data_tmp);
  free(h2);
  rc = frame_update_trailer(frame, schunk);
  if (rc < 0) {
    return rc;
  }

  return frame->len;

  failed:
  if (fp != NULL) {
    io_cb->close(fp);
  }
  free(off_chunk);
  free(data_tmp);
  free(h2);
  return rc;
}


// Get the compressed data offsets
uint8_t* get_coffsets(blosc2_frame_s *frame, int32_t header_len, int64_t cbytes,
                      int64_t nchunks, int32_t *off_cbytes) {
  int32_t chunk_cbytes;
  int rc;

  if (frame->coffsets != NULL) {
    if (off_cbytes != NULL) {
      rc = blosc2_cbuffer_sizes(frame->coffsets, NULL, &chunk_cbytes, NULL);
      if (rc < 0) {
        return NULL;
      }
      *off_cbytes = (int32_t)chunk_cbytes;
    }
    return frame->coffsets;
  }
  if (frame->cframe != NULL) {
    int64_t off_pos = header_len;
    if (cbytes < INT64_MAX - header_len) {
      off_pos += cbytes;
    }
    // Check that there is enough room to read Blosc header
    if (off_pos < 0 || off_pos > INT64_MAX - BLOSC_EXTENDED_HEADER_LENGTH ||
        off_pos + BLOSC_EXTENDED_HEADER_LENGTH > frame->len) {
      BLOSC_TRACE_ERROR("Cannot read the offsets outside of frame boundary.");
      return NULL;
    }
    // For in-memory frames, the coffset is just one pointer away
    uint8_t* off_start = frame->cframe + off_pos;
    if (off_cbytes != NULL) {
      int32_t chunk_nbytes;
      int32_t chunk_blocksize;
      rc = blosc2_cbuffer_sizes(off_start, &chunk_nbytes, &chunk_cbytes, &chunk_blocksize);
      if (rc < 0) {
        return NULL;
      }
      *off_cbytes = (int32_t)chunk_cbytes;
      if (*off_cbytes < 0 || off_pos + *off_cbytes > frame->len) {
        BLOSC_TRACE_ERROR("Cannot read the cbytes outside of frame boundary.");
        return NULL;
      }
      int32_t expected_off_nbytes;
      if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &expected_off_nbytes)) {
        BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
        return NULL;
      }
      if (chunk_nbytes != expected_off_nbytes) {
        BLOSC_TRACE_ERROR("The number of chunks in offset idx "
                          "does not match the ones in the header frame.");
        return NULL;
      }

    }
    return off_start;
  }

  int64_t trailer_offset = get_trailer_offset(frame, header_len, true);

  if (trailer_offset < BLOSC_EXTENDED_HEADER_LENGTH || trailer_offset + FRAME_TRAILER_MINLEN > frame->len) {
    BLOSC_TRACE_ERROR("Cannot read the trailer out of the frame.");
    return NULL;
  }

  int64_t coffsets_cbytes64;
  if (frame->sframe) {
    coffsets_cbytes64 = trailer_offset - header_len;
  }
  else {
    coffsets_cbytes64 = trailer_offset - (header_len + cbytes);
  }
  if (coffsets_cbytes64 <= 0 || coffsets_cbytes64 > INT32_MAX) {
    BLOSC_TRACE_ERROR("Offsets chunk size is out of bounds.");
    return NULL;
  }
  int32_t coffsets_cbytes = (int32_t)coffsets_cbytes64;

  if (off_cbytes != NULL) {
    *off_cbytes = coffsets_cbytes;
  }

  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return NULL;
  }

  void* fp = NULL;
  uint8_t* coffsets;
  if (io_cb->is_allocation_necessary) {
    coffsets = malloc((size_t)coffsets_cbytes);
    frame->coffsets_needs_free = true;
  }
  else {
    frame->coffsets_needs_free = false;
  }

  int64_t io_pos = 0;
  if (frame->sframe) {
    fp = sframe_open_index(frame->urlpath, "rb",
                           frame->schunk->storage->io);
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      return NULL;
    }
    io_pos = header_len + 0;
  }
  else {
    fp = frame_reader_acquire(frame, frame->schunk->storage->io);
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      return NULL;
    }
    io_pos = frame->file_offset + header_len + cbytes;
  }
  int64_t rbytes = io_cb->read((void**)&coffsets, 1, coffsets_cbytes, io_pos, fp);
  frame_reader_release(frame, io_cb, fp);
  if (rbytes != coffsets_cbytes) {
    BLOSC_TRACE_ERROR("Cannot read the offsets out of the frame.");
    if (frame->coffsets_needs_free)
      free(coffsets);
    return NULL;
  }
  frame->coffsets = coffsets;
  return coffsets;
}


// Get the data offsets from a frame
int64_t* blosc2_frame_get_offsets(blosc2_schunk *schunk) {
  if (schunk->frame == NULL) {
    BLOSC_TRACE_ERROR("This function needs a frame.");
    return NULL;
  }
  blosc2_frame_s* frame = (blosc2_frame_s*)schunk->frame;

  // Get header info
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int ret = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                            &blocksize, &chunksize, &nchunks,
                            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                            frame->schunk->storage->io);
  if (ret < 0) {
    BLOSC_TRACE_ERROR("Cannot get the header info for the frame.");
    return NULL;
  }

  int32_t off_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &off_nbytes)) {
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    return NULL;
  }
  int64_t* offsets = (int64_t *) malloc((size_t)off_nbytes);
  if (offsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for offsets.");
    return NULL;
  }

  int32_t coffsets_cbytes = 0;
  uint8_t *coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
  // Decompress offsets
  blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
  blosc2_context *dctx = blosc2_create_dctx(off_dparams);
  if (dctx == NULL) {
    BLOSC_TRACE_ERROR("Error while creating the decompression context");
    return NULL;
  }
  int32_t prev_nbytes = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes,
                                              offsets, off_nbytes);
  blosc2_free_ctx(dctx);
  if (prev_nbytes < 0) {
    free(offsets);
    BLOSC_TRACE_ERROR("Cannot decompress the offsets chunk.");
    return NULL;
  }
  return offsets;
}


int frame_update_header(blosc2_frame_s* frame, blosc2_schunk* schunk, bool new) {
  uint8_t* framep = frame->cframe;
  uint8_t* header_ptr;
  uint8_t header[FRAME_HEADER_MINLEN];

  if (frame->len <= 0) {
    return BLOSC2_ERROR_INVALID_PARAM;
  }

  if (new && schunk->cbytes > 0) {
    BLOSC_TRACE_ERROR("New metalayers cannot be added after actual data "
                      "has been appended.");
    return BLOSC2_ERROR_INVALID_PARAM;
  }

  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }

  if (frame->cframe == NULL) {
    int64_t rbytes = 0;
    void* fp = NULL;
    int64_t io_pos = 0;
    if (frame->sframe) {
      fp = sframe_open_index(frame->urlpath, "rb+",
                             frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
    }
    else {
      frame_reader_revalidate(frame);
      fp = frame_reader_acquire(frame, frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset;
    }
    if (fp != NULL) {
      if (io_cb->is_allocation_necessary)
        header_ptr = header;
      rbytes = io_cb->read((void**)&header_ptr, 1, FRAME_HEADER_MINLEN, io_pos, fp);
      frame_reader_release(frame, io_cb, fp);
    }
    (void) rbytes;
    if (rbytes != FRAME_HEADER_MINLEN) {
      return BLOSC2_ERROR_FILE_WRITE;
    }
    framep = header_ptr;
  }
  uint32_t prev_h2len;
  from_big(&prev_h2len, framep + FRAME_HEADER_LEN, sizeof(prev_h2len));

  // Build a new header
  uint8_t* h2 = new_header_frame(schunk, frame);
  if (h2 == NULL) {
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }
  uint32_t h2len;
  from_big(&h2len, h2 + FRAME_HEADER_LEN, sizeof(h2len));

  // The frame length is outdated when adding a new metalayer, so update it
  if (new) {
    int64_t frame_len = h2len;  // at adding time, we only have to worry of the header for now
    to_big(h2 + FRAME_LEN, &frame_len, sizeof(frame_len));
    frame->len = frame_len;
  }

  if (!new && prev_h2len != h2len) {
    BLOSC_TRACE_ERROR("The new metalayer sizes should be equal the existing ones.");
    free(h2);
    return BLOSC2_ERROR_DATA;
  }

  void* fp = NULL;
  if (frame->cframe == NULL) {
    // Write updated header down to file
    if (frame->sframe) {
      fp = sframe_open_index(frame->urlpath, "rb+",
                             frame->schunk->storage->io);
    }
    else {
      fp = frame_writer_acquire(frame, io_cb);
    }
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      free(h2);
      return BLOSC2_ERROR_FILE_OPEN;
    }
    int64_t io_pos = frame->file_offset;
    io_cb->write(h2, h2len, 1, io_pos, fp);
    frame_writer_release(frame, io_cb, fp);
  }
  else {
    if (new) {
      void *new_cframe = realloc(frame->cframe, h2len);
      if (new_cframe == NULL) {
        free(h2);
        return BLOSC2_ERROR_MEMORY_ALLOC;
      }
      frame->cframe = new_cframe;
    }
    memcpy(frame->cframe, h2, h2len);
  }
  free(h2);

  return 1;
}


static int get_meta_from_header(blosc2_frame_s* frame, blosc2_schunk* schunk, uint8_t* header,
                                int32_t header_len) {
  BLOSC_UNUSED_PARAM(frame);
  int64_t header_pos = FRAME_IDX_SIZE;

  // Get the size for the index of metalayers
  uint16_t idx_size;
  header_pos += sizeof(idx_size);
  if (header_len < header_pos) {
    return BLOSC2_ERROR_READ_BUFFER;
  }
  from_big(&idx_size, header + FRAME_IDX_SIZE, sizeof(idx_size));

  // Get the actual index of metalayers
  uint8_t* metalayers_idx = header + FRAME_IDX_SIZE + 2;
  header_pos += 1;
  if (header_len < header_pos) {
    return BLOSC2_ERROR_READ_BUFFER;
  }
  if (metalayers_idx[0] != 0xde) {   // sanity check
    return BLOSC2_ERROR_DATA;
  }
  uint8_t* idxp = metalayers_idx + 1;
  uint16_t nmetalayers;
  header_pos += sizeof(nmetalayers);
  if (header_len < header_pos) {
    return BLOSC2_ERROR_READ_BUFFER;
  }
  from_big(&nmetalayers, idxp, sizeof(uint16_t));
  idxp += 2;
  if (nmetalayers > BLOSC2_MAX_METALAYERS) {
    return BLOSC2_ERROR_DATA;
  }
  schunk->nmetalayers = nmetalayers;

  // Populate the metalayers and its serialized values
  for (int nmetalayer = 0; nmetalayer < nmetalayers; nmetalayer++) {
    header_pos += 1;
    if (header_len < header_pos) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    if ((*idxp & 0xe0u) != 0xa0u) {   // sanity check
      return BLOSC2_ERROR_DATA;
    }
    blosc2_metalayer* metalayer = calloc(1, sizeof(blosc2_metalayer));
    if (metalayer == NULL) {
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    schunk->metalayers[nmetalayer] = metalayer;

    // Populate the metalayer string
    uint8_t nslen = *idxp & (uint8_t)0x1F;
    idxp += 1;
    header_pos += nslen;
    if (header_len < header_pos) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    char* ns = malloc((size_t)nslen + 1);
    if (ns == NULL) {
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    memcpy(ns, idxp, nslen);
    ns[nslen] = '\0';
    idxp += nslen;
    metalayer->name = ns;

    // Populate the serialized value for this metalayer
    // Get the offset
    header_pos += 1;
    if (header_len < header_pos) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    if ((*idxp & 0xffu) != 0xd2u) {   // sanity check
      return BLOSC2_ERROR_DATA;
    }
    idxp += 1;
    int32_t offset;
    header_pos += sizeof(offset);
    if (header_len < header_pos) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    from_big(&offset, idxp, sizeof(offset));
    idxp += 4;
    if (offset < 0 || offset >= header_len) {
      // Offset is less than zero or exceeds header length
      return BLOSC2_ERROR_DATA;
    }
    // Go to offset and see if we have the correct marker
    uint8_t* content_marker = header + offset;
    if ((int64_t)header_len < (int64_t)offset + 1 + 4) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    if (*content_marker != 0xc6) {
      return BLOSC2_ERROR_DATA;
    }

    // Read the size of the content
    int32_t content_len;
    from_big(&content_len, content_marker + 1, sizeof(content_len));
    if (content_len < 0) {
      return BLOSC2_ERROR_DATA;
    }
    metalayer->content_len = content_len;

    // Finally, read the content. Use 64-bit arithmetic so a malicious
    // (offset, content_len) pair near INT32_MAX cannot wrap and bypass the
    // bounds check, which would let memcpy below read past the header buffer.
    if ((int64_t)header_len < (int64_t)offset + 1 + 4 + (int64_t)content_len) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    char* content = malloc((size_t)content_len);
    // malloc(0) is allowed to return NULL, and blosc2_meta_add accepts
    // content_len == 0, so only treat NULL as an allocation failure when
    // a non-zero allocation was requested.
    if (content_len > 0 && content == NULL) {
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    if (content_len > 0) {
      memcpy(content, content_marker + 1 + 4, (size_t)content_len);
    }
    metalayer->content = (uint8_t*)content;
  }

  return 1;
}

int frame_get_metalayers(blosc2_frame_s* frame, blosc2_schunk* schunk) {
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int ret = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                            &blocksize, &chunksize, &nchunks,
                            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                            schunk->storage->io);
  if (ret < 0) {
    BLOSC_TRACE_ERROR("Unable to get the header info from frame.");
    return ret;
  }

  // Get the header
  uint8_t* header = NULL;
  bool needs_free = false;
  if (frame->cframe != NULL) {
    header = frame->cframe;
  } else {
    int64_t rbytes = 0;
    blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      return BLOSC2_ERROR_PLUGIN_IO;
    }

    if (io_cb->is_allocation_necessary) {
      header = malloc(header_len);
      needs_free = true;
    }
    else {
      needs_free = false;
    }

    void* fp = NULL;
    int64_t io_pos = 0;
    if (frame->sframe) {
      fp = sframe_open_index(frame->urlpath, "rb",
                             frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
    }
    else {
      fp = frame_reader_acquire(frame, frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset;
    }
    if (fp != NULL) {
      rbytes = io_cb->read((void**)&header, 1, header_len, io_pos, fp);
      frame_reader_release(frame, io_cb, fp);
    }
    if (rbytes != header_len) {
      BLOSC_TRACE_ERROR("Cannot access the header out of the frame.");
      if (needs_free)
        free(header);
      return BLOSC2_ERROR_FILE_READ;
    }
  }

  ret = get_meta_from_header(frame, schunk, header, header_len);

  if (frame->cframe == NULL && needs_free) {
    free(header);
  }

  return ret;
}

static int get_vlmeta_from_trailer(blosc2_frame_s* frame, blosc2_schunk* schunk, uint8_t* trailer,
                                   int32_t trailer_len) {

  BLOSC_UNUSED_PARAM(frame);
  int64_t trailer_pos = FRAME_TRAILER_VLMETALAYERS + 2;
  uint8_t* idxp = trailer + trailer_pos;

  // Get the size for the index of metalayers
  trailer_pos += 2;
  if (trailer_len < trailer_pos) {
    return BLOSC2_ERROR_READ_BUFFER;
  }
  uint16_t idx_size;
  from_big(&idx_size, idxp, sizeof(idx_size));
  idxp += 2;

  trailer_pos += 1;
  // Get the actual index of metalayers
  if (trailer_len < trailer_pos) {
    return BLOSC2_ERROR_READ_BUFFER;
  }
  if (idxp[0] != 0xde) {   // sanity check
    return BLOSC2_ERROR_DATA;
  }
  idxp += 1;

  // The on-wire encoding is unsigned (uint16 follows the msgpack `0xde`
  // map16 marker), but `schunk->nvlmetalayers` is int16_t. Decoding into a
  // signed local would let raw bytes like 0xff 0xff slip past the
  // `> BLOSC2_MAX_VLMETALAYERS` ceiling as a negative count, after which
  // a later `blosc2_vlmeta_add` would write through `vlmetalayers[-1]`
  // and corrupt adjacent schunk fields. Decode unsigned, then narrow.
  uint16_t nmetalayers;
  trailer_pos += sizeof(nmetalayers);
  if (trailer_len < trailer_pos) {
    return BLOSC2_ERROR_READ_BUFFER;
  }
  from_big(&nmetalayers, idxp, sizeof(uint16_t));
  idxp += 2;
  if (nmetalayers > BLOSC2_MAX_VLMETALAYERS) {
    return BLOSC2_ERROR_DATA;
  }
  schunk->nvlmetalayers = (int16_t)nmetalayers;

  // Populate the metalayers and its serialized values
  for (int nmetalayer = 0; nmetalayer < nmetalayers; nmetalayer++) {
    trailer_pos += 1;
    if (trailer_len < trailer_pos) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    if ((*idxp & 0xe0u) != 0xa0u) {   // sanity check
      return BLOSC2_ERROR_DATA;
    }
    blosc2_metalayer* metalayer = calloc(1, sizeof(blosc2_metalayer));
    if (metalayer == NULL) {
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    schunk->vlmetalayers[nmetalayer] = metalayer;

    // Populate the metalayer string
    uint8_t nslen = *idxp & (uint8_t)0x1F;
    idxp += 1;
    trailer_pos += nslen;
    if (trailer_len < trailer_pos) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    char* ns = malloc((size_t)nslen + 1);
    if (ns == NULL) {
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    memcpy(ns, idxp, nslen);
    ns[nslen] = '\0';
    idxp += nslen;
    metalayer->name = ns;

    // Populate the serialized value for this metalayer
    // Get the offset
    trailer_pos += 1;
    if (trailer_len < trailer_pos) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    if ((*idxp & 0xffu) != 0xd2u) {   // sanity check
      return BLOSC2_ERROR_DATA;
    }
    idxp += 1;
    int32_t offset;
    trailer_pos += sizeof(offset);
    if (trailer_len < trailer_pos) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    from_big(&offset, idxp, sizeof(offset));
    idxp += 4;
    if (offset < 0 || offset >= trailer_len) {
      // Offset is less than zero or exceeds trailer length
      return BLOSC2_ERROR_DATA;
    }
    // Go to offset and see if we have the correct marker
    uint8_t* content_marker = trailer + offset;
    if ((int64_t)trailer_len < (int64_t)offset + 1 + 4) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    if (*content_marker != 0xc6) {
      return BLOSC2_ERROR_DATA;
    }

    // Read the size of the content
    int32_t content_len;
    from_big(&content_len, content_marker + 1, sizeof(content_len));
    if (content_len < 0) {
      return BLOSC2_ERROR_DATA;
    }
    metalayer->content_len = content_len;

    // Finally, read the content. Use 64-bit arithmetic so a malicious
    // (offset, content_len) pair near INT32_MAX cannot wrap and bypass the
    // bounds check, which would let memcpy below read past the trailer buffer.
    if ((int64_t)trailer_len < (int64_t)offset + 1 + 4 + (int64_t)content_len) {
      return BLOSC2_ERROR_READ_BUFFER;
    }
    char* content = malloc((size_t)content_len);
    // Same zero-length carve-out as in get_meta_from_header: malloc(0) may
    // return NULL on some platforms, and the public API allows
    // content_len == 0, so don't reject a valid empty vlmetalayer.
    if (content_len > 0 && content == NULL) {
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    if (content_len > 0) {
      memcpy(content, content_marker + 1 + 4, (size_t)content_len);
    }
    metalayer->content = (uint8_t*)content;
  }
  return 1;
}

int frame_get_vlmetalayers(blosc2_frame_s* frame, blosc2_schunk* schunk) {
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int ret = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                            &blocksize, &chunksize, &nchunks,
                            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                            schunk->storage->io);
  if (ret < 0) {
    BLOSC_TRACE_ERROR("Unable to get the trailer info from frame.");
    return ret;
  }

  int64_t trailer_offset = get_trailer_offset(frame, header_len, nbytes > 0);
  int32_t trailer_len = (int32_t) frame->trailer_len;

  if (trailer_offset < BLOSC_EXTENDED_HEADER_LENGTH || trailer_offset + trailer_len > frame->len) {
    BLOSC_TRACE_ERROR("Cannot access the trailer out of the frame.");
    return BLOSC2_ERROR_READ_BUFFER;
  }

  // Get the trailer
  uint8_t* trailer = NULL;
  bool needs_free = false;
  if (frame->cframe != NULL) {
    trailer = frame->cframe + trailer_offset;
  } else {
    int64_t rbytes = 0;

    blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      return BLOSC2_ERROR_PLUGIN_IO;
    }

    if (io_cb->is_allocation_necessary) {
      trailer = malloc(trailer_len);
      needs_free = true;
    }
    else {
      needs_free = false;
    }

    void* fp = NULL;
    int64_t io_pos = 0;
    if (frame->sframe) {
      // Check for overflow before calculating length
      if (strlen(frame->urlpath) > SIZE_MAX - strlen("/chunks.b2frame") - 1) {
        BLOSC_TRACE_ERROR("Path too long for frame filename.");
        if (needs_free) free(trailer);
        return BLOSC2_ERROR_INVALID_PARAM;
      }
      size_t _len = strlen(frame->urlpath) + strlen("/chunks.b2frame") + 1;
      char* eframe_name = malloc(_len);
      if (eframe_name == NULL) {
        BLOSC_TRACE_ERROR("Unable to allocate memory for frame filename.");
        if (needs_free) free(trailer);
        return BLOSC2_ERROR_MEMORY_ALLOC;
      }
      int _w = snprintf(eframe_name, _len, "%s/chunks.b2frame", frame->urlpath);
      if (_w < 0 || (size_t)_w >= _len) {
        BLOSC_TRACE_ERROR("Error building frame filename");
        free(eframe_name);
        if (needs_free) free(trailer);
        return BLOSC2_ERROR_INVALID_PARAM;
      }
      fp = io_cb->open(eframe_name, "rb", frame->schunk->storage->io->params);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", eframe_name);
        free(eframe_name);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      free(eframe_name);
      io_pos = trailer_offset;
    }
    else {
      fp = frame_reader_acquire(frame, frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset + trailer_offset;
    }
    if (fp != NULL) {
      rbytes = io_cb->read((void**)&trailer, 1, trailer_len, io_pos, fp);
      frame_reader_release(frame, io_cb, fp);
    }
    if (rbytes != trailer_len) {
      BLOSC_TRACE_ERROR("Cannot access the trailer out of the fileframe.");
      if (needs_free)
        free(trailer);
      return BLOSC2_ERROR_FILE_READ;
    }
  }

  ret = get_vlmeta_from_trailer(frame, schunk, trailer, trailer_len);

  if (frame->cframe == NULL && needs_free) {
    free(trailer);
  }

  return ret;
}


blosc2_storage* get_new_storage(const blosc2_storage* storage,
                                const blosc2_cparams* cdefaults,
                                const blosc2_dparams* ddefaults,
                                const blosc2_io* iodefaults) {

  blosc2_storage* new_storage = (blosc2_storage*)calloc(1, sizeof(blosc2_storage));
  memcpy(new_storage, storage, sizeof(blosc2_storage));
  if (storage->urlpath != NULL) {
    char* urlpath = normalize_urlpath(storage->urlpath);
    new_storage->urlpath = malloc(strlen(urlpath) + 1);
    strcpy(new_storage->urlpath, urlpath);
  }

  // cparams
  blosc2_cparams* cparams = malloc(sizeof(blosc2_cparams));
  if (storage->cparams != NULL) {
    memcpy(cparams, storage->cparams, sizeof(blosc2_cparams));
  } else {
    memcpy(cparams, cdefaults, sizeof(blosc2_cparams));
  }
  new_storage->cparams = cparams;

  // dparams
  blosc2_dparams* dparams = malloc(sizeof(blosc2_dparams));
  if (storage->dparams != NULL) {
    memcpy(dparams, storage->dparams, sizeof(blosc2_dparams));
  }
  else {
    memcpy(dparams, ddefaults, sizeof(blosc2_dparams));
  }
  new_storage->dparams = dparams;

  // iodefaults
  blosc2_io* udio = malloc(sizeof(blosc2_io));
  if (storage->io != NULL) {
    memcpy(udio, storage->io, sizeof(blosc2_io));
  }
  else {
    memcpy(udio, iodefaults, sizeof(blosc2_io));
  }
  new_storage->io = udio;

  return new_storage;
}


static int validate_offsets_chunk(blosc2_frame_s* frame, int32_t header_len, int64_t cbytes,
                                  int64_t nchunks) {
  int32_t coffsets_cbytes = 0;
  uint8_t* coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
  if (coffsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot get compressed offsets from frame.");
    return BLOSC2_ERROR_DATA;
  }

  int32_t offsets_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &offsets_nbytes)) {
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    return BLOSC2_ERROR_FAILURE;
  }

  int64_t* offsets = (int64_t*)malloc((size_t)offsets_nbytes);
  if (offsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for offsets validation.");
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }

  blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
  blosc2_context* dctx = blosc2_create_dctx(off_dparams);
  if (dctx == NULL) {
    free(offsets);
    BLOSC_TRACE_ERROR("Error while creating the decompression context.");
    return BLOSC2_ERROR_FAILURE;
  }

  int32_t off_nbytes = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes,
                                             offsets, offsets_nbytes);
  blosc2_free_ctx(dctx);
  if (off_nbytes != offsets_nbytes) {
    free(offsets);
    BLOSC_TRACE_ERROR("Cannot decompress offsets chunk.");
    return BLOSC2_ERROR_DATA;
  }

  for (int64_t i = 0; i < nchunks; ++i) {
    int64_t offset = offsets[i];
    if (offset < 0) {
      continue;
    }
    if (offset > INT64_MAX - header_len || offset > cbytes - BLOSC_EXTENDED_HEADER_LENGTH) {
      free(offsets);
      BLOSC_TRACE_ERROR("Offset for chunk %" PRId64 " is out of bounds.", i);
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    /* Offsets do not need to be monotonic.  Frame mutations like insert can append
     * chunk payloads at the end of the cframe while updating the logical chunk order
     * only in the offsets table, so a valid frame may legitimately contain
     * non-monotonic non-negative offsets.
     */
  }

  free(offsets);
  return 0;
}


/* Get a super-chunk out of a frame */
blosc2_schunk* frame_to_schunk(blosc2_frame_s* frame, bool copy, const blosc2_io *udio) {
  int32_t header_len;
  int64_t frame_len;
  int rc;
  bool frame_attached = true;
  blosc2_schunk* schunk = calloc(1, sizeof(blosc2_schunk));
  blosc2_cparams *cparams = NULL;
  blosc2_dparams *dparams = NULL;
  int64_t *offsets = NULL;
  if (schunk == NULL) {
    return NULL;
  }
  schunk->frame = (blosc2_frame*)frame;
  frame->schunk = schunk;

  rc = get_header_info(frame, &header_len, &frame_len, &schunk->nbytes,
                       &schunk->cbytes, &schunk->blocksize,
                       &schunk->chunksize, &schunk->nchunks, &schunk->typesize,
                       &schunk->compcode, &schunk->compcode_meta, &schunk->clevel, schunk->filters,
                       schunk->filters_meta, &schunk->splitmode, &schunk->use_dict, udio);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    goto error;
  }
  int64_t nchunks = schunk->nchunks;
  int64_t nbytes = schunk->nbytes;
  (void) nbytes;
  int64_t cbytes = schunk->cbytes;

  // Compression and decompression contexts
  blosc2_schunk_get_cparams(schunk, &cparams);
  schunk->cctx = blosc2_create_cctx(*cparams);
  if (schunk->cctx == NULL) {
    BLOSC_TRACE_ERROR("Error while creating the compression context");
    goto error;
  }
  blosc2_schunk_get_dparams(schunk, &dparams);
  schunk->dctx = blosc2_create_dctx(*dparams);
  if (schunk->dctx == NULL) {
    BLOSC_TRACE_ERROR("Error while creating the decompression context");
    goto error;
  }
  blosc2_storage storage = {.contiguous = copy ? false : true};
  schunk->storage = get_new_storage(&storage, cparams, dparams, udio);
  free(cparams);
  cparams = NULL;
  free(dparams);
  dparams = NULL;
  if (nchunks > 0) {
    rc = validate_offsets_chunk(frame, header_len, cbytes, nchunks);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Cannot validate frame offsets.");
      goto error;
    }
  }
  if (nchunks > 0) {
    uint8_t *chunk;
    bool needs_free;
    // A lazy chunk is enough here: only the header is needed for the flags2 byte
    rc = frame_get_lazychunk(frame, 0, &chunk, &needs_free);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Cannot inspect the first chunk in frame.");
      goto error;
    }
    schunk->flags2 = (rc >= BLOSC_EXTENDED_HEADER_LENGTH) ? chunk[BLOSC2_CHUNK_BLOSC2_FLAGS2] : 0;
    if (needs_free) {
      free(chunk);
    }
  }
  if (!copy) {
    goto out;
  }

  // We are not attached to a frame anymore
  schunk->frame = NULL;
  frame_attached = false;

  if (nchunks == 0) {
    frame->schunk = NULL;
    goto out;
  }

  // Get the compressed offsets
  int32_t coffsets_cbytes = 0;
  uint8_t* coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
  if (coffsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot get the offsets for the frame.");
    goto error;
  }

  // Decompress offsets
  blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
  blosc2_context *dctx = blosc2_create_dctx(off_dparams);
  if (dctx == NULL) {
    BLOSC_TRACE_ERROR("Error while creating the decompression context");
    goto error;
  }
  int32_t offsets_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &offsets_nbytes)) {
    blosc2_free_ctx(dctx);
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    goto error;
  }
  offsets = (int64_t *) malloc((size_t)offsets_nbytes);
  if (offsets == NULL) {
    blosc2_free_ctx(dctx);
    BLOSC_TRACE_ERROR("Cannot allocate memory for offsets.");
    goto error;
  }
  int32_t off_nbytes = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes,
                                             offsets, offsets_nbytes);
  blosc2_free_ctx(dctx);
  if (off_nbytes < 0) {
    BLOSC_TRACE_ERROR("Cannot decompress the offsets chunk.");
    goto error;
  }

  // We want the contiguous schunk, so create the actual data chunks (and, while doing this,
  // get a guess at the blocksize used in this frame)
  int64_t acc_nbytes = 0;
  int64_t acc_cbytes = 0;
  int32_t blocksize = 0;
  int32_t chunk_nbytes;
  int32_t chunk_cbytes;
  int32_t chunk_blocksize;
  size_t prev_alloc = BLOSC_EXTENDED_HEADER_LENGTH;
  uint8_t* data_chunk = NULL;
  bool needs_free = false;
  const blosc2_io_cb *io_cb = blosc2_get_io_cb(udio->id);
  if (io_cb == NULL) {
    blosc2_schunk_free(schunk);
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return NULL;
  }

  void* fp = NULL;
  if (frame->cframe == NULL) {
    if (io_cb->is_allocation_necessary) {
      data_chunk = malloc((size_t)prev_alloc);
      needs_free = true;
    }
    else {
      needs_free = false;
    }

    if (!frame->sframe) {
      // If not the chunks won't be in the frame
      fp = frame_reader_acquire(frame, udio);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        rc = BLOSC2_ERROR_FILE_OPEN;
        goto end;
      }
    }
  }
  /* calloc(): the loop below can stop at a bad chunk, and the error path frees
     every data[i] with i < nchunks, also the ones never set */
  schunk->data = calloc(nchunks, sizeof(void*));
  if (schunk->data == NULL && nchunks > 0) {
    BLOSC_TRACE_ERROR("Cannot allocate the chunk pointers.");
    rc = BLOSC2_ERROR_MEMORY_ALLOC;
    goto end;
  }
  for (int64_t i = 0; i < nchunks; i++) {
    if (frame->cframe != NULL) {
      if (needs_free) {
        free(data_chunk);
      }
      if (offsets[i] < 0) {
        int64_t rbytes = frame_get_chunk(frame, i, &data_chunk, &needs_free);
        if (rbytes < 0) {
          break;
        }
      }
      else {
        if (offsets[i] > INT64_MAX - header_len ||
            header_len + offsets[i] > frame->len - BLOSC_EXTENDED_HEADER_LENGTH ||
            offsets[i] > cbytes - BLOSC_EXTENDED_HEADER_LENGTH) {
          rc = BLOSC2_ERROR_INVALID_HEADER;
          break;
        }
        data_chunk = frame->cframe + header_len + offsets[i];
        needs_free = false;
      }
      rc = blosc2_cbuffer_sizes(data_chunk, NULL, &chunk_cbytes, NULL);
      if (rc < 0) {
        break;
      }
      if (offsets[i] >= 0 &&
          (chunk_cbytes < BLOSC_EXTENDED_HEADER_LENGTH ||
           offsets[i] > INT64_MAX - chunk_cbytes ||
           offsets[i] + chunk_cbytes > cbytes)) {
        rc = BLOSC2_ERROR_INVALID_HEADER;
        break;
      }
    }
    else {
      int64_t rbytes;
      if (offsets[i] < 0 || frame->sframe) {
        if (needs_free) {
          free(data_chunk);
        }
        rbytes = frame_get_chunk(frame, i, &data_chunk, &needs_free);
        if (rbytes < 0) {
          break;
        }
      }
      else {
        if (offsets[i] > INT64_MAX - header_len ||
            header_len + offsets[i] > frame->len - BLOSC_EXTENDED_HEADER_LENGTH ||
            offsets[i] > cbytes - BLOSC_EXTENDED_HEADER_LENGTH) {
          rc = BLOSC2_ERROR_INVALID_HEADER;
          break;
        }
        int64_t io_pos = frame->file_offset + header_len + offsets[i];
        rbytes = io_cb->read((void**)&data_chunk, 1, BLOSC_EXTENDED_HEADER_LENGTH, io_pos, fp);
      }
      if (rbytes != BLOSC_EXTENDED_HEADER_LENGTH) {
        rc = BLOSC2_ERROR_READ_BUFFER;
        break;
      }
      rc = blosc2_cbuffer_sizes(data_chunk, NULL, &chunk_cbytes, NULL);
      if (rc < 0) {
        break;
      }
      if (offsets[i] >= 0 &&
          (chunk_cbytes < BLOSC_EXTENDED_HEADER_LENGTH ||
           offsets[i] > INT64_MAX - chunk_cbytes ||
           offsets[i] + chunk_cbytes > cbytes)) {
        rc = BLOSC2_ERROR_INVALID_HEADER;
        break;
      }
      if (chunk_cbytes > (int32_t)prev_alloc) {
        if (io_cb->is_allocation_necessary)
          data_chunk = realloc(data_chunk, chunk_cbytes);
        if (data_chunk == NULL) {
          BLOSC_TRACE_ERROR("Cannot realloc space for the data_chunk.");
          rc = BLOSC2_ERROR_MEMORY_ALLOC;
          break;
        }
        prev_alloc = chunk_cbytes;
      }
      if (!frame->sframe) {
        int64_t io_pos = frame->file_offset + header_len + offsets[i];
        rbytes = io_cb->read((void**)&data_chunk, 1, chunk_cbytes, io_pos, fp);
        if (rbytes != chunk_cbytes) {
          rc = BLOSC2_ERROR_READ_BUFFER;
          break;
        }
      }
    }
    uint8_t* new_chunk = malloc(chunk_cbytes);
    memcpy(new_chunk, data_chunk, chunk_cbytes);
    schunk->data[i] = new_chunk;
    rc = blosc2_cbuffer_sizes(data_chunk, &chunk_nbytes, NULL, &chunk_blocksize);
    if (rc < 0) {
      break;
    }
    acc_nbytes += chunk_nbytes;
    acc_cbytes += chunk_cbytes;
    if (i == 0) {
      blocksize = chunk_blocksize;
    }
    else if (blocksize != chunk_blocksize) {
      // Blocksize varies
      blocksize = 0;
    }
  }

  // We are not attached to a schunk anymore
  frame->schunk = NULL;

  end:
  if (needs_free) {
    free(data_chunk);
  }
  if (frame->cframe == NULL) {
    if (!frame->sframe) {
      frame_reader_release(frame, io_cb, fp);
    }
  }
  free(offsets);
  // Avoid a double-free in the `error:` cleanup below, which is reached
  // when frame_get_metalayers / frame_get_vlmetalayers reject a malformed
  // metalayer index after we've already freed `offsets` here.
  offsets = NULL;

  // cframes and sframes have different ways to store chunks with special values:
  // 1) cframes represent special chunks as negative offsets
  // 2) sframes does not have the concept of offsets, but rather of data pointers (.data)
  //    so they always have a pointer to a special chunk
  // This is why cframes and sframes have different cbytes and hence, we cannot enforce acc_bytes == schunk->cbytes
  // In the future, maybe we could provide special meanings for .data[i] > 0x7FFFFFFF, but not there yet
  // if (rc < 0 || acc_nbytes != nbytes || acc_cbytes != cbytes) {
  if (rc < 0 || acc_nbytes != nbytes) {
    goto error;
  }
  // Update counters
  schunk->cbytes = acc_cbytes;
  schunk->blocksize = blocksize;

  out:
  rc = frame_get_metalayers(frame, schunk);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Cannot access the metalayers.");
    goto error;
  }

  rc = frame_get_vlmetalayers(frame, schunk);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Cannot access the vlmetalayers.");
    goto error;
  }

  return schunk;

error:
  free(cparams);
  free(dparams);
  free(offsets);
  if (schunk != NULL) {
    blosc2_schunk_free(schunk);
  }
  if (!frame_attached) {
    frame->schunk = NULL;
    frame_free(frame);
  }
  return NULL;
}


void frame_avoid_cframe_free(blosc2_frame_s* frame, bool avoid_cframe_free) {
  frame->avoid_cframe_free = avoid_cframe_free;
}


struct csize_idx {
    int32_t val;
    int32_t idx;
};

// Helper function for qsorting block offsets
int sort_offset(const void* a, const void* b) {
  int32_t a_ = ((struct csize_idx*)a)->val;
  int32_t b_ = ((struct csize_idx*)b)->val;
  return a_ - b_;
}


int get_coffset(blosc2_frame_s* frame, int32_t header_len, int64_t cbytes,
                int64_t nchunk, int64_t nchunks, int64_t *offset) {
  int32_t off_cbytes;
  // Get the offset to nchunk
  uint8_t *coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &off_cbytes);
  if (coffsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot get the offset for chunk %" PRId64 " for the frame.", nchunk);
    return BLOSC2_ERROR_DATA;
  }

  // Get the 64-bit offset
  int rc = blosc2_getitem(coffsets, off_cbytes, (int32_t)nchunk, 1, offset, (int32_t)sizeof(int64_t));
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Problems retrieving a chunk offset.");
  } else if (!frame->sframe && *offset >= 0) {
    if (cbytes < 0 || cbytes > INT64_MAX - header_len) {
      BLOSC_TRACE_ERROR("Invalid compressed size in frame header.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    if (*offset > INT64_MAX - header_len) {
      BLOSC_TRACE_ERROR("Offset for chunk %" PRId64 " overflows frame position.", nchunk);
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    int64_t chunk_pos = header_len + *offset;
    int64_t data_limit = header_len + cbytes;
    if (chunk_pos < header_len ||
        chunk_pos > data_limit - BLOSC_EXTENDED_HEADER_LENGTH ||
        chunk_pos > frame->len - BLOSC_EXTENDED_HEADER_LENGTH) {
      BLOSC_TRACE_ERROR("Cannot read chunk %" PRId64 " outside of frame boundary.", nchunk);
      return BLOSC2_ERROR_INVALID_HEADER;
    }
  }

  return rc;
}


/* How far frame_get_chunk_ranges() looks in the chunk index for the chunk that follows another one in the file */
#define CHUNK_END_LOOKAHEAD 64

/* See frame.h */
/* Read the index entries that a request for chunks nchunks[0..n) of `frame` needs: from the smallest of them, *lo,
   up to `lookahead` chunks after the largest (within the frame), *span_end, into a new array *off (to free(); NULL if
   n <= 0).  A negative entry is a special value coded in the offset (see special_offset()).  Refreshes a stale frame
   first, checks that the chunks exist, and also gives the frame's header length, cbytes and chunksize. */
static int frame_read_index_span(blosc2_frame_s *frame, const int64_t *nchunks, int64_t n, int64_t lookahead,
                                 int64_t **off, int64_t *lo, int64_t *span_end, int32_t *header_len,
                                 int64_t *cbytes, int32_t *chunksize) {
  *off = NULL;
  int64_t frame_len;
  int64_t frame_nbytes;
  int32_t blocksize;
  int64_t frame_nchunks;
  int rc = get_header_info(frame, header_len, &frame_len, &frame_nbytes, cbytes, &blocksize, chunksize,
                           &frame_nchunks, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                           frame->schunk->storage->io);
  if (rc < 0) {
    return rc;
  }
  // A different handle may have changed the index, including a same-length
  // reorder flagged by frame_lock().  Refresh before reusing cached offsets.
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc < 0) {
    return rc;
  }
  if (rc > 0) {
    frame->schunk->nbytes = frame_nbytes;
    frame->schunk->cbytes = *cbytes;
    frame->schunk->nchunks = frame_nchunks;
  }
  int64_t hi = -1;
  *lo = INT64_MAX;
  for (int64_t k = 0; k < n; ++k) {
    if (nchunks[k] < 0 || nchunks[k] >= frame_nchunks) {
      BLOSC_TRACE_ERROR("nchunk ('%" PRId64 "') exceeds the number of chunks ('%" PRId64 "').",
                        nchunks[k], frame_nchunks);
      return BLOSC2_ERROR_INVALID_PARAM;
    }
    *lo = nchunks[k] < *lo ? nchunks[k] : *lo;
    hi = nchunks[k] > hi ? nchunks[k] : hi;
  }
  if (n <= 0) {
    return BLOSC2_ERROR_SUCCESS;
  }
  int32_t off_cbytes;
  uint8_t *coffsets = get_coffsets(frame, *header_len, *cbytes, frame_nchunks, &off_cbytes);
  if (coffsets == NULL) {
    return BLOSC2_ERROR_DATA;
  }
  *span_end = hi + 1 + lookahead < frame_nchunks ? hi + 1 + lookahead : frame_nchunks;
  *off = malloc((size_t) (*span_end - *lo) * sizeof(int64_t));
  if (*off == NULL) {
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }
  rc = blosc2_getitem(coffsets, off_cbytes, (int32_t) *lo, (int32_t) (*span_end - *lo), *off,
                      (int32_t) ((*span_end - *lo) * sizeof(int64_t)));
  if (rc < 0) {
    free(*off);
    *off = NULL;
    return rc;
  }
  return BLOSC2_ERROR_SUCCESS;
}


int frame_get_chunks_special(blosc2_frame_s *frame, const int64_t *nchunks, int64_t n, uint8_t *special) {
  int64_t *off;
  int64_t lo;
  int64_t span_end;
  int32_t header_len;
  int64_t cbytes;
  int32_t chunksize;
  int rc = frame_read_index_span(frame, nchunks, n, 0, &off, &lo, &span_end, &header_len, &cbytes, &chunksize);
  if (rc < 0 || off == NULL) {
    return rc;
  }
  for (int64_t k = 0; k < n; ++k) {
    int64_t offset = off[nchunks[k] - lo];
    special[k] = offset < 0 ? (uint8_t) (((uint64_t) offset >> (8 * 7)) & BLOSC2_SPECIAL_MASK) : 0;
  }
  free(off);
  return BLOSC2_ERROR_SUCCESS;
}


int frame_get_chunk_ranges(blosc2_frame_s *frame, const int64_t *nchunks, int64_t n, int64_t *ranges) {
  if (frame->cframe != NULL || frame->sframe || frame->urlpath == NULL) {
    BLOSC_TRACE_ERROR("Only contiguous frames on disk have their chunks at a place in a file.");
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  // The offsets of the chunks asked for and of the few chunks after the last one, all in one go: in a frame written
  // chunk after chunk, a chunk ends where the next chunk with bytes in the file starts (special values have none)
  int64_t *off;
  int64_t lo;
  int64_t span_end;
  int32_t header_len;
  int64_t cbytes;
  int32_t chunksize;
  int rc = frame_read_index_span(frame, nchunks, n, CHUNK_END_LOOKAHEAD, &off, &lo, &span_end, &header_len,
                                 &cbytes, &chunksize);
  if (rc < 0 || off == NULL) {
    return rc;
  }
  for (int64_t k = 0; rc >= 0 && k < n; ++k) {
    int64_t start = off[nchunks[k] - lo];
    ranges[2 * k] = frame->file_offset + header_len + (start > 0 ? start : 0);
    ranges[2 * k + 1] = 0;
    if (start < 0) {
      continue;  // a special value (zeros, NaNs...) coded in the index: no bytes in the file
    }
    if (start > cbytes - BLOSC_EXTENDED_HEADER_LENGTH ||
        start > frame->len - header_len - BLOSC_EXTENDED_HEADER_LENGTH) {
      BLOSC_TRACE_ERROR("Chunk %" PRId64 " is outside of the frame.", nchunks[k]);
      rc = BLOSC2_ERROR_INVALID_HEADER;
      break;
    }
    // The last chunk ends where the index starts; chunks stored out of order (after updates) end at the latest
    // after their largest possible size
    int64_t end = cbytes;
    for (int64_t j = nchunks[k] + 1; j < span_end && j <= nchunks[k] + CHUNK_END_LOOKAHEAD; ++j) {
      if (off[j - lo] >= 0) {
        end = off[j - lo] > start && off[j - lo] < end ? off[j - lo] : end;
        break;
      }
    }
    if (chunksize > 0 && end - start > (int64_t) chunksize + BLOSC2_MAX_OVERHEAD) {
      end = start + chunksize + BLOSC2_MAX_OVERHEAD;
    }
    ranges[2 * k + 1] = end - start;
  }
  free(off);
  return rc < 0 ? rc : BLOSC2_ERROR_SUCCESS;
}


// Write the chunk with special values (only zeros, NaNs and non initialized) that an
// offset codes into `dest`, which holds `cbytes` bytes
static int special_chunk_into(int64_t special_value, int32_t nbytes, int32_t typesize, int32_t blocksize,
                              uint8_t* dest, int32_t cbytes) {
  int rc = 0;

  // Detect the kind of special value
  uint64_t zeros_mask = (uint64_t) BLOSC2_SPECIAL_ZERO << (8 * 7);  // chunk of zeros
  uint64_t nans_mask = (uint64_t) BLOSC2_SPECIAL_NAN << (8 * 7);  // chunk of NaNs
  uint64_t uninit_mask = (uint64_t) BLOSC2_SPECIAL_UNINIT << (8 * 7);  // chunk of uninit values

  blosc2_cparams cparams = BLOSC2_CPARAMS_DEFAULTS;
  cparams.typesize = typesize;
  cparams.blocksize = blocksize;
  if (special_value & zeros_mask) {
    rc = blosc2_chunk_zeros(cparams, nbytes, dest, cbytes);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Error creating a zero chunk");
    }
  }
  else if (special_value & uninit_mask) {
    rc = blosc2_chunk_uninit(cparams, nbytes, dest, cbytes);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Error creating a non initialized chunk");
    }
  }
  else if (special_value & nans_mask) {
    rc = blosc2_chunk_nans(cparams, nbytes, dest, cbytes);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Error creating a nan chunk");
    }
  }
  else {
    BLOSC_TRACE_ERROR("Special value not recognized: %" PRId64 "", special_value);
    rc = BLOSC2_ERROR_DATA;
  }
  return rc;
}


// Detect and return a chunk with special values in offsets (only zeros, NaNs and non initialized)
int frame_special_chunk(int64_t special_value, int32_t nbytes, int32_t typesize, int32_t blocksize,
                        uint8_t** chunk, int32_t cbytes, bool *needs_free) {
  *chunk = malloc(cbytes);
  *needs_free = true;
  int rc = *chunk == NULL ? BLOSC2_ERROR_MEMORY_ALLOC
                          : special_chunk_into(special_value, nbytes, typesize, blocksize, *chunk, cbytes);
  if (rc < 0) {
    free(*chunk);
    *needs_free = false;
    *chunk = NULL;
  }

  return rc;
}


/* Return a compressed chunk that is part of a frame in the `chunk` parameter.
 * If the frame is disk-based, a buffer is allocated for the (compressed) chunk,
 * and hence a free is needed.  You can check if the chunk requires a free with the `needs_free`
 * parameter.
 * If the chunk does not need a free, it means that a pointer to the location in frame is returned
 * in the `chunk` parameter.
 *
 * The size of the (compressed) chunk is returned.  If some problem is detected, a negative code
 * is returned instead.
*/
// With `capacity`, a chunk read from a file goes into a buffer from
// blosc2_tmp_malloc() (release it with blosc2_tmp_free(*chunk, *capacity));
// otherwise into a plain malloc'ed one.
static int get_chunk(blosc2_frame_s *frame, int64_t nchunk, uint8_t **chunk, bool *needs_free,
                     size_t *capacity) {
  if (capacity != NULL) {
    *capacity = 0;
  }
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int32_t typesize;
  int64_t offset;
  int32_t chunk_cbytes;
  int rc;

  *chunk = NULL;
  *needs_free = false;
  rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                       &blocksize, &chunksize, &nchunks,
                       &typesize, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                       frame->schunk->storage->io);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    return rc;
  }
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to refresh the frame state from disk.");
    return rc;
  }
  if (rc > 0) {
    // Keep the schunk-level counters in sync with the refreshed on-disk state.
    // Mutating ops (update/delete) read a chunk before adjusting the counters,
    // so this also gives them a fresh base to apply their deltas on.
    frame->schunk->nbytes = nbytes;
    frame->schunk->cbytes = cbytes;
    frame->schunk->nchunks = nchunks;
  }

  if ((nchunks > 0) && (nchunk >= nchunks)) {
    BLOSC_TRACE_ERROR("nchunk ('%" PRId64 "') exceeds the number of chunks "
                    "('%" PRId64 "') in frame.", nchunk, nchunks);
    return BLOSC2_ERROR_INVALID_PARAM;
  }

  // Get the offset to nchunk
  rc = get_coffset(frame, header_len, cbytes, nchunk, nchunks, &offset);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get offset to chunk %" PRId64 ".", nchunk);
    return rc;
  }

  if (offset < 0) {
    // Special value
    if (chunksize <= 0) {
      BLOSC_TRACE_ERROR("Cannot synthesize special chunk with chunksize <= 0.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    chunk_cbytes = BLOSC_EXTENDED_HEADER_LENGTH;
    int32_t chunksize_ = chunksize;
    if ((nchunk == nchunks - 1) && (nbytes % chunksize)) {
      // Last chunk is incomplete.  Compute its actual size.
      chunksize_ = (int32_t) (nbytes % chunksize);
    }
    rc = frame_special_chunk(offset, chunksize_, typesize, blocksize, chunk, chunk_cbytes, needs_free);
    if (rc < 0) {
      return rc;
    }
    goto end;
  }

  if (frame->sframe) {
    // Sparse on-disk
    nchunk = offset;
    return sframe_get_chunk(frame, nchunk, chunk, needs_free);
  }

  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }

  if (frame->cframe == NULL) {
    uint8_t* header_ptr;
    uint8_t header[BLOSC_EXTENDED_HEADER_LENGTH];
    void* fp = frame_reader_acquire(frame, frame->schunk->storage->io);
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      return BLOSC2_ERROR_FILE_OPEN;
    }
    if (io_cb->is_allocation_necessary)
      header_ptr = header;
    int64_t io_pos = frame->file_offset + header_len + offset;
    int64_t rbytes = io_cb->read((void**)&header_ptr, 1, sizeof(header), io_pos, fp);
    if (rbytes != BLOSC_EXTENDED_HEADER_LENGTH) {
      BLOSC_TRACE_ERROR("Cannot read the cbytes for chunk in the frame.");
      frame_reader_release(frame, io_cb, fp);
      return BLOSC2_ERROR_FILE_READ;
    }
    rc = blosc2_cbuffer_sizes(header_ptr, NULL, &chunk_cbytes, NULL);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Cannot read the cbytes for chunk in the frame.");
      frame_reader_release(frame, io_cb, fp);
      return rc;
    }
    if (chunk_cbytes < BLOSC_EXTENDED_HEADER_LENGTH ||
        offset > INT64_MAX - chunk_cbytes ||
        offset + chunk_cbytes > cbytes) {
      BLOSC_TRACE_ERROR("Invalid chunk size in frame for chunk %" PRId64 ".", nchunk);
      frame_reader_release(frame, io_cb, fp);
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    if (io_cb->is_allocation_necessary) {
      *chunk = capacity != NULL ? blosc2_tmp_malloc(chunk_cbytes, capacity) : malloc(chunk_cbytes);
      if (*chunk == NULL) {
        BLOSC_TRACE_ERROR("Cannot allocate memory for chunk.");
        frame_reader_release(frame, io_cb, fp);
        return BLOSC2_ERROR_MEMORY_ALLOC;
      }
      *needs_free = true;
    }
    else {
      *needs_free = false;
    }

    io_pos = frame->file_offset + header_len + offset;
    rbytes = io_cb->read((void**)chunk, 1, chunk_cbytes, io_pos, fp);
    frame_reader_release(frame, io_cb, fp);
    if (rbytes != chunk_cbytes) {
      BLOSC_TRACE_ERROR("Cannot read the chunk out of the frame.");
      if (*needs_free) {
        free(*chunk);
        *chunk = NULL;
        *needs_free = false;
      }
      return BLOSC2_ERROR_FILE_READ;
    }

  } else {
    // The chunk is in memory and just one pointer away
    *chunk = frame->cframe + header_len + offset;
    int32_t chunk_blocksize = 0;
    rc = blosc2_cbuffer_sizes(*chunk, NULL, &chunk_cbytes, &chunk_blocksize);
    if (rc < 0) {
      return rc;
    }
    if (chunk_blocksize <= 0) {
      BLOSC_TRACE_ERROR("Invalid blocksize %d in chunk header.", chunk_blocksize);
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    if (chunk_cbytes < BLOSC_EXTENDED_HEADER_LENGTH ||
        offset > INT64_MAX - chunk_cbytes ||
        offset + chunk_cbytes > cbytes) {
      BLOSC_TRACE_ERROR("Invalid chunk size in frame for chunk %" PRId64 ".", nchunk);
      return BLOSC2_ERROR_INVALID_HEADER;
    }
  }

  end:
  return (int32_t)chunk_cbytes;
}


int frame_get_chunk(blosc2_frame_s *frame, int64_t nchunk, uint8_t **chunk, bool *needs_free) {
  return get_chunk(frame, nchunk, chunk, needs_free, NULL);
}


/* Return a compressed chunk that is part of a frame in the `chunk` parameter.
 * If the frame is disk-based, a buffer is allocated for the (lazy) chunk,
 * and hence a free is needed.  You can check if the chunk requires a free with the `needs_free`
 * parameter.
 * If the chunk does not need a free, it means that the frame is in memory and that just a
 * pointer to the location of the chunk in memory is returned.
 *
 * The size of the (compressed, potentially lazy) chunk is returned.  If some problem is detected,
 * a negative code is returned instead.
*/
int frame_get_lazychunk(blosc2_frame_s *frame, int64_t nchunk, uint8_t **chunk, bool *needs_free) {
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int32_t typesize;
  int32_t lazychunk_cbytes;
  int64_t offset;
  void* fp = NULL;
  int32_t* block_csizes = NULL;
  struct csize_idx *csize_idx = NULL;

  *chunk = NULL;
  *needs_free = false;
  int rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                           &blocksize, &chunksize, &nchunks,
                           &typesize, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                           frame->schunk->storage->io);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    return rc;
  }
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to refresh the frame state from disk.");
    return rc;
  }
  if (rc > 0) {
    // Keep the schunk-level counters in sync with the refreshed on-disk state
    // (see frame_get_chunk).
    frame->schunk->nbytes = nbytes;
    frame->schunk->cbytes = cbytes;
    frame->schunk->nchunks = nchunks;
  }

  if (nchunk >= nchunks) {
    BLOSC_TRACE_ERROR("nchunk ('%" PRId64 "') exceeds the number of chunks "
                      "('%" PRId64 "') in frame.", nchunk, nchunks);
    return BLOSC2_ERROR_INVALID_PARAM;
  }

  // Get the offset to nchunk
  rc = get_coffset(frame, header_len, cbytes, nchunk, nchunks, &offset);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get offset to chunk %" PRId64 ".", nchunk);
    return rc;
  }

  if (offset < 0) {
    // Special value
    if (chunksize <= 0) {
      BLOSC_TRACE_ERROR("Cannot synthesize special chunk with chunksize <= 0.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    lazychunk_cbytes = BLOSC_EXTENDED_HEADER_LENGTH;
    int32_t chunksize_ = chunksize;
    if ((nchunk == nchunks - 1) && (nbytes % chunksize)) {
      // Last chunk is incomplete.  Compute its actual size.
      chunksize_ = (int32_t) (nbytes % chunksize);
    }
    rc = frame_special_chunk(offset, chunksize_, typesize, blocksize, chunk,
                             (int32_t)lazychunk_cbytes, needs_free);
    goto end;
  }

  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    rc = BLOSC2_ERROR_PLUGIN_IO;
    goto end;
  }

  if (frame->cframe == NULL) {
    // TODO: make this portable across different endianness
    // Get info for building a lazy chunk
    int32_t chunk_nbytes;
    int32_t chunk_cbytes;
    int32_t chunk_blocksize;
    uint8_t* header_ptr;
    uint8_t header[BLOSC_EXTENDED_HEADER_LENGTH];
    int64_t io_pos = 0;
    if (frame->sframe) {
      // The chunk is not in the frame
      fp = sframe_open_chunk(frame->urlpath, offset, "rb",
                             frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
    }
    else {
      fp = frame_reader_acquire(frame, frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset + header_len + offset;
    }
    if (io_cb->is_allocation_necessary)
      header_ptr = header;
    int64_t rbytes = io_cb->read((void**)&header_ptr, 1, BLOSC_EXTENDED_HEADER_LENGTH, io_pos, fp);
    if (rbytes != BLOSC_EXTENDED_HEADER_LENGTH) {
      BLOSC_TRACE_ERROR("Cannot read the header for chunk in the frame.");
      rc = BLOSC2_ERROR_FILE_READ;
      goto end;
    }
    rc = blosc2_cbuffer_sizes(header_ptr, &chunk_nbytes, &chunk_cbytes, &chunk_blocksize);
    if (rc < 0) {
      goto end;
    }
    if (chunk_nbytes < 0 || chunk_cbytes < BLOSC_EXTENDED_HEADER_LENGTH || chunk_blocksize <= 0) {
      rc = BLOSC2_ERROR_INVALID_HEADER;
      goto end;
    }
    bool vlblocks = (header_ptr[BLOSC2_CHUNK_BLOSC2_FLAGS2] & BLOSC2_VL_BLOCKS) != 0;
    size_t nblocks;
    size_t leftover_block = 0;
    if (vlblocks) {
      nblocks = (size_t)chunk_blocksize;
    }
    else {
      nblocks = (size_t)chunk_nbytes / (size_t)chunk_blocksize;
      leftover_block = (size_t)chunk_nbytes % (size_t)chunk_blocksize;
      if (leftover_block) {
        if (nblocks == SIZE_MAX) {
          rc = BLOSC2_ERROR_INVALID_HEADER;
          goto end;
        }
        nblocks += 1;
      }
    }
    if (nblocks == 0 || nblocks > (size_t)INT_MAX) {
      rc = BLOSC2_ERROR_INVALID_HEADER;
      goto end;
    }
    // Allocate space for the lazy chunk
    int32_t special_type = (header_ptr[BLOSC2_CHUNK_BLOSC2_FLAGS] >> 4) & BLOSC2_SPECIAL_MASK;
    int memcpyed = header_ptr[BLOSC2_CHUNK_FLAGS] & (uint8_t) BLOSC_MEMCPYED;

    int32_t trailer_offset;
    size_t streams_offset = BLOSC_EXTENDED_HEADER_LENGTH;
    size_t trailer_offset_sz = BLOSC_EXTENDED_HEADER_LENGTH;
    size_t trailer_len_sz = 0;
    size_t lazychunk_cbytes_sz = 0;
    size_t bstarts_nbytes = 0;
    if (special_type == 0) {
      if (nblocks > SIZE_MAX / sizeof(int32_t)) {
        rc = BLOSC2_ERROR_INVALID_HEADER;
        goto end;
      }
      bstarts_nbytes = nblocks * sizeof(int32_t);

      if (!memcpyed) {
        if ((size_t)chunk_cbytes < BLOSC_EXTENDED_HEADER_LENGTH ||
            bstarts_nbytes > (size_t)chunk_cbytes - BLOSC_EXTENDED_HEADER_LENGTH) {
          rc = BLOSC2_ERROR_INVALID_HEADER;
          goto end;
        }
      }

      if (bstarts_nbytes > SIZE_MAX - trailer_offset_sz) {
        rc = BLOSC2_ERROR_INVALID_HEADER;
        goto end;
      }
      trailer_offset_sz += bstarts_nbytes;
      // Regular values have offsets for blocks
      if (!memcpyed) {
        if (bstarts_nbytes > SIZE_MAX - streams_offset) {
          rc = BLOSC2_ERROR_INVALID_HEADER;
          goto end;
        }
        streams_offset += bstarts_nbytes;
      }

      if (bstarts_nbytes > SIZE_MAX - (sizeof(int32_t) + sizeof(int64_t))) {
        rc = BLOSC2_ERROR_INVALID_HEADER;
        goto end;
      }
      trailer_len_sz = sizeof(int32_t) + sizeof(int64_t) + bstarts_nbytes;
      if (trailer_len_sz > SIZE_MAX - trailer_offset_sz) {
        rc = BLOSC2_ERROR_INVALID_HEADER;
        goto end;
      }
      lazychunk_cbytes_sz = trailer_offset_sz + trailer_len_sz;
    }
    else if (special_type == BLOSC2_SPECIAL_VALUE) {
      if (typesize <= 0) {
        rc = BLOSC2_ERROR_INVALID_HEADER;
        goto end;
      }
      if ((size_t)typesize > SIZE_MAX - trailer_offset_sz ||
          (size_t)typesize > SIZE_MAX - streams_offset) {
        rc = BLOSC2_ERROR_INVALID_HEADER;
        goto end;
      }
      trailer_offset_sz += (size_t)typesize;
      streams_offset += (size_t)typesize;
      lazychunk_cbytes_sz = trailer_offset_sz;
    }
    else {
      rc = BLOSC2_ERROR_INVALID_HEADER;
      goto end;
    }

    if (streams_offset > (size_t)chunk_cbytes ||
        trailer_offset_sz > INT32_MAX ||
        trailer_len_sz > INT32_MAX ||
        lazychunk_cbytes_sz > INT32_MAX) {
      rc = BLOSC2_ERROR_INVALID_HEADER;
      goto end;
    }

    trailer_offset = (int32_t)trailer_offset_sz;
    lazychunk_cbytes = (int32_t)lazychunk_cbytes_sz;

    // Read just the full header and bstarts section too (lazy partial length)
    if (frame->sframe) {
      io_pos = 0;
    }
    else {
      io_pos = frame->file_offset + header_len + offset;
    }

    // The case here is a bit special because more memory is allocated than read from the file
    // and the chunk is modified after reading. Due to the modification, we cannot directly use
    // the memory provided by the io
    *chunk = malloc((size_t)lazychunk_cbytes);
    if (*chunk == NULL) {
      rc = BLOSC2_ERROR_MEMORY_ALLOC;
      goto end;
    }
    *needs_free = true;

    if (io_cb->is_allocation_necessary) {
      rbytes = io_cb->read((void**)chunk, 1, (int64_t)streams_offset, io_pos, fp);
    }
    else {
      // The io hands out its own memory (mmap) and none at all for a read past
      // its end, which a damaged offset or header asks for: copy only after a
      // complete read
      uint8_t* chunk_ptr = NULL;
      rbytes = io_cb->read((void**)&chunk_ptr, 1, (int64_t)streams_offset, io_pos, fp);
      if (rbytes == (int64_t)streams_offset && chunk_ptr != NULL) {
        memcpy(*chunk, chunk_ptr, streams_offset);
      }
      else {
        rbytes = BLOSC2_ERROR_FILE_READ;
      }
    }

    if (rbytes != (int64_t)streams_offset) {
      BLOSC_TRACE_ERROR("Cannot read the (lazy) chunk out of the frame.");
      rc = BLOSC2_ERROR_FILE_READ;
      goto end;
    }
    if (special_type == BLOSC2_SPECIAL_VALUE) {
      // Value runlen is not returning a lazy chunk.  We are done.
      goto end;
    }

    // Mark chunk as lazy
    uint8_t* blosc2_flags = *chunk + BLOSC2_CHUNK_BLOSC2_FLAGS;
    *blosc2_flags |= 0x08U;

    // Add the trailer (currently, nchunk + offset + block_csizes)
    if (frame->sframe) {
      *(int32_t*)(*chunk + trailer_offset) = (int32_t)offset;   // offset is nchunk for sframes
      *(int64_t*)(*chunk + trailer_offset + sizeof(int32_t)) = offset;
    }
    else {
      *(int32_t*)(*chunk + trailer_offset) = (int32_t)nchunk;
      *(int64_t*)(*chunk + trailer_offset + sizeof(int32_t)) = header_len + offset;
    }

    block_csizes = malloc(nblocks * sizeof(int32_t));
    if (block_csizes == NULL) {
      rc = BLOSC2_ERROR_MEMORY_ALLOC;
      goto end;
    }

    if (memcpyed) {
      // When memcpyed the blocksizes are trivial to compute
      for (size_t i = 0; i + 1 < nblocks; i++) {
        block_csizes[i] = (int)chunk_blocksize;
      }
      // The last block could be incomplete, mainly due to the fact that the block size is not divisible
      // by the typesize
      block_csizes[nblocks - 1] = (int32_t)leftover_block ? (int32_t)leftover_block : chunk_blocksize;
    }
    else {
      // In regular, compressed chunks, we need to sort the bstarts (they can be out
      // of order because of multi-threading), and get a reverse index too.
      memcpy(block_csizes, *chunk + BLOSC_EXTENDED_HEADER_LENGTH, nblocks * sizeof(int32_t));
      // Helper structure to keep track of original indexes
      csize_idx = malloc(nblocks * sizeof(struct csize_idx));
      if (csize_idx == NULL) {
        rc = BLOSC2_ERROR_MEMORY_ALLOC;
        goto end;
      }
      for (size_t n = 0; n < nblocks; n++) {
        // A block starts within its chunk, at or after streams_offset; damaged
        // starts would point into chunk headers or overflow the differences below
        // (and in sort_offset())
        if (block_csizes[n] < (int64_t)streams_offset || block_csizes[n] > chunk_cbytes) {
          rc = BLOSC2_ERROR_INVALID_HEADER;
          goto end;
        }
        csize_idx[n].val = block_csizes[n];
        csize_idx[n].idx = (int)n;
      }
      qsort(csize_idx, nblocks, sizeof(struct csize_idx), &sort_offset);
      // Compute the actual csizes
      int idx;
      for (size_t n = 0; n + 1 < nblocks; n++) {
        idx = csize_idx[n].idx;
        block_csizes[idx] = csize_idx[n + 1].val - csize_idx[n].val;
      }
      idx = csize_idx[nblocks - 1].idx;
      block_csizes[idx] = chunk_cbytes - csize_idx[nblocks - 1].val;
      free(csize_idx);
      csize_idx = NULL;
    }
    // Copy the csizes at the end of the trailer
    void *trailer_csizes = *chunk + lazychunk_cbytes - nblocks * sizeof(int32_t);
    memcpy(trailer_csizes, block_csizes, nblocks * sizeof(int32_t));
    free(block_csizes);
    block_csizes = NULL;
  } else {
    // The chunk is in memory and just one pointer away
    int64_t chunk_header_offset = header_len + offset;
    int64_t chunk_cbytes_offset = chunk_header_offset + BLOSC_MIN_HEADER_LENGTH;

    *chunk = frame->cframe + chunk_header_offset;

    if (chunk_header_offset < 0 ||
        chunk_cbytes_offset < chunk_header_offset ||
        chunk_cbytes_offset > frame->len) {
      BLOSC_TRACE_ERROR("Cannot read the header for chunk in the (contiguous) frame.");
      rc = BLOSC2_ERROR_READ_BUFFER;
    } else {
      int32_t chunk_blocksize = 0;
      rc = blosc2_cbuffer_sizes(*chunk, NULL, &lazychunk_cbytes, &chunk_blocksize);
      if (rc < 0) {
        BLOSC_TRACE_ERROR("Cannot read the chunk header.");
        rc = BLOSC2_ERROR_READ_BUFFER;
      }
      else if (chunk_blocksize <= 0) {
        BLOSC_TRACE_ERROR("Invalid blocksize %d in chunk header.", chunk_blocksize);
        rc = BLOSC2_ERROR_INVALID_HEADER;
      }
      else if (lazychunk_cbytes < BLOSC_EXTENDED_HEADER_LENGTH ||
               chunk_header_offset > INT64_MAX - lazychunk_cbytes ||
               chunk_header_offset + lazychunk_cbytes > frame_len) {
        BLOSC_TRACE_ERROR("Compressed bytes exceed beyond frame length.");
        rc = BLOSC2_ERROR_READ_BUFFER;
      }
    }
  }

  end:
  if (csize_idx != NULL) {
    free(csize_idx);
  }
  if (block_csizes != NULL) {
    free(block_csizes);
  }
  if (fp != NULL) {
    frame_reader_release(frame, io_cb, fp);
  }
  if (rc < 0) {
    if (*needs_free) {
      free(*chunk);
      *chunk = NULL;
      *needs_free = false;
    }
    return rc;
  }

  return (int)lazychunk_cbytes;
}


/* The fields of a frame header needed to find, and synthesize, its chunks */
typedef struct {
  int32_t header_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int32_t typesize;
} frame_fields;


/* Read the fields of the header of `frame`, refreshing its cached state when the
   frame changed on disk (and the counters of its super-chunk, as get_chunk() does). */
static int get_frame_fields(blosc2_frame_s* frame, frame_fields* f) {
  int64_t frame_len;
  int rc = get_header_info(frame, &f->header_len, &frame_len, &f->nbytes, &f->cbytes, &f->blocksize,
                           &f->chunksize, &f->nchunks, &f->typesize, NULL, NULL, NULL, NULL, NULL, NULL,
                           NULL, frame->schunk->storage->io);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    return rc;
  }
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to refresh the frame state from disk.");
    return rc;
  }
  if (rc > 0) {
    frame->schunk->nbytes = f->nbytes;
    frame->schunk->cbytes = f->cbytes;
    frame->schunk->nchunks = f->nchunks;
  }
  return BLOSC2_ERROR_SUCCESS;
}


/* Copy the header of chunk `nchunk` of `frame`, whose header fields are `f`, into
   `header` (BLOSC_EXTENDED_HEADER_LENGTH bytes); a chunk coded in its offset gets
   the header of the special chunk that it stands for.  A contiguous file frame is
   read through `fp` if not NULL.  The offset of the chunk goes to *offset.
   Returns the cbytes of the chunk, or a negative value on error. */
static int read_frame_chunk_header(blosc2_frame_s* frame, const frame_fields* f, int64_t nchunk, void* fp,
                                   uint8_t* header, int64_t* offset) {
  if (nchunk < 0 || nchunk >= f->nchunks) {
    BLOSC_TRACE_ERROR("nchunk ('%" PRId64 "') exceeds the number of chunks "
                      "('%" PRId64 "') in frame.", nchunk, f->nchunks);
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  int rc = get_coffset(frame, f->header_len, f->cbytes, nchunk, f->nchunks, offset);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get offset to chunk %" PRId64 ".", nchunk);
    return rc;
  }
  if (*offset < 0) {
    if (f->chunksize <= 0) {
      BLOSC_TRACE_ERROR("Cannot synthesize special chunk with chunksize <= 0.");
      return BLOSC2_ERROR_INVALID_HEADER;
    }
    int32_t chunksize = f->chunksize;
    if ((nchunk == f->nchunks - 1) && (f->nbytes % f->chunksize)) {
      // Last chunk is incomplete.  Compute its actual size.
      chunksize = (int32_t) (f->nbytes % f->chunksize);
    }
    return special_chunk_into(*offset, chunksize, f->typesize, f->blocksize, header,
                              BLOSC_EXTENDED_HEADER_LENGTH);
  }

  if (frame->cframe != NULL) {
    // get_coffset() checked that the header is inside the frame
    memcpy(header, frame->cframe + f->header_len + *offset, BLOSC_EXTENDED_HEADER_LENGTH);
  }
  else {
    blosc2_io_cb* io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      return BLOSC2_ERROR_PLUGIN_IO;
    }
    void* chunk_fp = fp;
    int64_t io_pos = frame->file_offset + f->header_len + *offset;
    if (frame->sframe) {
      chunk_fp = sframe_open_chunk(frame->urlpath, *offset, "rb", frame->schunk->storage->io);
      io_pos = 0;
    }
    else if (fp == NULL) {
      chunk_fp = frame_reader_acquire(frame, frame->schunk->storage->io);
    }
    if (chunk_fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      return BLOSC2_ERROR_FILE_OPEN;
    }
    uint8_t* header_ptr = header;
    int64_t rbytes = io_cb->read((void**)&header_ptr, 1, BLOSC_EXTENDED_HEADER_LENGTH, io_pos, chunk_fp);
    if (rbytes == BLOSC_EXTENDED_HEADER_LENGTH && header_ptr != header) {
      memcpy(header, header_ptr, BLOSC_EXTENDED_HEADER_LENGTH);
    }
    if (frame->sframe) {
      io_cb->close(chunk_fp);
    }
    else if (fp == NULL) {
      frame_reader_release(frame, io_cb, chunk_fp);
    }
    if (rbytes != BLOSC_EXTENDED_HEADER_LENGTH) {
      BLOSC_TRACE_ERROR("Cannot read the header for chunk in the frame.");
      return BLOSC2_ERROR_FILE_READ;
    }
  }
  int32_t chunk_cbytes;
  rc = blosc2_cbuffer_sizes(header, NULL, &chunk_cbytes, NULL);
  if (rc < 0) {
    return rc;
  }
  int64_t chunk_end;
  if (chunk_cbytes < BLOSC_EXTENDED_HEADER_LENGTH ||
      (!frame->sframe && (!blosc2_checked_add_i64_nonneg(*offset, chunk_cbytes, &chunk_end) ||
                          chunk_end > f->cbytes))) {
    BLOSC_TRACE_ERROR("Invalid chunk size in frame for chunk %" PRId64 ".", nchunk);
    return BLOSC2_ERROR_INVALID_HEADER;
  }
  return chunk_cbytes;
}


/* See frame.h */
int frame_get_chunk_header(blosc2_frame_s* frame, int64_t nchunk, uint8_t* header) {
  frame_fields f;
  int rc = get_frame_fields(frame, &f);
  if (rc < 0) {
    return rc;
  }
  int64_t offset;
  return read_frame_chunk_header(frame, &f, nchunk, NULL, header, &offset);
}


/* Fill an empty frame with special values (fast path). */
int64_t frame_fill_special(blosc2_frame_s* frame, int64_t nitems, int special_value,
                       int32_t chunksize, blosc2_schunk* schunk) {
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t typesize;
  int64_t nchunks;

  int rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes, &blocksize, NULL,
                           &nchunks, &typesize, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                           schunk->storage->io);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    return BLOSC2_ERROR_DATA;
  }

  if (nitems == 0) {
    return frame_len;
  }

  if ((nitems / chunksize) > INT_MAX) {
    BLOSC_TRACE_ERROR("nitems is too large.  Try increasing the chunksize.");
    return BLOSC2_ERROR_FRAME_SPECIAL;
  }

  if ((nbytes > 0) || (cbytes > 0)) {
    BLOSC_TRACE_ERROR("Filling with special values only works on empty frames");
    return BLOSC2_ERROR_FRAME_SPECIAL;
  }

  // Compute the number of chunks and the length of the offsets chunk
  int32_t chunkitems = chunksize / typesize;
  if (chunkitems <= 0) {
    BLOSC_TRACE_ERROR("chunksize must be >= typesize for frame special fill.");
    return BLOSC2_ERROR_FRAME_SPECIAL;
  }
  nchunks = nitems / chunkitems;
  int32_t leftover_items = (int32_t)(nitems % chunkitems);
  if (leftover_items) {
    nchunks += 1;
  }

  blosc2_cparams* cparams;
  blosc2_schunk_get_cparams(schunk, &cparams);

  // Build the offsets with a special chunk
  int new_off_cbytes = BLOSC_EXTENDED_HEADER_LENGTH + sizeof(int64_t);
  uint8_t* off_chunk = malloc(new_off_cbytes);
  uint64_t offset_value = ((uint64_t)1 << 63);
  uint8_t* sample_chunk = malloc(BLOSC_EXTENDED_HEADER_LENGTH);
  if (off_chunk == NULL || sample_chunk == NULL) {
    free(off_chunk);
    free(sample_chunk);
    free(cparams);
    BLOSC_TRACE_ERROR("Cannot allocate memory for special fill chunks.");
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }
  int csize;
  switch (special_value) {
    case BLOSC2_SPECIAL_ZERO:
      offset_value += (uint64_t) BLOSC2_SPECIAL_ZERO << (8 * 7);
      csize = blosc2_chunk_zeros(*cparams, chunksize, sample_chunk, BLOSC_EXTENDED_HEADER_LENGTH);
      break;
    case BLOSC2_SPECIAL_UNINIT:
      offset_value += (uint64_t) BLOSC2_SPECIAL_UNINIT << (8 * 7);
      csize = blosc2_chunk_uninit(*cparams, chunksize, sample_chunk, BLOSC_EXTENDED_HEADER_LENGTH);
      break;
    case BLOSC2_SPECIAL_NAN:
      offset_value += (uint64_t)BLOSC2_SPECIAL_NAN << (8 * 7);
      csize = blosc2_chunk_nans(*cparams, chunksize, sample_chunk, BLOSC_EXTENDED_HEADER_LENGTH);
      break;
    default:
      free(off_chunk);
      free(sample_chunk);
      free(cparams);
      BLOSC_TRACE_ERROR("Only zeros, NaNs or non-initialized values are supported.");
      return BLOSC2_ERROR_FRAME_SPECIAL;
  }
  if (csize < 0) {
    free(off_chunk);
    free(sample_chunk);
    free(cparams);
    BLOSC_TRACE_ERROR("Error creating sample chunk");
    return BLOSC2_ERROR_FRAME_SPECIAL;
  }
  cparams->typesize = sizeof(int64_t);  // change it to offsets typesize
  // cparams->blocksize = 0;   // automatic blocksize
  cparams->blocksize = 8 * 2 * 1024;  // based on experiments with create_frame.c bench
  cparams->clevel = 5;
  cparams->compcode = BLOSC_BLOSCLZ;
  int32_t special_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &special_nbytes)) {
    free(off_chunk);
    free(sample_chunk);
    free(cparams);
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    return BLOSC2_ERROR_FRAME_SPECIAL;
  }
  rc = blosc2_chunk_repeatval(*cparams, special_nbytes, off_chunk, new_off_cbytes, &offset_value);
  free(cparams);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Error creating a special offsets chunk");
    return BLOSC2_ERROR_DATA;
  }

  // Get the blocksize associated to the sample chunk
  blosc2_cbuffer_sizes(sample_chunk, NULL, NULL, &blocksize);
  free(sample_chunk);
  // and use it for the super-chunk
  schunk->blocksize = blocksize;
  // schunk->blocksize = 0;  // for experimenting with automatic blocksize

  // We have the new offsets; update the frame.
  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }

  int64_t new_frame_len = header_len + new_off_cbytes + frame->trailer_len;
  void* fp = NULL;
  if (frame->cframe != NULL) {
    uint8_t* framep = frame->cframe;
    /* Make space for the new chunk and copy it */
    frame->cframe = framep = realloc(framep, (size_t)new_frame_len);
    if (framep == NULL) {
      BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
      return BLOSC2_ERROR_FRAME_SPECIAL;
    }
    /* Copy the offsets */
    memcpy(framep + header_len, off_chunk, (size_t)new_off_cbytes);
  }
  else {
    size_t wbytes;
    int64_t io_pos = 0;
    if (frame->sframe) {
      // Update the offsets chunk in the chunks frame
      fp = sframe_open_index(frame->urlpath, "rb+", frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset + header_len;
    }
    else {
      // Regular frame
      fp = frame_writer_acquire(frame, io_cb);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset + header_len + cbytes;
    }
    wbytes = io_cb->write(off_chunk, 1, new_off_cbytes, io_pos, fp);  // the new offsets
    frame_writer_release(frame, io_cb, fp);
    if (wbytes != (size_t)new_off_cbytes) {
      BLOSC_TRACE_ERROR("Cannot write the offsets to frame.");
      return BLOSC2_ERROR_FRAME_SPECIAL;
    }
  }

  // Invalidate the cache for chunk offsets
  if (frame->coffsets != NULL) {
    if (frame->coffsets_needs_free)
      free(frame->coffsets);
    frame->coffsets = NULL;
  }
  free(off_chunk);

  frame->len = new_frame_len;
  rc = frame_update_header(frame, schunk, false);
  if (rc < 0) {
    return BLOSC2_ERROR_FRAME_SPECIAL;
  }

  rc = frame_update_trailer(frame, schunk);
  if (rc < 0) {
    return BLOSC2_ERROR_FRAME_SPECIAL;
  }

  return frame->len;
}


/* Compress the `off_nbytes` bytes of chunk offsets of a frame into a new
   *off_chunk of `dest_nbytes` bytes, at least off_nbytes + BLOSC2_MAX_OVERHEAD
   (the room given can change the result, so each caller keeps its own).  The
   typesize is always that of the offsets, whatever BLOSC_TYPESIZE says.
   Returns the compressed size, or a negative value on error. */
static int32_t compress_offsets(const int64_t* offsets, int32_t off_nbytes, int32_t dest_nbytes,
                                uint8_t** off_chunk) {
  *off_chunk = NULL;
  blosc2_cparams cparams = BLOSC2_CPARAMS_DEFAULTS;
  cparams.splitmode = BLOSC_NEVER_SPLIT;
  cparams.typesize = sizeof(int64_t);
  cparams.blocksize = 16 * 1024;  // based on experiments with create_frame.c bench
  cparams.nthreads = 4;  // 4 threads seems a decent default for nowadays CPUs
  cparams.compcode = BLOSC_BLOSCLZ;
  blosc2_context* cctx = blosc2_create_cctx(cparams);
  if (cctx == NULL) {
    BLOSC_TRACE_ERROR("Error while creating the compression context");
    return BLOSC2_ERROR_NULL_POINTER;
  }
  cctx->typesize = sizeof(int64_t);  // override a possible BLOSC_TYPESIZE env variable (or chaos may appear)
  uint8_t* chunk = malloc((size_t)dest_nbytes);
  if (chunk == NULL) {
    blosc2_free_ctx(cctx);
    BLOSC_TRACE_ERROR("Cannot allocate memory for the offsets chunk.");
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }
  int32_t off_cbytes = blosc2_compress_ctx(cctx, offsets, off_nbytes, chunk, dest_nbytes);
  blosc2_free_ctx(cctx);
  if (off_cbytes < 0) {
    free(chunk);
    return off_cbytes;
  }
  *off_chunk = chunk;
  return off_cbytes;
}


/* Code a chunk of special values (see chunk_special_in_offset()) in its offset */
static void special_offset(int64_t* offset, int special_value) {
  uint64_t offset_value = ((uint64_t)1 << 63) + ((uint64_t)special_value << (8 * 7));
  to_little(offset, &offset_value, sizeof(uint64_t));
}

/* Whether a frame whose header has `chunksize` and `nchunks` chunks of `nbytes`
   in all needs the nbytes of its last chunk to tell whether it takes a chunk of
   `chunk_nbytes` at the end (see frame_takes_chunk()). */
static bool frame_needs_last_nbytes(int32_t chunksize, int64_t nchunks, int32_t chunk_nbytes) {
  return chunksize > 0 && nchunks > 0 && chunk_nbytes < chunksize;
}

/* Whether such a frame, whose last chunk has `last_nbytes`, takes a chunk of
   `chunk_nbytes` at the end: not two consecutive chunks shorter than the
   chunksize (yet). */
static bool frame_takes_chunk(int32_t chunksize, int64_t nchunks, int64_t nbytes, int32_t last_nbytes,
                              int32_t chunk_nbytes) {
  if (frame_needs_last_nbytes(chunksize, nchunks, chunk_nbytes) && last_nbytes < chunksize &&
      nbytes < chunksize) {
    BLOSC_TRACE_ERROR("Appending two consecutive chunks with a chunksize smaller "
                      "than the frame chunksize is not allowed yet: %d != %d.",
                      chunk_nbytes, chunksize);
    return false;
  }
  return true;
}


/* Append an existing chunk into a frame. */
void* frame_append_chunk(blosc2_frame_s* frame, void* chunk, blosc2_schunk* schunk) {
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes, &blocksize, &chunksize,
                           &nchunks, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                           frame->schunk->storage->io);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    return NULL;
  }
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to refresh the frame state from disk.");
    return NULL;
  }

  /* The uncompressed and compressed sizes start at byte 4 and 12 */
  int32_t chunk_nbytes;
  int32_t chunk_cbytes;
  rc = blosc2_cbuffer_sizes(chunk, &chunk_nbytes, &chunk_cbytes, NULL);
  if (rc < 0) {
    return NULL;
  }

  if ((nchunks > 0) && (chunksize > 0) && (schunk->chunksize != 0) && (chunk_nbytes > chunksize)) {
    BLOSC_TRACE_ERROR("Appending chunks with a larger chunksize than frame is "
                      "not allowed yet %d != %d.", chunk_nbytes, chunksize);
    return NULL;
  }

  // Check that we are not appending a small chunk after another small chunk
  int32_t chunk_nbytes_last = 0;
  if (frame_needs_last_nbytes(chunksize, nchunks, chunk_nbytes)) {
    uint8_t last_header[BLOSC_EXTENDED_HEADER_LENGTH];
    rc = frame_get_chunk_header(frame, nchunks - 1, last_header);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Cannot get the last chunk (in position %" PRId64 ").", nchunks - 1);
    } else {
      rc = blosc2_cbuffer_sizes(last_header, &chunk_nbytes_last, NULL, NULL);
    }
    if (rc < 0) {
      return NULL;
    }
  }
  if (!frame_takes_chunk(chunksize, nchunks, nbytes, chunk_nbytes_last, chunk_nbytes)) {
    return NULL;
  }

  // Get the current offsets and add one more
  int32_t off_nbytes = (int32_t) ((nchunks + 1) * sizeof(int64_t));
  int64_t* offsets = (int64_t *) malloc((size_t)off_nbytes);
  if (offsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for offsets.");
    return NULL;
  }
  if (nchunks > 0) {
    int32_t coffsets_cbytes;
    uint8_t *coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
    if (coffsets == NULL) {
      BLOSC_TRACE_ERROR("Cannot get the offsets for the frame.");
      free(offsets);
      return NULL;
    }
    // Decompress offsets
    blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
    blosc2_context *dctx = blosc2_create_dctx(off_dparams);
    if (dctx == NULL) {
      BLOSC_TRACE_ERROR("Error while creating the decompression context");
      free(offsets);
      return NULL;
    }
    int32_t prev_nbytes = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes, offsets,
                                                off_nbytes);
    blosc2_free_ctx(dctx);
    if (prev_nbytes < 0) {
      free(offsets);
      BLOSC_TRACE_ERROR("Cannot decompress the offsets chunk.");
      return NULL;
    }
  }

  // Add the new offset
  int64_t sframe_chunk_id = -1;
  int special_value = chunk_special_in_offset(chunk, chunk_cbytes);
  if (special_value) {
    special_offset(offsets + nchunks, special_value);
    chunk_cbytes = 0;   // we don't need to store the chunk
  }
  else if (frame->sframe) {
    // Compute the sframe_chunk_id value
    for (int64_t i = 0; i < nchunks; ++i) {
      if (offsets[i] > sframe_chunk_id) {
        sframe_chunk_id = offsets[i];
      }
    }
    offsets[nchunks] = ++sframe_chunk_id;
  }
  else {
    offsets[nchunks] = cbytes;
  }

  // Re-compress the offsets again
  uint8_t* off_chunk;
  int32_t new_off_cbytes = compress_offsets(offsets, off_nbytes, off_nbytes + BLOSC2_MAX_OVERHEAD,
                                            &off_chunk);
  free(offsets);
  if (new_off_cbytes < 0) {
    return NULL;
  }

  int64_t new_cbytes = cbytes + chunk_cbytes;
  int64_t new_frame_len;
  if (frame->sframe) {
    new_frame_len = header_len + 0 + new_off_cbytes + frame->trailer_len;
  }
  else {
    new_frame_len = header_len + new_cbytes + new_off_cbytes + frame->trailer_len;
  }

  void* fp = NULL;
  if (frame->cframe != NULL) {
    /* Make space for the new chunk and copy it (keeping the frame if that fails) */
    uint8_t* framep = realloc(frame->cframe, (size_t)new_frame_len);
    if (framep == NULL) {
      BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
      goto failed;
    }
    frame->cframe = framep;
    /* Copy the chunk */
    memcpy(framep + header_len + cbytes, chunk, (size_t)chunk_cbytes);
    /* Copy the offsets */
    memcpy(framep + header_len + new_cbytes, off_chunk, (size_t)new_off_cbytes);
  }
  else {
    int64_t wbytes;
    int64_t io_pos = 0;
    blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      goto failed;
    }

    if (frame->sframe) {
      // Update the offsets chunk in the chunks frame
      if (chunk_cbytes != 0) {
        if (sframe_chunk_id < 0) {
          BLOSC_TRACE_ERROR("The chunk id (%" PRId64 ") is not correct", sframe_chunk_id);
          goto failed;
        }
        if (sframe_create_chunk(frame, chunk, sframe_chunk_id, chunk_cbytes) == NULL) {
          BLOSC_TRACE_ERROR("Cannot write the full chunk.");
          goto failed;
        }
      }
      fp = sframe_open_index(frame->urlpath, "rb+",
                             frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        goto failed;
      }
      io_pos = frame->file_offset + header_len;
    }
    else {
      // Regular frame
      fp = frame_writer_acquire(frame, io_cb);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        goto failed;
      }
      io_pos = frame->file_offset + header_len + cbytes;
      wbytes = io_cb->write(chunk, 1, chunk_cbytes, io_pos, fp);  // the new chunk
      io_pos += chunk_cbytes;
      if (wbytes != chunk_cbytes) {
        BLOSC_TRACE_ERROR("Cannot write the full chunk to frame (wrote %" PRId64 " of %" PRId64
                          " bytes at position %" PRId64 ", nchunk=%" PRId64 ").",
                          wbytes, (int64_t)chunk_cbytes, io_pos - (int64_t)chunk_cbytes, nchunks);
        frame->file_end = 0;
        frame_writer_release(frame, io_cb, fp);
        goto failed;
      }
    }
    wbytes = io_cb->write(off_chunk, 1, new_off_cbytes, io_pos, fp);  // the new offsets
    frame_writer_release(frame, io_cb, fp);
    if (wbytes != new_off_cbytes) {
      BLOSC_TRACE_ERROR("Cannot write the offsets to frame.");
      frame->file_end = 0;
      goto failed;
    }
  }
  // Invalidate the cache for chunk offsets
  if (frame->coffsets != NULL) {
    if (frame->coffsets_needs_free)
      free(frame->coffsets);
    frame->coffsets = NULL;
  }
  free(off_chunk);

  frame->len = new_frame_len;
  rc = frame_update_header(frame, schunk, false);
  if (rc < 0) {
    frame->len = frame_len;
    return NULL;
  }

  rc = frame_update_trailer(frame, schunk);
  if (rc < 0) {
    frame->len = frame_len;
    return NULL;
  }

  return frame;

  failed:
  // The caller still owns the chunk; the offsets chunk is ours
  free(off_chunk);
  return NULL;
}


/* The counters of a super-chunk and the offsets of its contiguous frame after
   appending chunks one by one (see schunk_append_chunk_unlocked() and
   frame_append_chunk()), tallied without touching the frame. */
typedef struct {
  int64_t nchunks;
  int64_t nbytes;
  int64_t cbytes;  // the chunk data in the frame; special chunks live in their offset
  int32_t chunksize;
  int32_t last_nbytes;
  uint8_t flags2;  // of the first chunk
  int64_t* offsets;
  int32_t off_nbytes;  // of the offsets of all the chunks
} chunk_tally;

static int tally_init(chunk_tally* tally, int64_t nchunks, int32_t chunksize) {
  memset(tally, 0, sizeof(*tally));
  tally->chunksize = chunksize;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &tally->off_nbytes)) {
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    return BLOSC2_ERROR_DATA;
  }
  tally->offsets = malloc(tally->off_nbytes > 0 ? (size_t)tally->off_nbytes : 1);
  if (tally->offsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for the offsets.");
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }
  return BLOSC2_ERROR_SUCCESS;
}

/* Add the next chunk to the tally.  Returns the number of bytes it takes in the
   frame, where it goes at the tally->cbytes from before the call (0 for a special
   chunk), or a negative value on error. */
static int32_t tally_chunk(chunk_tally* tally, const uint8_t* chunk) {
  int32_t chunk_nbytes;
  int32_t chunk_cbytes;
  int rc = blosc2_cbuffer_sizes(chunk, &chunk_nbytes, &chunk_cbytes, NULL);
  if (rc < 0) {
    return rc;
  }
  int64_t nchunk = tally->nchunks;
  int32_t chunksize = tally->chunksize;  // as in the frame header before this chunk
  uint8_t flags2 = get_chunk_flags2(chunk, chunk_cbytes);
  if (nchunk == 0) {
    tally->flags2 = flags2;
  }
  else if ((flags2 & BLOSC2_VL_BLOCKS) != (tally->flags2 & BLOSC2_VL_BLOCKS)) {
    BLOSC_TRACE_ERROR("schunks cannot mix regular chunks and VL-block chunks.");
    return BLOSC2_ERROR_CHUNK_APPEND;
  }
  if (!chunksize_after_adding(&tally->chunksize, nchunk, tally->last_nbytes, chunk_nbytes, true)) {
    BLOSC_TRACE_ERROR("Appending chunks that have different lengths in the same schunk "
                      "is not supported yet: %d > %d.", chunk_nbytes, tally->chunksize);
    return BLOSC2_ERROR_CHUNK_APPEND;
  }
  if (!frame_takes_chunk(chunksize, nchunk, tally->nbytes, tally->last_nbytes, chunk_nbytes)) {
    return BLOSC2_ERROR_CHUNK_APPEND;
  }

  int32_t stored = chunk_cbytes;
  int special_value = chunk_special_in_offset(chunk, chunk_cbytes);
  if (special_value) {
    special_offset(tally->offsets + nchunk, special_value);
    stored = 0;
  }
  else {
    tally->offsets[nchunk] = tally->cbytes;
  }
  tally->nchunks++;
  tally->nbytes += chunk_nbytes;
  tally->cbytes += stored;
  tally->last_nbytes = chunk_nbytes;
  return stored;
}

/* Give `schunk` the counters of the tally and make `frame`, whose offsets are
   already in place, `len` bytes long, with its header and trailer to match. */
static int tally_finish(chunk_tally* tally, blosc2_frame_s* frame, blosc2_schunk* schunk, int64_t len) {
  schunk->nchunks = tally->nchunks;
  schunk->current_nchunk = tally->nchunks - 1;
  schunk->nbytes = tally->nbytes;
  schunk->cbytes = tally->cbytes;
  schunk->chunksize = tally->chunksize;
  schunk->flags2 = tally->flags2;
  if (frame->coffsets != NULL) {
    if (frame->coffsets_needs_free) {
      free(frame->coffsets);
    }
    frame->coffsets = NULL;
  }
  frame->len = len;
  return frame_update_header(frame, schunk, false);
}


/* Reads the chunks of the source super-chunk of a fill below, holding its shared
   lock: a plain super-chunk or an in-memory frame hands out the chunks in place,
   and a file frame is read through one handle, its header read once. */
typedef struct {
  blosc2_schunk* schunk;
  blosc2_frame_s* frame;  // NULL for a plain super-chunk
  bool locked;
  frame_fields f;
  blosc2_io_cb* io_cb;
  void* fp;  // the reader of a contiguous file frame
} chunk_source;

static void source_close(chunk_source* s) {
  if (s->fp != NULL) {
    frame_reader_release(s->frame, s->io_cb, s->fp);
    s->fp = NULL;
  }
  if (s->locked) {
    frame_unlock(s->frame);
    s->locked = false;
  }
}

static int source_open(chunk_source* s, blosc2_schunk* schunk) {
  memset(s, 0, sizeof(*s));
  s->schunk = schunk;
  s->frame = (blosc2_frame_s*)schunk->frame;
  if (s->frame == NULL || schunk->nchunks == 0) {
    // Without chunks there is nothing to read, so leave the frame alone: its
    // file need not even hold the frame yet
    return BLOSC2_ERROR_SUCCESS;
  }
  int rc = frame_lock(s->frame, false);
  if (rc < 0) {
    return rc;
  }
  s->locked = true;
  // This also gives the super-chunk the counters of a frame that changed on disk
  rc = get_frame_fields(s->frame, &s->f);
  if (rc >= 0 && s->frame->cframe == NULL) {
    s->io_cb = blosc2_get_io_cb(s->frame->schunk->storage->io->id);
    if (s->io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      rc = BLOSC2_ERROR_PLUGIN_IO;
    }
    else if (!s->frame->sframe) {
      s->fp = frame_reader_acquire(s->frame, s->frame->schunk->storage->io);
      if (s->fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", s->frame->urlpath);
        rc = BLOSC2_ERROR_FILE_OPEN;
      }
    }
  }
  if (rc < 0) {
    source_close(s);
  }
  return rc;
}

/* The header of chunk `nchunk` in *chunk: the whole chunk where it is in memory,
   otherwise a copy of the header in `header` (BLOSC_EXTENDED_HEADER_LENGTH bytes).
   Returns the cbytes of the chunk, or a negative value on error. */
static int source_chunk_header(chunk_source* s, int64_t nchunk, uint8_t* header, const uint8_t** chunk) {
  int rc;
  if (s->frame == NULL) {
    *chunk = s->schunk->data[nchunk];
    if (*chunk == NULL) {
      BLOSC_TRACE_ERROR("Chunk %" PRId64 " is missing.", nchunk);
      return BLOSC2_ERROR_DATA;
    }
    int32_t chunk_cbytes;
    rc = blosc2_cbuffer_sizes(*chunk, NULL, &chunk_cbytes, NULL);
    return rc < 0 ? rc : chunk_cbytes;
  }
  int64_t offset;
  rc = read_frame_chunk_header(s->frame, &s->f, nchunk, s->fp, header, &offset);
  // read_frame_chunk_header() checked that the chunk is inside an in-memory frame
  *chunk = (rc >= 0 && offset >= 0 && s->frame->cframe != NULL) ?
           s->frame->cframe + s->f.header_len + offset : header;
  return rc;
}

/* Copy chunk `nchunk`, whose header gave `cbytes`, into `dest`. */
static int source_read_chunk(chunk_source* s, int64_t nchunk, int32_t cbytes, uint8_t* dest) {
  int32_t read_cbytes;
  if (s->frame == NULL || s->frame->cframe != NULL) {
    uint8_t header[BLOSC_EXTENDED_HEADER_LENGTH];
    const uint8_t* chunk;
    read_cbytes = source_chunk_header(s, nchunk, header, &chunk);
    if (read_cbytes < 0) {
      return read_cbytes;
    }
    if (read_cbytes == cbytes && chunk != header) {
      memcpy(dest, chunk, (size_t)cbytes);
    }
  }
  else {
    int64_t offset;
    int rc = get_coffset(s->frame, s->f.header_len, s->f.cbytes, nchunk, s->f.nchunks, &offset);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Unable to get offset to chunk %" PRId64 ".", nchunk);
      return rc;
    }
    int64_t chunk_end;
    if (offset < 0 || (!s->frame->sframe && (!blosc2_checked_add_i64_nonneg(offset, cbytes, &chunk_end) ||
                                             chunk_end > s->f.cbytes))) {
      BLOSC_TRACE_ERROR("The super-chunk changed while reading it.");
      return BLOSC2_ERROR_DATA;
    }
    void* fp = s->fp;
    int64_t io_pos = s->frame->file_offset + s->f.header_len + offset;
    if (s->frame->sframe) {
      fp = sframe_open_chunk(s->frame->urlpath, offset, "rb", s->frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", s->frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = 0;
    }
    uint8_t* ptr = dest;
    int64_t rbytes = s->io_cb->read((void**)&ptr, 1, cbytes, io_pos, fp);
    if (rbytes == cbytes && ptr != dest) {
      memcpy(dest, ptr, (size_t)cbytes);
    }
    if (s->frame->sframe) {
      s->io_cb->close(fp);
    }
    if (rbytes != cbytes) {
      BLOSC_TRACE_ERROR("Cannot read the chunk out of the frame.");
      return BLOSC2_ERROR_FILE_READ;
    }
    rc = blosc2_cbuffer_sizes(dest, NULL, &read_cbytes, NULL);
    if (rc < 0) {
      return rc;
    }
  }
  if (read_cbytes != cbytes) {
    BLOSC_TRACE_ERROR("The super-chunk changed while reading it.");
    return BLOSC2_ERROR_DATA;
  }
  return cbytes;
}


/* Make room for `len` bytes at `pos` of an in-memory frame being filled by
   frame_fill_from_schunk(), growing it past `capacity` when needed. */
static int fill_reserve(blosc2_frame_s* frame, int64_t* capacity, int64_t pos, int32_t len) {
  if (pos + len > *capacity) {
    int64_t new_capacity = (pos + len) + (pos + len) / 2;
    uint8_t* cframe = realloc(frame->cframe, (size_t)new_capacity);
    if (cframe == NULL) {
      BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    frame->cframe = cframe;
    *capacity = new_capacity;
  }
  return BLOSC2_ERROR_SUCCESS;
}

/* Store `len` bytes at `pos` of a frame being filled by frame_fill_from_schunk():
   in memory (see fill_reserve()), or else through `fp`. */
static int fill_put(blosc2_frame_s* frame, int64_t* capacity, blosc2_io_cb* io_cb, void* fp,
                    int64_t pos, const uint8_t* src, int32_t len) {
  if (frame->cframe == NULL) {
    int64_t wbytes = io_cb->write(src, 1, len, frame->file_offset + pos, fp);
    if (wbytes != len) {
      BLOSC_TRACE_ERROR("Cannot write to frame (wrote %" PRId64 " of %d bytes at position %" PRId64 ").",
                        wbytes, len, frame->file_offset + pos);
      frame->file_end = 0;  // a partial write may have moved the end of the file
      return BLOSC2_ERROR_FILE_WRITE;
    }
    return BLOSC2_ERROR_SUCCESS;
  }
  int rc = fill_reserve(frame, capacity, pos, len);
  if (rc >= 0) {
    memcpy(frame->cframe + pos, src, (size_t)len);
  }
  return rc;
}


static int fill_from_schunk_unlocked(blosc2_frame_s* frame, blosc2_schunk* schunk, chunk_source* src,
                                     int32_t header_len) {
  int64_t nchunks = src->schunk->nchunks;
  chunk_tally tally;
  int rc = tally_init(&tally, nchunks, schunk->chunksize);
  if (rc < 0) {
    return rc;
  }
  // In memory, size the frame for all the chunks up front (src->cbytes is exact for
  // a consistent super-chunk) and grow it only when that falls short
  int64_t capacity = 0;
  blosc2_io_cb* io_cb = NULL;
  void* fp = NULL;
  if (frame->cframe != NULL) {
    capacity = header_len + (src->schunk->cbytes > 0 ? src->schunk->cbytes : 0) +
               nchunks * (int64_t)sizeof(int64_t) + BLOSC2_MAX_OVERHEAD + frame->trailer_len;
    uint8_t* cframe = realloc(frame->cframe, (size_t)capacity);
    if (cframe == NULL) {
      BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
      rc = BLOSC2_ERROR_MEMORY_ALLOC;
    }
    else {
      frame->cframe = cframe;
    }
  }
  else {
    io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    fp = (io_cb == NULL) ? NULL : frame_writer_acquire(frame, io_cb);
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      rc = BLOSC2_ERROR_FILE_OPEN;
    }
  }

  // For chunks that are read from a file and written to one
  uint8_t* buffer = NULL;
  size_t buffer_capacity = 0;
  for (int64_t nchunk = 0; rc >= 0 && nchunk < nchunks; nchunk++) {
    uint8_t header[BLOSC_EXTENDED_HEADER_LENGTH];
    const uint8_t* chunk;
    rc = source_chunk_header(src, nchunk, header, &chunk);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Can not get the `chunk` %" PRId64 ".", nchunk);
      break;
    }
    int64_t pos = header_len + tally.cbytes;
    int32_t stored = tally_chunk(&tally, chunk);
    rc = stored;
    if (stored <= 0) {
      continue;
    }
    if (chunk != header) {
      rc = fill_put(frame, &capacity, io_cb, fp, pos, chunk, stored);
    }
    else if (frame->cframe != NULL) {
      rc = fill_reserve(frame, &capacity, pos, stored);
      if (rc >= 0) {
        rc = source_read_chunk(src, nchunk, stored, frame->cframe + pos);
      }
    }
    else {
      if ((size_t)stored > buffer_capacity) {
        blosc2_tmp_free(buffer, buffer_capacity);
        buffer = blosc2_tmp_malloc((size_t)stored, &buffer_capacity);
        if (buffer == NULL) {
          buffer_capacity = 0;
          rc = BLOSC2_ERROR_MEMORY_ALLOC;
          break;
        }
      }
      rc = source_read_chunk(src, nchunk, stored, buffer);
      if (rc >= 0) {
        rc = fill_put(frame, &capacity, io_cb, fp, pos, buffer, stored);
      }
    }
  }
  blosc2_tmp_free(buffer, buffer_capacity);

  uint8_t* off_chunk = NULL;
  int32_t off_cbytes = 0;
  if (rc >= 0) {
    off_cbytes = compress_offsets(tally.offsets, tally.off_nbytes,
                                  tally.off_nbytes + BLOSC2_MAX_OVERHEAD, &off_chunk);
    rc = off_cbytes;
  }
  if (rc >= 0) {
    rc = fill_put(frame, &capacity, io_cb, fp, header_len + tally.cbytes, off_chunk, off_cbytes);
  }
  free(off_chunk);
  if (fp != NULL) {
    frame_writer_release(frame, io_cb, fp);
  }
  if (rc >= 0) {
    rc = tally_finish(&tally, frame, schunk, header_len + tally.cbytes + off_cbytes + frame->trailer_len);
  }
  free(tally.offsets);
  if (rc < 0) {
    return rc;
  }
  // This also trims the in-memory frame to its final size
  return frame_update_trailer(frame, schunk);
}


/* Fill the empty contiguous frame of `schunk` with the chunks of `src`, as they are.

   The frame and the counters of `schunk` end up the same as after appending every
   chunk with blosc2_schunk_append_chunk(), but that re-reads and recompresses all
   the offsets, rewrites the header and the trailer and grows the frame for each
   chunk, after the caller has made a private copy of it.  Here every chunk is
   copied (or written) once, straight from `src`, and the offsets, header and
   trailer are written once at the end. */
int frame_fill_from_schunk(blosc2_frame_s* frame, blosc2_schunk* schunk, blosc2_schunk* src) {
  if (frame->sframe || schunk->nchunks != 0) {
    BLOSC_TRACE_ERROR("Only an empty contiguous frame can be filled.");
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  if (src->nchunks == 0) {
    return BLOSC2_ERROR_SUCCESS;
  }
  int rc = frame_lock(frame, true);
  if (rc < 0) {
    return rc;
  }
  rc = frame_check_stale(frame);
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  if (rc >= 0) {
    rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes, &blocksize, &chunksize,
                         &nchunks, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                         frame->schunk->storage->io);
  }
  chunk_source source;
  if (rc >= 0) {
    rc = source_open(&source, src);
  }
  if (rc >= 0) {
    rc = fill_from_schunk_unlocked(frame, schunk, &source, header_len);
    source_close(&source);
  }
  frame_unlock(frame);
  return rc < 0 ? rc : BLOSC2_ERROR_SUCCESS;
}


/* Write the contiguous frame of `schunk`, an empty in-memory copy of `src` (see
   blosc2_schunk_copy()), filled with the chunks of `src`, into the buffer that
   `alloc` returns for its exact length.  This is the frame that
   frame_fill_from_schunk() would build, but written in place: a first pass over
   the chunk headers gives the length, a second one copies the chunks.  Returns the
   frame length, or a negative value on error. */
int64_t frame_fill_alloc(blosc2_frame_s* frame, blosc2_schunk* schunk, blosc2_schunk* src,
                         uint8_t* (*alloc)(int64_t len, void* user_data), void* user_data) {
  if (frame->cframe == NULL || schunk->nchunks != 0) {
    BLOSC_TRACE_ERROR("Only an empty in-memory frame can be filled.");
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  int32_t header_len;
  from_big(&header_len, frame->cframe + FRAME_HEADER_LEN, sizeof(header_len));
  // With no chunks yet, the trailer follows the header
  int64_t trailer_len = frame->trailer_len;
  if (header_len + trailer_len != frame->len) {
    BLOSC_TRACE_ERROR("The frame to fill is not empty.");
    return BLOSC2_ERROR_INVALID_PARAM;
  }

  // Each pass holds the lock of the source, but not the call to `alloc` in
  // between, which may wait for something (Python's GIL) that a writer to the
  // source holds while it waits for the lock
  chunk_source source;
  int rc = source_open(&source, src);
  if (rc < 0) {
    return rc;
  }
  int64_t nchunks = src->nchunks;
  chunk_tally tally;
  rc = tally_init(&tally, nchunks, schunk->chunksize);
  // What each chunk takes in the frame, for the second pass
  int32_t* stored = malloc((size_t)(nchunks > 0 ? nchunks : 1) * sizeof(int32_t));
  if (rc >= 0 && stored == NULL) {
    rc = BLOSC2_ERROR_MEMORY_ALLOC;
  }
  for (int64_t nchunk = 0; rc >= 0 && nchunk < nchunks; nchunk++) {
    uint8_t header[BLOSC_EXTENDED_HEADER_LENGTH];
    const uint8_t* chunk;
    rc = source_chunk_header(&source, nchunk, header, &chunk);
    if (rc < 0) {
      BLOSC_TRACE_ERROR("Can not get the `chunk` %" PRId64 ".", nchunk);
      break;
    }
    rc = stored[nchunk] = tally_chunk(&tally, chunk);
  }
  source_close(&source);
  uint8_t* off_chunk = NULL;
  int32_t off_cbytes = 0;
  if (rc >= 0 && nchunks > 0) {
    off_cbytes = compress_offsets(tally.offsets, tally.off_nbytes,
                                  tally.off_nbytes + BLOSC2_MAX_OVERHEAD, &off_chunk);
    rc = off_cbytes;
  }
  int64_t len = header_len + tally.cbytes + off_cbytes + trailer_len;
  uint8_t* dest = NULL;
  if (rc >= 0) {
    dest = alloc(len, user_data);
    if (dest == NULL) {
      BLOSC_TRACE_ERROR("Cannot get a buffer for the frame.");
      rc = BLOSC2_ERROR_MEMORY_ALLOC;
    }
  }
  if (rc >= 0) {
    memcpy(dest + len - trailer_len, frame->cframe + header_len, (size_t)trailer_len);
    if (nchunks > 0) {
      // The header also gets the final length
      rc = tally_finish(&tally, frame, schunk, len);
    }
  }
  if (rc >= 0) {
    memcpy(dest, frame->cframe, (size_t)header_len);
    rc = source_open(&source, src);
    if (rc >= 0 && src->nchunks != nchunks) {
      BLOSC_TRACE_ERROR("The super-chunk changed while serializing it.");
      rc = BLOSC2_ERROR_DATA;
    }
    // The chunks go one after the other, straight from the source
    int64_t pos = header_len;
    for (int64_t nchunk = 0; rc >= 0 && nchunk < nchunks; nchunk++) {
      if (stored[nchunk] > 0) {
        rc = source_read_chunk(&source, nchunk, stored[nchunk], dest + pos);
        pos += stored[nchunk];
        continue;
      }
      // Coded in its offset by the first pass: check that it still is
      uint8_t header[BLOSC_EXTENDED_HEADER_LENGTH];
      const uint8_t* chunk;
      rc = source_chunk_header(&source, nchunk, header, &chunk);
      if (rc >= 0 && !chunk_special_in_offset(chunk, sw32_(chunk + BLOSC2_CHUNK_CBYTES))) {
        BLOSC_TRACE_ERROR("The super-chunk changed while serializing it.");
        rc = BLOSC2_ERROR_DATA;
      }
    }
    source_close(&source);
    if (rc >= 0 && off_cbytes > 0) {
      memcpy(dest + header_len + tally.cbytes, off_chunk, (size_t)off_cbytes);
    }
  }
  free(stored);
  free(off_chunk);
  free(tally.offsets);
  return rc < 0 ? rc : len;
}


void* frame_insert_chunk(blosc2_frame_s* frame, int64_t nchunk, void* chunk, blosc2_schunk* schunk) {
  uint8_t* chunk_ = chunk;
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                           &blocksize, &chunksize, &nchunks,
                           NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                           frame->schunk->storage->io);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    return NULL;
  }
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to refresh the frame state from disk.");
    return NULL;
  }
  int32_t chunk_cbytes;
  rc = blosc2_cbuffer_sizes(chunk_, NULL, &chunk_cbytes, NULL);
  if (rc < 0) {
    return NULL;
  }

  // Get the current offsets
  int32_t off_nbytes = (int32_t) ((nchunks + 1) * sizeof(int64_t));
  int64_t* offsets = (int64_t *) malloc((size_t)off_nbytes);
  if (offsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for offsets.");
    return NULL;
  }
  if (nchunks > 0) {
    int32_t coffsets_cbytes = 0;
    uint8_t *coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
    if (coffsets == NULL) {
      BLOSC_TRACE_ERROR("Cannot get the offsets for the frame.");
      free(offsets);
      return NULL;
    }
    // Decompress offsets
    blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
    blosc2_context *dctx = blosc2_create_dctx(off_dparams);
    if (dctx == NULL) {
      BLOSC_TRACE_ERROR("Error while creating the decompression context");
      free(offsets);
      return NULL;
    }
    int32_t prev_nbytes = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes, offsets, off_nbytes);
    blosc2_free_ctx(dctx);
    if (prev_nbytes < 0) {
      free(offsets);
      BLOSC_TRACE_ERROR("Cannot decompress the offsets chunk.");
      return NULL;
    }
  }

  // TODO: Improvement: Check if new chunk is smaller than previous one

  // Move offsets
  for (int64_t i = nchunks; i > nchunk; i--) {
    offsets[i] = offsets[i - 1];
  }
  // Add the new offset
  int64_t sframe_chunk_id = -1;
  int special_value = chunk_special_in_offset(chunk_, chunk_cbytes);
  if (special_value) {
    special_offset(offsets + nchunk, special_value);
    chunk_cbytes = 0;   // we don't need to store the chunk
  }
  else if (frame->sframe) {
    for (int64_t i = 0; i <= nchunks; ++i) {
      // offsets[nchunk] is still uninitialized here
      if (i != nchunk && offsets[i] > sframe_chunk_id) {
        sframe_chunk_id = offsets[i];
      }
    }
    offsets[nchunk] = ++sframe_chunk_id;
  }
  else {
    offsets[nchunk] = cbytes;
  }

  // Re-compress the offsets again
  uint8_t* off_chunk;
  int32_t new_off_cbytes = compress_offsets(offsets, off_nbytes, off_nbytes + BLOSC2_MAX_OVERHEAD,
                                            &off_chunk);
  free(offsets);
  if (new_off_cbytes < 0) {
    return NULL;
  }

  int64_t new_cbytes = cbytes + chunk_cbytes;

  int64_t new_frame_len;
  if (frame->sframe) {
    new_frame_len = header_len + 0 + new_off_cbytes + frame->trailer_len;
  }
  else {
    new_frame_len = header_len + new_cbytes + new_off_cbytes + frame->trailer_len;
  }

  // Add the chunk and update meta
  void* fp = NULL;
  if (frame->cframe != NULL) {
    /* Make space for the new chunk and copy it (keeping the frame if that fails) */
    uint8_t* framep = realloc(frame->cframe, (size_t)new_frame_len);
    if (framep == NULL) {
      BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
      goto failed;
    }
    frame->cframe = framep;
    /* Copy the chunk */
    memcpy(framep + header_len + cbytes, chunk, (size_t)chunk_cbytes);
    /* Copy the offsets */
    memcpy(framep + header_len + new_cbytes, off_chunk, (size_t)new_off_cbytes);
  } else {
    int64_t wbytes;

    int64_t io_pos = 0;
    blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      goto failed;
    }

    if (frame->sframe) {
      if (chunk_cbytes != 0) {
        if (sframe_chunk_id < 0) {
          BLOSC_TRACE_ERROR("The chunk id (%" PRId64 ") is not correct", sframe_chunk_id);
          goto failed;
        }
        if (sframe_create_chunk(frame, chunk, sframe_chunk_id, chunk_cbytes) == NULL) {
          BLOSC_TRACE_ERROR("Cannot write the full chunk.");
          goto failed;
        }
      }
      // Update the offsets chunk in the chunks frame
      fp = sframe_open_index(frame->urlpath, "rb+",
                             frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        goto failed;
      }
      io_pos = frame->file_offset + header_len + 0;
    }
    else {
      // Regular frame
      fp = frame_writer_acquire(frame, io_cb);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        goto failed;
      }
      io_pos = frame->file_offset + header_len + cbytes;
      wbytes = io_cb->write(chunk, 1, chunk_cbytes, io_pos, fp);  // the new chunk
      io_pos += chunk_cbytes;
      if (wbytes != chunk_cbytes) {
        BLOSC_TRACE_ERROR("Cannot write the full chunk to frame (wrote %" PRId64 " of %" PRId64
                          " bytes at position %" PRId64 ", nchunk=%" PRId64 ").",
                          wbytes, (int64_t)chunk_cbytes, io_pos - (int64_t)chunk_cbytes, nchunk);
        frame->file_end = 0;
        frame_writer_release(frame, io_cb, fp);
        goto failed;
      }
    }
    wbytes = io_cb->write(off_chunk, 1, new_off_cbytes, io_pos, fp);  // the new offsets
    frame_writer_release(frame, io_cb, fp);
    if (wbytes != new_off_cbytes) {
      BLOSC_TRACE_ERROR("Cannot write the offsets to frame.");
      frame->file_end = 0;
      goto failed;
    }
    // Invalidate the cache for chunk offsets
    if (frame->coffsets != NULL) {
      if (frame->coffsets_needs_free)
        free(frame->coffsets);
      frame->coffsets = NULL;
    }
  }
  free(off_chunk);

  frame->len = new_frame_len;
  rc = frame_update_header(frame, schunk, false);
  if (rc < 0) {
    frame->len = frame_len;
    return NULL;
  }

  rc = frame_update_trailer(frame, schunk);
  if (rc < 0) {
    frame->len = frame_len;
    return NULL;
  }

  return frame;

  failed:
  // The caller still owns the chunk; the offsets chunk is ours
  free(off_chunk);
  return NULL;
}


int frame_move_range(blosc2_io_cb *io_cb, void *fp, int64_t src_pos, int64_t dst_pos, int64_t length, int64_t cap) {
  if (io_cb == NULL || fp == NULL) {
    BLOSC_TRACE_ERROR("Invalid arguments for frame_move_range.");
    return BLOSC2_ERROR_NULL_POINTER;
  }
  if (length < 0 || src_pos < 0 || dst_pos < 0) {
    BLOSC_TRACE_ERROR("Negative arguments for frame_move_range: src_pos=%" PRId64
                      ", dst_pos=%" PRId64 ", length=%" PRId64 ".",
                      src_pos, dst_pos, length);
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  if (length == 0 || src_pos == dst_pos) {
    return BLOSC2_ERROR_SUCCESS;
  }
  if (src_pos > INT64_MAX - length || dst_pos > INT64_MAX - length) {
    BLOSC_TRACE_ERROR("Position overflow in frame_move_range: src_pos=%" PRId64
                      ", dst_pos=%" PRId64 ", length=%" PRId64 ".",
                      src_pos, dst_pos, length);
    return BLOSC2_ERROR_INVALID_PARAM;
  }

  int64_t effective_cap = (cap > 0) ? cap : (int64_t)FRAME_TAIL_COPY_BUFFER_CAP;
  int64_t buf_size = length < effective_cap ? length : effective_cap;
  if ((uint64_t)buf_size > SIZE_MAX) {
    BLOSC_TRACE_ERROR("Buffer size exceeds SIZE_MAX in frame_move_range.");
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }

  uint8_t *scratch = malloc((size_t)buf_size);
  if (scratch == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate scratch memory (%" PRId64 " bytes) for frame tail movement.", buf_size);
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }

  if (dst_pos < src_pos) {
    // Shrink: move forward starting from the beginning of the range
    int64_t offset = 0;
    while (offset < length) {
      int64_t seg_len = length - offset;
      if (seg_len > buf_size) {
        seg_len = buf_size;
      }
      int64_t cur_src = src_pos + offset;
      int64_t cur_dst = dst_pos + offset;

      void *read_ptr = scratch;
      if (!io_cb->is_allocation_necessary) {
        read_ptr = NULL;
      }
      int64_t rbytes = io_cb->read(&read_ptr, 1, seg_len, cur_src, fp);
      if (rbytes != seg_len || (!io_cb->is_allocation_necessary && read_ptr == NULL)) {
        free(scratch);
        BLOSC_TRACE_ERROR("Cannot read payload segment from frame (read %" PRId64 " of %" PRId64 " bytes at %" PRId64 ").",
                          rbytes, seg_len, cur_src);
        return BLOSC2_ERROR_FILE_READ;
      }
      if (!io_cb->is_allocation_necessary) {
        memcpy(scratch, read_ptr, (size_t)seg_len);
      }

      int64_t wbytes = io_cb->write(scratch, 1, seg_len, cur_dst, fp);
      if (wbytes != seg_len) {
        free(scratch);
        BLOSC_TRACE_ERROR("Cannot write payload segment to frame (wrote %" PRId64 " of %" PRId64 " bytes at %" PRId64 ").",
                          wbytes, seg_len, cur_dst);
        return BLOSC2_ERROR_FILE_WRITE;
      }
      offset += seg_len;
    }
  } else {
    // Growth: move backward starting from the end of the range
    int64_t offset = length;
    while (offset > 0) {
      int64_t seg_len = offset < buf_size ? offset : buf_size;
      offset -= seg_len;
      int64_t cur_src = src_pos + offset;
      int64_t cur_dst = dst_pos + offset;

      void *read_ptr = scratch;
      if (!io_cb->is_allocation_necessary) {
        read_ptr = NULL;
      }
      int64_t rbytes = io_cb->read(&read_ptr, 1, seg_len, cur_src, fp);
      if (rbytes != seg_len || (!io_cb->is_allocation_necessary && read_ptr == NULL)) {
        free(scratch);
        BLOSC_TRACE_ERROR("Cannot read payload segment from frame (read %" PRId64 " of %" PRId64 " bytes at %" PRId64 ").",
                          rbytes, seg_len, cur_src);
        return BLOSC2_ERROR_FILE_READ;
      }
      if (!io_cb->is_allocation_necessary) {
        memcpy(scratch, read_ptr, (size_t)seg_len);
      }

      int64_t wbytes = io_cb->write(scratch, 1, seg_len, cur_dst, fp);
      if (wbytes != seg_len) {
        free(scratch);
        BLOSC_TRACE_ERROR("Cannot write payload segment to frame (wrote %" PRId64 " of %" PRId64 " bytes at %" PRId64 ").",
                          wbytes, seg_len, cur_dst);
        return BLOSC2_ERROR_FILE_WRITE;
      }
    }
  }

  free(scratch);
  return BLOSC2_ERROR_SUCCESS;
}


/* Remember the hole [offset, offset + len) in the payload of a frame inside frame_begin_updates(). */
static void holes_add(blosc2_frame_s* frame, int64_t offset, int64_t len) {
  if (len <= 0) {
    return;
  }
  if (frame->nholes == frame->holes_cap) {
    int64_t cap = frame->holes_cap > 0 ? 2 * frame->holes_cap : 64;
    int64_t* holes = realloc(frame->holes, (size_t)cap * 2 * sizeof(int64_t));
    if (holes == NULL) {
      frame->holes_lost = true;  // the frame stays valid, just with some dead space
      return;
    }
    frame->holes = holes;
    frame->holes_cap = cap;
  }
  frame->holes[2 * frame->nholes] = offset;
  frame->holes[2 * frame->nholes + 1] = len;
  frame->nholes++;
}


/* The free run made of [offset, offset + len) and the known holes next to it on either side, which are taken
   out of the list. */
static void holes_take_run(blosc2_frame_s* frame, int64_t offset, int64_t len, int64_t* run_start,
                           int64_t* run_len) {
  int64_t start = offset;
  int64_t end = offset + len;
  for (int64_t i = 0; i < frame->nholes;) {
    int64_t hole_start = frame->holes[2 * i];
    int64_t hole_end = hole_start + frame->holes[2 * i + 1];
    if (hole_end == start || hole_start == end) {
      start = (hole_end == start) ? hole_start : start;
      end = (hole_start == end) ? hole_end : end;
      frame->nholes--;
      frame->holes[2 * i] = frame->holes[2 * frame->nholes];
      frame->holes[2 * i + 1] = frame->holes[2 * frame->nholes + 1];
      i = 0;  // the longer run may touch a hole seen already
      continue;
    }
    i++;
  }
  *run_start = start;
  *run_len = end - start;
}


/* Where a chunk update inside frame_begin_updates() puts a chunk of new_len bytes (0 for a chunk stored in
   its offset) that replaces one stored at [old_offset, old_offset + old_len) (old_offset < 0: stored
   nowhere), in a payload that ends at *payload_end (updated).  Nothing else moves: the chunk goes into the
   free run made of its old place and the holes around it when it fits there (a sequential overwrite slides
   one hole along the payload that way), else to the end of the payload; the space left over becomes a
   hole.  A free run at the end of the payload just grows or shrinks the payload. */
static int64_t holes_place(blosc2_frame_s* frame, int64_t old_offset, int64_t old_len, int64_t new_len,
                           int64_t* payload_end) {
  int64_t start = *payload_end;
  int64_t len = 0;
  if (old_offset >= 0) {
    holes_take_run(frame, old_offset, old_len, &start, &len);
  }
  if (start + len == *payload_end) {
    *payload_end = start + new_len;
    return start;
  }
  if (new_len <= len) {
    holes_add(frame, start + new_len, len - new_len);
    return start;
  }
  holes_add(frame, start, len);
  int64_t offset = *payload_end;
  *payload_end += new_len;
  return offset;
}


void* frame_update_chunk(blosc2_frame_s* frame, int64_t nchunk, void* chunk, blosc2_schunk* schunk,
                         int32_t cbytes_old) {
  uint8_t *chunk_ = (uint8_t *) chunk;
  int64_t* offsets = NULL;
  uint8_t* off_chunk = NULL;
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                           &blocksize, &chunksize, &nchunks,
                           NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                           frame->schunk->storage->io);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    goto failed;
  }
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to refresh the frame state from disk.");
    goto failed;
  }
  if (nchunk >= nchunks) {
    BLOSC_TRACE_ERROR("The chunk must already exist.");
    goto failed;
  }

  int32_t chunk_cbytes;
  rc = blosc2_cbuffer_sizes(chunk, NULL, &chunk_cbytes, NULL);
  if (rc < 0) {
    goto failed;
  }

  // Get the current offsets
  int32_t off_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &off_nbytes)) {
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    goto failed;
  }
  offsets = (int64_t *) malloc((size_t)off_nbytes);
  if (offsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for offsets.");
    goto failed;
  }
  if (nchunks > 0) {
    int32_t coffsets_cbytes = 0;
    uint8_t *coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
    if (coffsets == NULL) {
      BLOSC_TRACE_ERROR("Cannot get the offsets for the frame.");
      goto failed;
    }
    // Decompress offsets
    blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
    blosc2_context *dctx = blosc2_create_dctx(off_dparams);
    if (dctx == NULL) {
      BLOSC_TRACE_ERROR("Error while creating the decompression context");
      goto failed;
    }
    int32_t prev_nbytes = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes, offsets, off_nbytes);
    blosc2_free_ctx(dctx);
    if (prev_nbytes < 0) {
      BLOSC_TRACE_ERROR("Cannot decompress the offsets chunk.");
      goto failed;
    }
  }
  int64_t old_offset = 0;
  if (!frame->sframe) {
    old_offset = offsets[nchunk];
  }

  // Add the new offset
  int64_t sframe_chunk_id = -1;
  int64_t old_sframe_chunk_id = -1;
  int64_t delta_cbytes = 0;
  bool old_chunk_is_regular = (!frame->sframe && old_offset >= 0);
  bool new_chunk_is_regular = true;
  int64_t new_chunk_offset = cbytes;
  // Inside frame_begin_updates(), a resized chunk leaves a hole instead of moving the payload behind it
  bool defer = !frame->sframe && frame->updates_depth > 0;
  if (frame->sframe) {
    if (offsets[nchunk] < 0) {
      sframe_chunk_id = -1;
    }
    else {
      // In case there was a reorder in a sframe
      sframe_chunk_id = offsets[nchunk];
      old_sframe_chunk_id = offsets[nchunk];
    }
  }
  int special_value = chunk_special_in_offset(chunk_, chunk_cbytes);
  bool is_special_chunk = special_value != 0;
  if (is_special_chunk) {
    special_offset(offsets + nchunk, special_value);
  }
  else if (frame->sframe) {
    if (sframe_chunk_id < 0) {
      for (int64_t i = 0; i < nchunks; ++i) {
        if (offsets[i] > sframe_chunk_id) {
          sframe_chunk_id = offsets[i];
        }
      }
      offsets[nchunk] = ++sframe_chunk_id;
    }
  }
  else {
    if (old_chunk_is_regular) {
      new_chunk_offset = old_offset;
    }
    offsets[nchunk] = new_chunk_offset;
  }
  if (is_special_chunk) {
    chunk_cbytes = 0;   // Special chunks are encoded in offsets and have no stored payload.
    new_chunk_is_regular = false;
  }
  if (defer) {
    if (old_chunk_is_regular || new_chunk_is_regular) {
      int64_t payload_end = cbytes;
      new_chunk_offset = holes_place(frame, old_chunk_is_regular ? old_offset : -1, cbytes_old, chunk_cbytes,
                                     &payload_end);
      delta_cbytes = payload_end - cbytes;
      if (new_chunk_is_regular) {
        offsets[nchunk] = new_chunk_offset;
      }
    }
  }
  else if (!frame->sframe) {
    if (old_chunk_is_regular) {
      delta_cbytes = (int64_t)chunk_cbytes - cbytes_old;
      for (int64_t i = 0; i < nchunks; ++i) {
        if (i == nchunk || offsets[i] < 0) {
          continue;
        }
        if (offsets[i] > old_offset) {
          offsets[i] += delta_cbytes;
        }
      }
    }
    else if (new_chunk_is_regular) {
      delta_cbytes = chunk_cbytes;
    }
  }
  // Re-compress the offsets again
  int32_t new_off_cbytes = compress_offsets(offsets, off_nbytes, off_nbytes + BLOSC2_MAX_OVERHEAD,
                                            &off_chunk);
  free(offsets);
  offsets = NULL;
  if (new_off_cbytes < 0) {
    goto failed;
  }

  int64_t new_cbytes = cbytes;
  if (!frame->sframe) {
    new_cbytes += delta_cbytes;
  }
  else {
    new_cbytes = schunk->cbytes;
  }
  int64_t new_frame_len;
  if (frame->sframe) {
    // The chunk is not stored in the frame
    new_frame_len = header_len + 0 + new_off_cbytes + frame->trailer_len;
  }
  else {
    new_frame_len = header_len + new_cbytes + new_off_cbytes + frame->trailer_len;
  }

  void* fp = NULL;
  if (frame->cframe != NULL) {
    uint8_t* framep = frame->cframe;
    if (new_frame_len > frame->len) {
      // Keep the frame if the realloc fails
      framep = realloc(framep, (size_t)new_frame_len);
      if (framep == NULL) {
        BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
        goto failed;
      }
      frame->cframe = framep;
    }
    if (!frame->sframe && old_chunk_is_regular && !defer) {
      int64_t tail_src_offset = old_offset + cbytes_old;
      int64_t tail_dst_offset = old_offset + chunk_cbytes;
      int64_t tail_nbytes = cbytes - tail_src_offset;
      if (tail_nbytes > 0 && tail_src_offset != tail_dst_offset) {
        memmove(framep + header_len + tail_dst_offset, framep + header_len + tail_src_offset, (size_t)tail_nbytes);
      }
    }
    if (!frame->sframe && new_chunk_is_regular) {
      memcpy(framep + header_len + new_chunk_offset, chunk, (size_t)chunk_cbytes);
    }
    /* Copy the offsets */
    memcpy(framep + header_len + new_cbytes, off_chunk, (size_t)new_off_cbytes);
  } else {
    int64_t wbytes;

    int64_t io_pos = 0;
    blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      goto failed;
    }

    if (frame->sframe) {
      // Create or update chunk file only for chunks with stored payload (regular or VALUE)
      if (!is_special_chunk && sframe_chunk_id >= 0) {
        if (sframe_create_chunk(frame, chunk, sframe_chunk_id, chunk_cbytes) == NULL) {
          BLOSC_TRACE_ERROR("Cannot write the full chunk.");
          goto failed;
        }
      }
      // Update the offsets chunk in the chunks frame
      fp = sframe_open_index(frame->urlpath, "rb+",
                             frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        goto failed;
      }
      io_pos = frame->file_offset + header_len + 0;
    }
    else {
      // Regular frame
      fp = frame_writer_acquire(frame, io_cb);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        goto failed;
      }
      if (old_chunk_is_regular && !defer) {
        int64_t tail_src_offset = old_offset + cbytes_old;
        int64_t tail_dst_offset = old_offset + chunk_cbytes;
        int64_t tail_nbytes = cbytes - tail_src_offset;
        if (tail_nbytes < 0) {
          frame_writer_release(frame, io_cb, fp);
          BLOSC_TRACE_ERROR("Invalid tail length for frame payload compaction.");
          goto failed;
        }
        if (tail_nbytes > 0 && tail_src_offset != tail_dst_offset) {
          int rc_move = frame_move_range(io_cb, fp,
                                         frame->file_offset + header_len + tail_src_offset,
                                         frame->file_offset + header_len + tail_dst_offset,
                                         tail_nbytes, 0);
          if (rc_move < 0) {
            frame->file_end = 0;
            frame_writer_release(frame, io_cb, fp);
            BLOSC_TRACE_ERROR("Cannot compact the payload tail in frame.");
            goto failed;
          }
        }
      }
      if (new_chunk_is_regular) {
        io_pos = frame->file_offset + header_len + new_chunk_offset;
        wbytes = io_cb->write(chunk, 1, chunk_cbytes, io_pos, fp);  // the new chunk
        if (wbytes != chunk_cbytes) {
          BLOSC_TRACE_ERROR("Cannot write the full chunk to frame (wrote %" PRId64 " of %" PRId64
                            " bytes at position %" PRId64 ", nchunk=%" PRId64 ").",
                            wbytes, (int64_t)chunk_cbytes, io_pos, nchunk);
          frame->file_end = 0;
          frame_writer_release(frame, io_cb, fp);
          goto failed;
        }
      }
      io_pos = frame->file_offset + header_len + new_cbytes;
    }
    wbytes = io_cb->write(off_chunk, 1, new_off_cbytes, io_pos, fp);  // the new offsets
    frame_writer_release(frame, io_cb, fp);
    if (wbytes != new_off_cbytes) {
      BLOSC_TRACE_ERROR("Cannot write the offsets to frame.");
      frame->file_end = 0;
      goto failed;
    }
    // Invalidate the cache for chunk offsets
    if (frame->coffsets != NULL) {
      if (frame->coffsets_needs_free)
        free(frame->coffsets);
      frame->coffsets = NULL;
    }
  }
  free(off_chunk);
  off_chunk = NULL;

  if (defer) {
    // The header describes the payload as it lies, holes included
    schunk->cbytes = new_cbytes;
  }
  frame->len = new_frame_len;
  rc = frame_update_header(frame, schunk, false);
  if (rc < 0) {
    frame->len = frame_len;
    goto failed;
  }

  rc = frame_update_trailer(frame, schunk);
  if (rc < 0) {
    frame->len = frame_len;
    goto failed;
  }

  if (frame->sframe && is_special_chunk && old_sframe_chunk_id >= 0) {
    const blosc2_io *io = (frame->schunk && frame->schunk->storage) ? frame->schunk->storage->io : NULL;
    int err = sframe_delete_chunk(frame->urlpath, old_sframe_chunk_id, io);
    if (err != BLOSC2_ERROR_SUCCESS) {
      BLOSC_TRACE_WARNING("Unable to evict old chunk %" PRId64 " from sframe (error %d).",
                          old_sframe_chunk_id, err);
      // Do not return NULL: the update was already committed to the index and trailer.
      // Distinguish orphan cleanup failure from failure to commit the update.
    }
  }

  return frame;

  failed:
  free(offsets);
  free(off_chunk);
  return NULL;
}


static int compare_holes(const void* a, const void* b) {
  int64_t x = *(const int64_t*)a;
  int64_t y = *(const int64_t*)b;
  return (x > y) - (x < y);
}


/* Close the holes that updates inside frame_begin_updates() left in the payload of a contiguous frame: the
   stretches between them move towards the start, each once, and the chunks keep their order in the payload.
   Only the known holes are closed (the space of deleted chunks stays, as without frame_begin_updates()).  An
   I/O error while moving leaves a torn frame, as one in the tail move of a single update does. */
static int frame_compact(blosc2_frame_s* frame, blosc2_schunk* schunk) {
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes, &blocksize, &chunksize,
                           &nchunks, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                           frame->schunk->storage->io);
  if (rc < 0) {
    return rc;
  }
  int64_t nholes = frame->nholes;
  int64_t* holes = frame->holes;  // (offset, length) pairs
  qsort(holes, (size_t)nholes, 2 * sizeof(int64_t), compare_holes);
  for (int64_t k = 0; k < nholes; k++) {
    int64_t next = (k + 1 < nholes) ? holes[2 * (k + 1)] : cbytes;
    if (holes[2 * k] < 0 || holes[2 * k + 1] <= 0 || holes[2 * k] + holes[2 * k + 1] > next) {
      BLOSC_TRACE_ERROR("Inconsistent holes in the payload of the frame.");
      return BLOSC2_ERROR_DATA;
    }
  }
  if (nchunks == 0) {
    return BLOSC2_ERROR_SUCCESS;  // all chunks got deleted: no offsets to rewrite, the payload stays
  }

  int32_t off_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &off_nbytes)) {
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    return BLOSC2_ERROR_DATA;
  }
  int64_t* offsets = malloc((size_t)off_nbytes);
  int64_t* shifts = malloc((size_t)(nholes + 1) * sizeof(int64_t));  // shifts[k]: length of the first k holes
  uint8_t* off_chunk = NULL;
  blosc2_io_cb* io_cb = NULL;
  void* fp = NULL;
  if (offsets == NULL || shifts == NULL) {
    rc = BLOSC2_ERROR_MEMORY_ALLOC;
    goto out;
  }
  shifts[0] = 0;
  for (int64_t k = 0; k < nholes; k++) {
    shifts[k + 1] = shifts[k] + holes[2 * k + 1];
  }
  int32_t coffsets_cbytes = 0;
  uint8_t* coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
  if (coffsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot get the offsets for the frame.");
    rc = BLOSC2_ERROR_DATA;
    goto out;
  }
  blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
  blosc2_context* dctx = blosc2_create_dctx(off_dparams);
  if (dctx == NULL) {
    rc = BLOSC2_ERROR_MEMORY_ALLOC;
    goto out;
  }
  rc = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes, offsets, off_nbytes);
  blosc2_free_ctx(dctx);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Cannot decompress the offsets chunk.");
    goto out;
  }

  // A stored chunk moves by the length of the holes before it
  for (int64_t i = 0; i < nchunks; i++) {
    if (offsets[i] < 0) {
      continue;  // stored in its offset
    }
    int64_t lo = 0;
    int64_t hi = nholes;  // the holes [0, lo) start before the chunk, [hi, nholes) after it
    while (lo < hi) {
      int64_t mid = lo + (hi - lo) / 2;
      if (holes[2 * mid] < offsets[i]) {
        lo = mid + 1;
      }
      else {
        hi = mid;
      }
    }
    if ((lo > 0 && offsets[i] < holes[2 * (lo - 1)] + holes[2 * (lo - 1) + 1]) ||
        (lo < nholes && offsets[i] == holes[2 * lo])) {
      BLOSC_TRACE_ERROR("Chunk %" PRId64 " lies in a hole of the frame.", i);
      rc = BLOSC2_ERROR_DATA;
      goto out;
    }
    offsets[i] -= shifts[lo];
  }

  if (frame->cframe == NULL) {
    io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      rc = BLOSC2_ERROR_PLUGIN_IO;
      goto out;
    }
    fp = frame_writer_acquire(frame, io_cb);
    if (fp == NULL) {
      BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
      rc = BLOSC2_ERROR_FILE_OPEN;
      goto out;
    }
  }
  // The stretch behind each hole moves down by the length of all holes up to it
  for (int64_t k = 0; k < nholes; k++) {
    int64_t shift = shifts[k + 1];
    int64_t src = holes[2 * k] + holes[2 * k + 1];
    int64_t len = ((k + 1 < nholes) ? holes[2 * (k + 1)] : cbytes) - src;
    if (len == 0) {
      continue;
    }
    if (frame->cframe != NULL) {
      memmove(frame->cframe + header_len + src - shift, frame->cframe + header_len + src, (size_t)len);
    }
    else {
      rc = frame_move_range(io_cb, fp, frame->file_offset + header_len + src,
                            frame->file_offset + header_len + src - shift, len, 0);
      if (rc < 0) {
        BLOSC_TRACE_ERROR("Cannot move chunks in the frame to close its holes.");
        frame->file_end = 0;
        goto out;
      }
    }
  }
  int64_t new_cbytes = cbytes - shifts[nholes];

  int32_t off_cbytes = compress_offsets(offsets, off_nbytes, off_nbytes + BLOSC2_MAX_OVERHEAD, &off_chunk);
  if (off_cbytes < 0) {
    rc = off_cbytes;
    goto out;
  }
  if (frame->cframe != NULL) {
    // The payload got shorter: the offsets fit into the frame
    memcpy(frame->cframe + header_len + new_cbytes, off_chunk, (size_t)off_cbytes);
  }
  else {
    int64_t wbytes = io_cb->write(off_chunk, 1, off_cbytes, frame->file_offset + header_len + new_cbytes, fp);
    if (wbytes != off_cbytes) {
      BLOSC_TRACE_ERROR("Cannot write the offsets to frame.");
      frame->file_end = 0;
      rc = BLOSC2_ERROR_FILE_WRITE;
      goto out;
    }
  }
  if (frame->coffsets != NULL) {
    if (frame->coffsets_needs_free) {
      free(frame->coffsets);
    }
    frame->coffsets = NULL;
  }
  schunk->cbytes = new_cbytes;
  frame->len = header_len + new_cbytes + off_cbytes + frame->trailer_len;
  rc = frame_update_header(frame, schunk, false);
  if (rc >= 0) {
    rc = frame_update_trailer(frame, schunk);  // cuts the file too
  }

  out:
  if (fp != NULL) {
    frame_writer_release(frame, io_cb, fp);
  }
  free(off_chunk);
  free(offsets);
  free(shifts);
  return rc < 0 ? rc : BLOSC2_ERROR_SUCCESS;
}


int frame_begin_updates(blosc2_frame_s* frame) {
  if (frame == NULL) {
    return BLOSC2_ERROR_SUCCESS;
  }
  int rc = frame_lock(frame, true);
  if (rc < 0) {
    return rc;
  }
  if (!frame->sframe && frame->updates_depth++ == 0) {
    frame->nholes = 0;
    frame->holes_lost = false;
  }
  return BLOSC2_ERROR_SUCCESS;
}


int frame_end_updates(blosc2_frame_s* frame, blosc2_schunk* schunk) {
  if (frame == NULL) {
    return BLOSC2_ERROR_SUCCESS;
  }
  int rc = BLOSC2_ERROR_SUCCESS;
  if (!frame->sframe && frame->updates_depth > 0 && --frame->updates_depth == 0) {
    if (frame->holes_lost) {
      // Valid, just larger: the holes stay as dead space, like the space of deleted chunks
      BLOSC_TRACE_WARNING("Lost track of the free space in the frame; it stays.");
    }
    else if (frame->nholes > 0) {
      rc = frame_compact(frame, schunk);
    }
    frame->nholes = 0;
    frame->holes_lost = false;
  }
  int unlock_rc = frame_unlock(frame);
  return rc < 0 ? rc : unlock_rc;
}


void* frame_delete_chunk(blosc2_frame_s* frame, int64_t nchunk, blosc2_schunk* schunk) {
  int64_t* offsets = NULL;
  uint8_t* off_chunk = NULL;
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int rc = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                           &blocksize, &chunksize,  &nchunks,
                           NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, frame->schunk->storage->io);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to get meta info from frame.");
    goto failed;
  }
  rc = frame_refresh_if_stale(frame, frame_len);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Unable to refresh the frame state from disk.");
    goto failed;
  }

  // Get the current offsets
  int32_t off_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &off_nbytes)) {
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    goto failed;
  }
  offsets = (int64_t *) malloc((size_t)off_nbytes);
  if (offsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for offsets.");
    goto failed;
  }
  if (nchunks > 0) {
    int32_t coffsets_cbytes = 0;
    uint8_t *coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
    if (coffsets == NULL) {
      BLOSC_TRACE_ERROR("Cannot get the offsets for the frame.");
      goto failed;
    }
    // Decompress offsets
    blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
    blosc2_context *dctx = blosc2_create_dctx(off_dparams);
    if (dctx == NULL) {
      BLOSC_TRACE_ERROR("Error while creating the decompression context");
      goto failed;
    }
    int32_t prev_nbytes = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes, offsets, off_nbytes);
    blosc2_free_ctx(dctx);
    if (prev_nbytes < 0) {
      BLOSC_TRACE_ERROR("Cannot decompress the offsets chunk.");
      goto failed;
    }
  }

  // Delete the new offset
  for (int64_t i = nchunk; i < nchunks - 1; i++) {
    offsets[i] = offsets[i + 1];
  }
  offsets[nchunks - 1] = 0;

  // Re-compress the offsets again: one less, in the room of the old ones
  int32_t new_off_cbytes = compress_offsets(offsets, off_nbytes - (int32_t)sizeof(int64_t),
                                            off_nbytes + BLOSC2_MAX_OVERHEAD, &off_chunk);
  free(offsets);
  offsets = NULL;
  if (new_off_cbytes < 0) {
    goto failed;
  }

  int64_t new_cbytes = cbytes;

  int64_t new_frame_len;
  if (frame->sframe) {
    new_frame_len = header_len + 0 + new_off_cbytes + frame->trailer_len;
  }
  else {
    new_frame_len = header_len + new_cbytes + new_off_cbytes + frame->trailer_len;
  }

  // Add the chunk and update meta
  FILE* fp = NULL;
  if (frame->cframe != NULL) {
    /* Make room for the offsets (keeping the frame if that fails) */
    uint8_t* framep = realloc(frame->cframe, (size_t)new_frame_len);
    if (framep == NULL) {
      BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
      goto failed;
    }
    frame->cframe = framep;
    /* Copy the offsets */
    memcpy(framep + header_len + new_cbytes, off_chunk, (size_t)new_off_cbytes);
  } else {
    blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      goto failed;
    }

    size_t wbytes;
    int64_t io_pos = 0;
    if (frame->sframe) {
      int64_t offset;
      rc = get_coffset(frame, header_len, cbytes, nchunk, nchunks, &offset);
      if (rc < 0) {
        BLOSC_TRACE_ERROR("Unable to get offset to chunk %" PRId64 ".", nchunk);
        goto failed;
      }
      if (offset >= 0){
        // Remove the chunk file only if it is not a special value chunk
        const blosc2_io *io = (frame->schunk && frame->schunk->storage) ? frame->schunk->storage->io : NULL;
        int err = sframe_delete_chunk(frame->urlpath, offset, io);
        if (err != BLOSC2_ERROR_SUCCESS) {
          BLOSC_TRACE_WARNING("Unable to delete chunk file %" PRId64 " from sframe (error %d).", offset, err);
        }
      }
      // Update the offsets chunk in the chunks frame
      fp = sframe_open_index(frame->urlpath, "rb+", frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        goto failed;
      }
      io_pos = frame->file_offset + header_len + 0;
    }
    else {
      // Regular frame
      fp = frame_writer_acquire(frame, io_cb);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        goto failed;
      }
      io_pos = frame->file_offset + header_len + cbytes;
    }
    wbytes = io_cb->write(off_chunk, 1, new_off_cbytes, io_pos, fp);  // the new offsets
    frame_writer_release(frame, io_cb, fp);
    if (wbytes != (size_t)new_off_cbytes) {
      BLOSC_TRACE_ERROR("Cannot write the offsets to frame.");
      goto failed;
    }
    // Invalidate the cache for chunk offsets
    if (frame->coffsets != NULL) {
      if (frame->coffsets_needs_free)
        free(frame->coffsets);
      frame->coffsets = NULL;
    }
  }
  free(off_chunk);
  off_chunk = NULL;

  frame->len = new_frame_len;
  rc = frame_update_header(frame, schunk, false);
  if (rc < 0) {
    frame->len = frame_len;
    goto failed;
  }

  rc = frame_update_trailer(frame, schunk);
  if (rc < 0) {
    frame->len = frame_len;
    goto failed;
  }

  return frame;

  failed:
  free(offsets);
  free(off_chunk);
  return NULL;
}


int frame_reorder_offsets(blosc2_frame_s* frame, const int64_t* offsets_order, blosc2_schunk* schunk) {
  // Get header info
  int32_t header_len;
  int64_t frame_len;
  int64_t nbytes;
  int64_t cbytes;
  int32_t blocksize;
  int32_t chunksize;
  int64_t nchunks;
  int ret = get_header_info(frame, &header_len, &frame_len, &nbytes, &cbytes,
                            &blocksize, &chunksize, &nchunks,
                            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                            frame->schunk->storage->io);
  if (ret < 0) {
      BLOSC_TRACE_ERROR("Cannot get the header info for the frame.");
      return ret;
  }
  ret = frame_refresh_if_stale(frame, frame_len);
  if (ret < 0) {
    BLOSC_TRACE_ERROR("Unable to refresh the frame state from disk.");
    return ret;
  }

  // Get the current offsets and add one more
  int32_t off_nbytes;
  if (!blosc2_nchunks_to_offsets_nbytes(nchunks, &off_nbytes)) {
    BLOSC_TRACE_ERROR("Too many chunks for offsets representation.");
    return BLOSC2_ERROR_DATA;
  }
  int64_t* offsets = (int64_t *) malloc((size_t)off_nbytes);
  if (offsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot allocate memory for offsets.");
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }

  int32_t coffsets_cbytes = 0;
  uint8_t *coffsets = get_coffsets(frame, header_len, cbytes, nchunks, &coffsets_cbytes);
  if (coffsets == NULL) {
    BLOSC_TRACE_ERROR("Cannot get the offsets for the frame.");
    free(offsets);
    return BLOSC2_ERROR_DATA;
  }

  // Decompress offsets
  blosc2_dparams off_dparams = BLOSC2_DPARAMS_DEFAULTS;
  blosc2_context *dctx = blosc2_create_dctx(off_dparams);
  if (dctx == NULL) {
    BLOSC_TRACE_ERROR("Error while creating the decompression context");
    return BLOSC2_ERROR_NULL_POINTER;
  }
  int32_t prev_nbytes = blosc2_decompress_ctx(dctx, coffsets, coffsets_cbytes,
                                              offsets, off_nbytes);
  blosc2_free_ctx(dctx);
  if (prev_nbytes < 0) {
    free(offsets);
    BLOSC_TRACE_ERROR("Cannot decompress the offsets chunk.");
    return prev_nbytes;
  }

  // Make a copy of the chunk offsets and reorder it
  int64_t *offsets_copy = malloc(prev_nbytes);
  memcpy(offsets_copy, offsets, prev_nbytes);

  for (int64_t i = 0; i < nchunks; ++i) {
    offsets[i] = offsets_copy[offsets_order[i]];
  }
  free(offsets_copy);

  // Re-compress the offsets again
  uint8_t* off_chunk;
  int32_t new_off_cbytes = compress_offsets(offsets, off_nbytes, off_nbytes + BLOSC2_MAX_OVERHEAD,
                                            &off_chunk);
  free(offsets);
  if (new_off_cbytes < 0) {
    return new_off_cbytes;
  }
  int64_t new_frame_len;
  if (frame->sframe) {
    // The chunks are not in the frame
    new_frame_len = header_len + 0 + new_off_cbytes + frame->trailer_len;
  }
  else {
    new_frame_len = header_len + cbytes + new_off_cbytes + frame->trailer_len;
  }

  if (frame->cframe != NULL) {
    uint8_t* framep = frame->cframe;
    /* Make space for the new chunk and copy it */
    frame->cframe = framep = realloc(framep, (size_t)new_frame_len);
    if (framep == NULL) {
      BLOSC_TRACE_ERROR("Cannot realloc space for the frame.");
      return BLOSC2_ERROR_MEMORY_ALLOC;
    }
    /* Copy the offsets */
    memcpy(framep + header_len + cbytes, off_chunk, (size_t)new_off_cbytes);
  }
  else {
    void* fp = NULL;

    blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      return BLOSC2_ERROR_PLUGIN_IO;
    }

    int64_t io_pos = 0;
    if (frame->sframe) {
      // Update the offsets chunk in the chunks frame
      fp = sframe_open_index(frame->urlpath, "rb+",
                             frame->schunk->storage->io);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset + header_len + 0;
    }
    else {
      // Regular frame
      fp = frame_writer_acquire(frame, io_cb);
      if (fp == NULL) {
        BLOSC_TRACE_ERROR("Error opening file in: %s", frame->urlpath);
        return BLOSC2_ERROR_FILE_OPEN;
      }
      io_pos = frame->file_offset + header_len + cbytes;
    }
    int64_t wbytes = io_cb->write(off_chunk, 1, new_off_cbytes, io_pos, fp);  // the new offsets
    frame_writer_release(frame, io_cb, fp);
    if (wbytes != new_off_cbytes) {
      BLOSC_TRACE_ERROR("Cannot write the offsets to frame.");
      return BLOSC2_ERROR_FILE_WRITE;
    }
  }

  // Invalidate the cache for chunk offsets
  if (frame->coffsets != NULL) {
    if (frame->coffsets_needs_free)
      free(frame->coffsets);
    frame->coffsets = NULL;
  }
  free(off_chunk);

  frame->len = new_frame_len;
  int rc = frame_update_header(frame, schunk, false);
  if (rc < 0) {
    return rc;
  }

  rc = frame_update_trailer(frame, schunk);
  if (rc < 0) {
    return rc;
  }

  return 0;
}

/* Decompress and return a chunk that is part of a frame. */
int frame_decompress_chunk(blosc2_context *dctx, blosc2_frame_s* frame, int64_t nchunk, void *dest, int32_t nbytes) {
  uint8_t* src = NULL;
  bool needs_free = false;
  int32_t srcsize;
  int32_t chunk_nbytes;
  int32_t chunk_cbytes;
  int rc;

  size_t capacity = 0;
  rc = get_chunk(frame, nchunk, &src, &needs_free, &capacity);
  if (rc < 0) {
    BLOSC_TRACE_ERROR("Cannot get the chunk in position %" PRId64 ".", nchunk);
    goto end;
  }
  srcsize = rc;
  if (srcsize < BLOSC_MIN_HEADER_LENGTH) {
    BLOSC_TRACE_ERROR("Not enough input to read the header of chunk %" PRId64 ".", nchunk);
    rc = BLOSC2_ERROR_READ_BUFFER;
    goto end;
  }

  rc = blosc2_cbuffer_sizes(src, &chunk_nbytes, &chunk_cbytes, NULL);
  if (rc < 0) {
    goto end;
  }
  /* The header cbytes is used as srcsize below, so it must fit in what was read */
  if (chunk_cbytes > srcsize) {
    BLOSC_TRACE_ERROR("Invalid chunk size in frame for chunk %" PRId64 ".", nchunk);
    rc = BLOSC2_ERROR_INVALID_HEADER;
    goto end;
  }

  /* Create a buffer for destination */
  if (chunk_nbytes > nbytes) {
    BLOSC_TRACE_ERROR("Not enough space for decompressing in dest.");
    rc = BLOSC2_ERROR_WRITE_BUFFER;
    goto end;
  }
  /* And decompress it */
  dctx->header_overhead = BLOSC_EXTENDED_HEADER_LENGTH;
  int chunksize = rc = blosc2_decompress_ctx(dctx, src, chunk_cbytes, dest, nbytes);
  if (chunksize < 0 || chunksize != chunk_nbytes) {
    BLOSC_TRACE_ERROR("Error in decompressing chunk.");
    if (chunksize >= 0)
      rc = BLOSC2_ERROR_FAILURE;
  }
  end:
  if (needs_free) {
    blosc2_tmp_free(src, capacity);
  }
  return rc;
}
