/*********************************************************************
  Blosc - Blocked Shuffling and Compression Library

  Copyright (c) 2021  Blosc Development Team <blosc@blosc.org>
  https://blosc.org
  License: BSD 3-Clause (see LICENSE.txt)

  See LICENSE.txt for details about copyright and rights to use.
**********************************************************************/

#if defined(__linux__) && !defined(_GNU_SOURCE)
// madvise() and mincore() are not POSIX: make them visible despite -D_XOPEN_SOURCE=600 (as in frame.c)
#define _GNU_SOURCE
#endif

#include "b2nd.h"
#include "b2nd-private.h"
#include "prefetch.h"
#include "context.h"
#include "frame.h"
#include "blosc-private.h"
#include "blosc2/blosc2-common.h"
#include "blosc2.h"
#include "blosc-checked.h"

#include <inttypes.h>
#include <limits.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#if defined(__linux__)
#include <sys/mman.h>
#include <unistd.h>
#ifndef MADV_POPULATE_WRITE
#define MADV_POPULATE_WRITE 23
#endif
#endif


int b2nd_serialize_meta(int8_t ndim, const int64_t *shape, const int32_t *chunkshape,
                        const int32_t *blockshape, const char *dtype, int8_t dtype_format,
                        uint8_t **smeta) {
  if (dtype == NULL) {
    dtype = B2ND_DEFAULT_DTYPE;
  }
  // dtype checks
  if (dtype_format < 0) {
    BLOSC_TRACE_ERROR("dtype_format cannot be negative");
    BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
  }
  size_t dtype_len0 = strlen(dtype);
  if (dtype_len0 > INT32_MAX) {
    BLOSC_TRACE_ERROR("dtype is too large (len > %d)", INT32_MAX);
    BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
  }
  const int32_t dtype_len = (int32_t) dtype_len0;
  // Allocate space for b2nd metalayer
  int32_t max_smeta_len = (int32_t) (1 + 1 + 1 + (1 + ndim * (1 + sizeof(int64_t))) +
                                     (1 + ndim * (1 + sizeof(int32_t))) + (1 + ndim * (1 + sizeof(int32_t))) +
                                     1 + 1 + sizeof(int32_t) + dtype_len);
  *smeta = malloc((size_t) max_smeta_len);
  BLOSC_ERROR_NULL(*smeta, BLOSC2_ERROR_MEMORY_ALLOC);
  uint8_t *pmeta = *smeta;

  // Build an array with 7 entries (version, ndim, shape, chunkshape, blockshape, dtype_format, dtype)
  *pmeta++ = 0x90 + 7;

  // version entry
  *pmeta++ = B2ND_METALAYER_VERSION;  // positive fixnum (7-bit positive integer)

  // ndim entry
  *pmeta++ = (uint8_t) ndim;  // positive fixnum (7-bit positive integer)

  // shape entry
  *pmeta++ = (uint8_t) (0x90) + ndim;  // fix array with ndim elements
  for (uint8_t i = 0; i < ndim; i++) {
    *pmeta++ = 0xd3;  // int64
    swap_store(pmeta, shape + i, sizeof(int64_t));
    pmeta += sizeof(int64_t);
  }

  // chunkshape entry
  *pmeta++ = (uint8_t) (0x90) + ndim;  // fix array with ndim elements
  for (uint8_t i = 0; i < ndim; i++) {
    *pmeta++ = 0xd2;  // int32
    swap_store(pmeta, chunkshape + i, sizeof(int32_t));
    pmeta += sizeof(int32_t);
  }

  // blockshape entry
  *pmeta++ = (uint8_t) (0x90) + ndim;  // fix array with ndim elements
  for (uint8_t i = 0; i < ndim; i++) {
    *pmeta++ = 0xd2;  // int32
    swap_store(pmeta, blockshape + i, sizeof(int32_t));
    pmeta += sizeof(int32_t);
  }

  // dtype entry
  *pmeta++ = dtype_format;  // positive fixint (7-bit positive integer)
  *pmeta++ = (uint8_t) (0xdb);  // str with up to 2^31 elements
  swap_store(pmeta, &dtype_len, sizeof(int32_t));
  pmeta += sizeof(int32_t);
  memcpy(pmeta, dtype, dtype_len);
  pmeta += dtype_len;

  int32_t slen = (int32_t) (pmeta - *smeta);
  if (max_smeta_len != slen) {
    BLOSC_TRACE_ERROR("meta length is inconsistent!");
    return BLOSC2_ERROR_FAILURE;
  }

  return (int)slen;
}


int b2nd_deserialize_meta(const uint8_t *smeta, int32_t smeta_len, int8_t *ndim, int64_t *shape,
                          int32_t *chunkshape, int32_t *blockshape, char **dtype, int8_t *dtype_format) {
  return b2nd_deserialize_meta_inline(smeta, smeta_len, ndim, shape, chunkshape, blockshape, dtype, dtype_format);
}


static int validate_shape_chunkshape_blockshape(int8_t ndim, const int64_t *shape,
                                                const int32_t *chunkshape, const int32_t *blockshape) {
  for (int i = 0; i < ndim; ++i) {
    if (shape[i] < 0) {
      BLOSC_TRACE_ERROR("shape[%d] cannot be negative", i);
      return BLOSC2_ERROR_INVALID_PARAM;
    }
    if (chunkshape[i] < 0 || blockshape[i] < 0) {
      BLOSC_TRACE_ERROR("chunkshape[%d] and blockshape[%d] cannot be negative", i, i);
      return BLOSC2_ERROR_INVALID_PARAM;
    }

    bool chunkshape_is_zero = (chunkshape[i] == 0);
    bool blockshape_is_zero = (blockshape[i] == 0);

    // Keep compatibility with contexts that use chunkshape=0 (e.g. empty slices).
    // Reject only invalid tuples that can produce divide-by-zero when chunkshape is non-zero.
    if (blockshape_is_zero && !chunkshape_is_zero) {
      BLOSC_TRACE_ERROR("blockshape[%d] cannot be zero when chunkshape[%d] is non-zero", i, i);
      return BLOSC2_ERROR_INVALID_PARAM;
    }
  }

  return BLOSC2_ERROR_SUCCESS;
}



/* Recompute the cached geometry (shape/extshape/strides/...) without touching
 * the b2nd metalayer.  Used both by update_shape() and by the refresh path
 * that re-syncs the struct from a metalayer another handle rewrote. */
static int update_shape_struct(b2nd_array_t *array, int8_t ndim, const int64_t *shape,
                               const int32_t *chunkshape, const int32_t *blockshape) {
  BLOSC_ERROR(validate_shape_chunkshape_blockshape(ndim, shape, chunkshape, blockshape));

  array->ndim = ndim;
  array->nitems = 1;
  array->extnitems = 1;
  array->extchunknitems = 1;
  array->chunknitems = 1;
  array->blocknitems = 1;
  for (int i = 0; i < B2ND_MAX_DIM; ++i) {
    if (i < ndim) {
      array->shape[i] = shape[i];
      array->chunkshape[i] = chunkshape[i];
      array->blockshape[i] = blockshape[i];
      if (array->chunkshape[i] != 0) {
        if (shape[i] % array->chunkshape[i] == 0) {
          array->extshape[i] = shape[i];
        } else {
          // Rounding shape up to the next chunk must not wrap int64
          if (shape[i] > INT64_MAX - chunkshape[i]) {
            BLOSC_TRACE_ERROR("shape[%d] is too large to round up to chunkshape[%d]", i, i);
            return BLOSC2_ERROR_INVALID_PARAM;
          }
          array->extshape[i] = shape[i] + chunkshape[i] - shape[i] % chunkshape[i];
        }
        if (chunkshape[i] % blockshape[i] == 0) {
          array->extchunkshape[i] = chunkshape[i];
        } else {
          // Done in 64 bits: the sum of two int32 values does not fit in int32,
          // and extchunkshape is int64 anyway
          array->extchunkshape[i] =
                  (int64_t) chunkshape[i] + blockshape[i] - chunkshape[i] % blockshape[i];
        }
      } else {
        array->extchunkshape[i] = chunkshape[i];
        array->extshape[i] = 0;
      }
    } else {
      array->blockshape[i] = 1;
      array->chunkshape[i] = 1;
      array->extshape[i] = 1;
      array->extchunkshape[i] = 1;
      array->shape[i] = 1;
    }
    // Crafted metadata can make any of these products wrap, which is UB and
    // lands in divisors and allocation sizes downstream (see #795)
    if (!blosc2_checked_mul_i64_nonneg(array->nitems, array->shape[i], &array->nitems) ||
        !blosc2_checked_mul_i64_nonneg(array->extnitems, array->extshape[i], &array->extnitems) ||
        !blosc2_checked_mul_i64_nonneg(array->extchunknitems, array->extchunkshape[i],
                                       &array->extchunknitems) ||
        !blosc2_checked_mul_i32_nonneg(array->chunknitems, array->chunkshape[i], &array->chunknitems) ||
        !blosc2_checked_mul_i32_nonneg(array->blocknitems, array->blockshape[i], &array->blocknitems)) {
      BLOSC_TRACE_ERROR("shape, chunkshape or blockshape product overflows at dimension %d", i);
      return BLOSC2_ERROR_INVALID_PARAM;
    }
  }

  // Compute strides
  if (ndim > 0) {
    array->item_array_strides[ndim - 1] = 1;
    array->item_extchunk_strides[ndim - 1] = 1;
    array->item_chunk_strides[ndim - 1] = 1;
    array->item_block_strides[ndim - 1] = 1;
    array->block_chunk_strides[ndim - 1] = 1;
    array->chunk_array_strides[ndim - 1] = 1;
  }
  for (int i = ndim - 2; i >= 0; --i) {
    // Treat (chunkshape[i+1] == 0) the same as (shape[i+1] == 0):  the
    // dimension carries no actual chunking and any stride into it is moot.
    // validate_shape_chunkshape_blockshape allows the chunkshape==0
    // combination (paired with blockshape==0) as a placeholder for empty
    // contexts (see example_empty_shape.c).  Without this guard a crafted
    // b2nd metalayer with shape[i+1]>0 but chunkshape[i+1]==blockshape[i+1]==0
    // -- accepted by the validator -- reaches the (extchunkshape / blockshape)
    // division below as 0/0, which is undefined behaviour and aborts the
    // process with SIGFPE on x86.  Crafted cframes loaded via b2nd_from_schunk
    // / b2nd_open / b2nd_from_cframe would otherwise crash any consumer.
    if (shape[i + 1] != 0 && array->chunkshape[i + 1] != 0 &&
        array->blockshape[i + 1] != 0) {
      if (!blosc2_checked_mul_i64_nonneg(array->item_array_strides[i + 1], array->shape[i + 1],
                                         &array->item_array_strides[i]) ||
          !blosc2_checked_mul_i64_nonneg(array->item_extchunk_strides[i + 1], array->extchunkshape[i + 1],
                                         &array->item_extchunk_strides[i]) ||
          !blosc2_checked_mul_i64_nonneg(array->item_chunk_strides[i + 1], array->chunkshape[i + 1],
                                         &array->item_chunk_strides[i]) ||
          !blosc2_checked_mul_i64_nonneg(array->item_block_strides[i + 1], array->blockshape[i + 1],
                                         &array->item_block_strides[i]) ||
          !blosc2_checked_mul_i64_nonneg(array->block_chunk_strides[i + 1],
                                         array->extchunkshape[i + 1] / array->blockshape[i + 1],
                                         &array->block_chunk_strides[i])) {
        BLOSC_TRACE_ERROR("Dimension stride overflow in array shape");
        return BLOSC2_ERROR_INVALID_PARAM;
      }
      // Unused here, and this product can overflow for large (or damaged)
      // shapes: 0 then, as for an empty dimension
      int64_t extent;
      if (!blosc2_checked_mul_i64_nonneg(array->extshape[i + 1], array->chunkshape[i + 1], &extent) ||
          !blosc2_checked_mul_i64_nonneg(array->chunk_array_strides[i + 1], extent,
                                         &array->chunk_array_strides[i])) {
        array->chunk_array_strides[i] = 0;
      }
    } else {
      array->item_array_strides[i] = 0;
      array->item_extchunk_strides[i] = 0;
      array->item_chunk_strides[i] = 0;
      array->item_block_strides[i] = 0;
      array->block_chunk_strides[i] = 0;
      array->chunk_array_strides[i] = 0;
    }
  }
  return BLOSC2_ERROR_SUCCESS;
}


/* Publish the current cached geometry into the "b2nd" metalayer. */
static int publish_shape_meta(b2nd_array_t *array) {
  if (!array->sc) {
    return BLOSC2_ERROR_SUCCESS;
  }
  uint8_t *smeta = NULL;
  // Serialize the dimension info ...
  int32_t smeta_len =
          b2nd_serialize_meta(array->ndim, array->shape, array->chunkshape, array->blockshape,
                              array->dtype, array->dtype_format, &smeta);
  if (smeta_len < 0) {
    BLOSC_TRACE_ERROR("Error during serializing dims info for Blosc2 NDim");
    BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
  }
  // ... and update it in its metalayer
  if (blosc2_meta_exists(array->sc, "b2nd") < 0) {
    if (blosc2_meta_add(array->sc, "b2nd", smeta, smeta_len) < 0) {
      BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
    }
  } else {
    if (blosc2_meta_update(array->sc, "b2nd", smeta, smeta_len) < 0) {
      BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
    }
  }
  free(smeta);
  // The meta mutation bumped the schunk change tick; this struct is in sync
  array->last_tick = array->sc->change_tick;

  return BLOSC2_ERROR_SUCCESS;
}


int update_shape(b2nd_array_t *array, int8_t ndim, const int64_t *shape,
                 const int32_t *chunkshape, const int32_t *blockshape) {
  BLOSC_ERROR(update_shape_struct(array, ndim, shape, chunkshape, blockshape));
  return publish_shape_meta(array);
}


/* Re-sync the cached geometry when another handle changed the b2nd metalayer
 * behind our back (the growth-SWMR case: a writer resizes, readers follow).
 * A no-op for arrays not backed by an on-disk frame.
 * Returns 1 if the geometry was re-synced, 0 if it was already current, or
 * a negative error code. */
static int refresh_if_stale(b2nd_array_t *array) {
  blosc2_schunk *sc = array->sc;
  if (sc == NULL || sc->frame == NULL) {
    return BLOSC2_ERROR_SUCCESS;
  }
  BLOSC_ERROR(frame_check_stale((blosc2_frame_s *) sc->frame));
  if (array->last_tick == sc->change_tick) {
    return BLOSC2_ERROR_SUCCESS;
  }

  uint8_t *smeta;
  int32_t smeta_len;
  if (blosc2_meta_get(sc, "b2nd", &smeta, &smeta_len) < 0) {
    if (blosc2_meta_get(sc, "caterva", &smeta, &smeta_len) < 0) {
      // blosc2_meta_get() itself is a pure in-memory lookup on
      // schunk->metalayers[], but that array was just repopulated by
      // frame_check_stale() -> frame_refresh_if_stale() -> frame_get_metalayers(),
      // which does its *own*, fully independent disk read (its own fresh
      // get_header_info() + header re-read, frame.c) -- separate from both
      // frame_check_stale()'s header read and the trailer read a few lines
      // up in this same call chain. Without locking, nothing holds these
      // reads together atomically, so this one can catch the header mid
      // rewrite just as easily as the other two; a b2nd array always has
      // one of these two metalayers from creation, so a miss here reflects
      // that specific read landing in a torn window, not a genuine
      // absence. Same opportunistic treatment as those reads: keep the
      // cached view and let the next poll (its own fresh, independent read)
      // resolve it, instead of hard-erroring on what is normally transient.
      return BLOSC2_ERROR_SUCCESS;
    }
  }
  int8_t ndim;
  int64_t shape[B2ND_MAX_DIM];
  int32_t chunkshape[B2ND_MAX_DIM];
  int32_t blockshape[B2ND_MAX_DIM];
  char *dtype;
  int8_t dtype_format;
  int rc = b2nd_deserialize_meta(smeta, smeta_len, &ndim, shape, chunkshape, blockshape,
                                 &dtype, &dtype_format);
  free(smeta);
  BLOSC_ERROR(rc);
  free(dtype);

  // Shape-only SWMR scope (matching HDF5): chunk/block geometry or ndim
  // changing under a live handle is a misuse of the single-writer contract,
  // not something to follow silently.
  if (ndim != array->ndim ||
      memcmp(chunkshape, array->chunkshape, ndim * sizeof(int32_t)) != 0 ||
      memcmp(blockshape, array->blockshape, ndim * sizeof(int32_t)) != 0) {
    BLOSC_TRACE_ERROR("ndim/chunkshape/blockshape changed behind this handle; "
                      "only shape changes are followed");
    BLOSC_ERROR(BLOSC2_ERROR_DATA);
  }

  BLOSC_ERROR(update_shape_struct(array, ndim, shape, chunkshape, blockshape));
  array->last_tick = sc->change_tick;

  return 1;
}


int b2nd_refresh(b2nd_array_t *array) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  return refresh_if_stale(array);
}


int array_without_schunk(b2nd_context_t *ctx, b2nd_array_t **array) {
  /* Create a b2nd_array_t buffer */
  (*array) = (b2nd_array_t *) malloc(sizeof(b2nd_array_t));
  BLOSC_ERROR_NULL(*array, BLOSC2_ERROR_MEMORY_ALLOC);

  (*array)->sc = NULL;
  (*array)->last_tick = 0;

  (*array)->ndim = ctx->ndim;
  int64_t *shape = ctx->shape;
  int32_t *chunkshape = ctx->chunkshape;
  int32_t *blockshape = ctx->blockshape;
  // update_shape() rejects shapes whose products overflow, so this can fail on
  // crafted metadata.  Hand back NULL rather than the half-built array, which
  // would otherwise leak and leave callers with a non-NULL pointer on error.
  int rc = update_shape(*array, ctx->ndim, shape, chunkshape, blockshape);
  if (rc < 0) {
    free(*array);
    *array = NULL;
    BLOSC_ERROR(rc);
  }

  if (ctx->dtype != NULL) {
    (*array)->dtype = malloc(strlen(ctx->dtype) + 1);
    strcpy((*array)->dtype, ctx->dtype);
  } else {
    (*array)->dtype = NULL;
  }

  (*array)->dtype_format = ctx->dtype_format;

  // The partition cache (empty initially)
  (*array)->chunk_cache.data = NULL;
  (*array)->chunk_cache.nchunk = -1;  // means no valid cache yet

  return BLOSC2_ERROR_SUCCESS;
}


int array_new(b2nd_context_t *ctx, int special_value, b2nd_array_t **array) {
  BLOSC_ERROR(array_without_schunk(ctx, array));

  int rc = BLOSC2_ERROR_FAILURE;
  blosc2_schunk *sc = blosc2_schunk_new(ctx->b2_storage);
  if (sc == NULL) {
    BLOSC_TRACE_ERROR("Pointer is NULL");
    goto failed;
  }
  // Freed with the array on failure
  (*array)->sc = sc;
  // Set the chunksize for the schunk, as it cannot be derived from storage
  if (sc->typesize <= 0) {
    BLOSC_TRACE_ERROR("Invalid chunk parameters");
    rc = BLOSC2_ERROR_INVALID_PARAM;
    goto failed;
  }
  if ((*array)->extchunknitems < 0) {
    BLOSC_TRACE_ERROR("Invalid chunk parameters");
    rc = BLOSC2_ERROR_INVALID_PARAM;
    goto failed;
  }
  if ((uint64_t)(*array)->extchunknitems > (uint64_t)SIZE_MAX) {
    BLOSC_TRACE_ERROR("extchunknitems too large");
    rc = BLOSC2_ERROR_INVALID_PARAM;
    goto failed;
  }
  size_t chunkbytes_size = 0;
  if (!blosc2_checked_mul_size((size_t)(*array)->extchunknitems, (size_t)sc->typesize, &chunkbytes_size)) {
    BLOSC_TRACE_ERROR("Chunksize overflows size limits");
    rc = BLOSC2_ERROR_INVALID_PARAM;
    goto failed;
  }
  if (chunkbytes_size > BLOSC2_MAX_BUFFERSIZE || chunkbytes_size > INT32_MAX) {
    BLOSC_TRACE_ERROR("Chunksize exceeds maximum of %d", BLOSC2_MAX_BUFFERSIZE);
    rc = BLOSC2_ERROR_MAX_BUFSIZE_EXCEEDED;
    goto failed;
  }
  int32_t chunksize = (int32_t)chunkbytes_size;
  sc->chunksize = chunksize;

  // Serialize the dimension info
  if (sc->nmetalayers >= BLOSC2_MAX_METALAYERS) {
    BLOSC_TRACE_ERROR("the number of metalayers for this schunk has been exceeded");
    goto failed;
  }
  uint8_t *smeta = NULL;
  int32_t smeta_len = b2nd_serialize_meta(ctx->ndim,
                                          (*array)->shape,
                                          (*array)->chunkshape,
                                          (*array)->blockshape,
                                          (*array)->dtype,
                                          (*array)->dtype_format,
                                          &smeta);
  if (smeta_len < 0) {
    BLOSC_TRACE_ERROR("error during serializing dims info for Blosc2 NDim");
    goto failed;
  }

  // And store it in b2nd metalayer
  int meta_rc = blosc2_meta_add(sc, "b2nd", smeta, smeta_len);
  free(smeta);
  if (meta_rc < 0) {
    goto failed;
  }

  for (int i = 0; i < ctx->nmetalayers; ++i) {
    char *name = ctx->metalayers[i].name;
    uint8_t *data = ctx->metalayers[i].content;
    int32_t size = ctx->metalayers[i].content_len;
    if (blosc2_meta_add(sc, name, data, size) < 0) {
      goto failed;
    }
  }

  // Fill schunk with uninit values
  if ((*array)->nitems != 0) {
    int64_t nchunks = (*array)->extnitems / (*array)->chunknitems;
    int64_t nitems = nchunks * (*array)->extchunknitems;
    if (blosc2_schunk_fill_special(sc, nitems, special_value, chunksize) < 0) {
      BLOSC_TRACE_ERROR("Error filling the super-chunk");
      goto failed;
    }
  }

  return BLOSC2_ERROR_SUCCESS;

  failed:
  b2nd_free(*array);
  *array = NULL;
  return rc;
}


int b2nd_uninit(b2nd_context_t *ctx, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(ctx, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  BLOSC_ERROR(array_new(ctx, BLOSC2_SPECIAL_UNINIT, array));

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_empty(b2nd_context_t *ctx, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(ctx, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  // Fill with zeros to avoid variable cratios
  BLOSC_ERROR(array_new(ctx, BLOSC2_SPECIAL_ZERO, array));

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_zeros(b2nd_context_t *ctx, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(ctx, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  BLOSC_ERROR(array_new(ctx, BLOSC2_SPECIAL_ZERO, array));

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_nans(b2nd_context_t *ctx, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(ctx, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  BLOSC_ERROR(array_new(ctx, BLOSC2_SPECIAL_NAN, array));

  const int32_t typesize = (*array)->sc->typesize;
  if (typesize != 4 && typesize != 8)
  {
    BLOSC_TRACE_ERROR("Unsupported typesize for NaN");
    return BLOSC2_ERROR_DATA;
  }

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_full(b2nd_context_t *ctx, b2nd_array_t **array, const void *fill_value) {
  BLOSC_ERROR_NULL(ctx, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  BLOSC_ERROR(b2nd_empty(ctx, array));

  if ((*array)->sc->typesize <= 0) {
    BLOSC_TRACE_ERROR("Invalid chunk parameters");
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  if ((*array)->extchunknitems < 0) {
    BLOSC_TRACE_ERROR("Invalid chunk parameters");
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  if ((uint64_t)(*array)->extchunknitems > (uint64_t)SIZE_MAX) {
    BLOSC_TRACE_ERROR("extchunknitems too large");
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  size_t chunkbytes_size = 0;
  if (!blosc2_checked_mul_size((size_t)(*array)->extchunknitems, (size_t)(*array)->sc->typesize, &chunkbytes_size)) {
    BLOSC_TRACE_ERROR("Chunk bytes overflows size limits");
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  if (chunkbytes_size > BLOSC2_MAX_BUFFERSIZE || chunkbytes_size > INT32_MAX) {
    BLOSC_TRACE_ERROR("Chunk bytes exceeds maximum of %d", BLOSC2_MAX_BUFFERSIZE);
    return BLOSC2_ERROR_MAX_BUFSIZE_EXCEEDED;
  }
  int32_t chunkbytes = (int32_t)chunkbytes_size;

  blosc2_cparams *cparams;
  if (blosc2_schunk_get_cparams((*array)->sc, &cparams) != 0) {
    BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
  }

  int32_t chunksize = BLOSC_EXTENDED_HEADER_LENGTH + (*array)->sc->typesize;
  uint8_t *chunk = malloc(chunksize);
  BLOSC_ERROR_NULL(chunk, BLOSC2_ERROR_MEMORY_ALLOC);
  int rc = blosc2_chunk_repeatval(*cparams, chunkbytes, chunk, chunksize, fill_value);
  free(cparams);
  for (int64_t i = 0; rc >= 0 && i < (*array)->sc->nchunks; ++i) {
    if (blosc2_schunk_update_chunk((*array)->sc, i, chunk, true) < 0) {
      rc = BLOSC2_ERROR_FAILURE;
    }
  }
  free(chunk);
  if (rc < 0) {
    BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
  }

  return BLOSC2_ERROR_SUCCESS;
}


/* Reject a super-chunk that contradicts its b2nd metalayer, as a damaged frame
 * does: readers trust the shape for chunk indexes and result sizes, and the
 * chunk shape and typesize for the size of every chunk.  Only clear
 * contradictions count: chunks missing for the shape, and chunks of another
 * size than the chunk shape makes.  The dtype is not looked at: b2nd stores it
 * for others and accepts any along with any typesize. */
static int check_schunk_matches_meta(const blosc2_schunk *schunk, const b2nd_array_t *array) {
  // Every chunk the shape covers exists: arrays are created with all of them,
  // and resizes add chunks before they publish a larger shape.  More are fine.
  int64_t needed_nchunks = array->chunknitems == 0 ? 0 : array->extnitems / array->chunknitems;
  if (schunk->nchunks < needed_nchunks) {
    BLOSC_TRACE_ERROR("The b2nd shape needs %" PRId64 " chunks, but the super-chunk holds %" PRId64,
                      needed_nchunks, schunk->nchunks);
    return BLOSC2_ERROR_INVALID_HEADER;
  }
  // The chunks hold the chunk shape (padded to whole blocks) in typesize items;
  // a super-chunk without chunks or with chunks of varying size (<= 0) says nothing
  int64_t chunkbytes;
  if (schunk->nchunks > 0 && schunk->chunksize > 0 &&
      (!blosc2_checked_mul_i64_nonneg(array->extchunknitems, schunk->typesize, &chunkbytes) ||
       chunkbytes != schunk->chunksize)) {
    BLOSC_TRACE_ERROR("The b2nd chunk shape with typesize %d does not make the %d-byte chunks of the super-chunk",
                      schunk->typesize, schunk->chunksize);
    return BLOSC2_ERROR_INVALID_HEADER;
  }
  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_from_schunk(blosc2_schunk *schunk, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(schunk, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  if (schunk == NULL) {
    BLOSC_TRACE_ERROR("Schunk is null");
    return BLOSC2_ERROR_NULL_POINTER;
  }

  blosc2_cparams *cparams;
  if (blosc2_schunk_get_cparams(schunk, &cparams) < 0) {
    BLOSC_TRACE_ERROR("Blosc error");
    return BLOSC2_ERROR_NULL_POINTER;
  }
  free(cparams);

  b2nd_context_t params = {0};
  params.b2_storage = schunk->storage;

  // Deserialize the b2nd metalayer
  uint8_t *smeta;
  int32_t smeta_len;
  if (blosc2_meta_get(schunk, "b2nd", &smeta, &smeta_len) < 0) {
    // Try with a caterva metalayer; we are meant to be backward compatible with it
    if (blosc2_meta_get(schunk, "caterva", &smeta, &smeta_len) < 0) {
      BLOSC_ERROR(BLOSC2_ERROR_METALAYER_NOT_FOUND);
    }
  }
  int rc_meta = b2nd_deserialize_meta(smeta, smeta_len, &params.ndim, params.shape,
                                      params.chunkshape, params.blockshape, &params.dtype,
                                      &params.dtype_format);
  free(smeta);
  BLOSC_ERROR(rc_meta);

  // Reject crafted metalayers that pair shape[i]>0 with chunkshape[i]==0 or
  // blockshape[i]==0.  validate_shape_chunkshape_blockshape is intentionally
  // lenient about chunkshape==0/blockshape==0 to support the placeholder
  // pattern in b2nd_create_ctx (see example_empty_shape.c), where the
  // companion shape entry is also 0 so no divide-by-zero ever materializes.
  // Crafted on-wire metadata can violate that pairing, and many code paths
  // downstream (b2nd_get_slice, b2nd_set_slice, set/get_orthogonal_selection,
  // squeeze, resize) divide or mod by chunkshape[i] / blockshape[i] without
  // re-checking.  Enforce the pairing here so the deserialization path is
  // strict even when the create-ctx path remains permissive.
  for (int i = 0; i < params.ndim; ++i) {
    if (params.shape[i] != 0 &&
        (params.chunkshape[i] == 0 || params.blockshape[i] == 0)) {
      BLOSC_TRACE_ERROR("b2nd metalayer: shape[%d] is non-zero but "
                        "chunkshape[%d] or blockshape[%d] is zero", i, i, i);
      free(params.dtype);
      return BLOSC2_ERROR_INVALID_PARAM;
    }
  }

  // Free the deserialized dtype whether or not the array could be built; the
  // rejection path is now reachable for crafted shapes (see #795)
  int rc = array_without_schunk(&params, array);
  free(params.dtype);
  BLOSC_ERROR(rc);

  rc = check_schunk_matches_meta(schunk, *array);
  if (rc < 0) {
    // The schunk stays with the caller
    b2nd_free(*array);
    *array = NULL;
    BLOSC_ERROR(rc);
  }

  (*array)->sc = schunk;
  (*array)->last_tick = schunk->change_tick;

  if ((*array) == NULL) {
    BLOSC_TRACE_ERROR("Error creating a b2nd container from a frame");
    return BLOSC2_ERROR_NULL_POINTER;
  }

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_to_cframe(const b2nd_array_t *array, uint8_t **cframe, int64_t *cframe_len,
                   bool *needs_free) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(cframe, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(cframe_len, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(needs_free, BLOSC2_ERROR_NULL_POINTER);

  *cframe_len = blosc2_schunk_to_buffer(array->sc, cframe, needs_free);
  if (*cframe_len <= 0) {
    BLOSC_TRACE_ERROR("Error serializing the b2nd array");
    return BLOSC2_ERROR_FAILURE;
  }
  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_from_cframe(uint8_t *cframe, int64_t cframe_len, bool copy, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(cframe, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  blosc2_schunk *sc = blosc2_schunk_from_buffer(cframe, cframe_len, copy);
  if (sc == NULL) {
    BLOSC_TRACE_ERROR("Blosc error");
    return BLOSC2_ERROR_FAILURE;
  }
  // ...and create a b2nd array out of it
  int rc = b2nd_from_schunk(sc, array);
  if (rc < 0) {
    blosc2_schunk_free(sc);
    return rc;
  }

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_open(const char *urlpath, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(urlpath, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  blosc2_schunk *sc = blosc2_schunk_open(urlpath);
  if (sc == NULL) {
    return BLOSC2_ERROR_FAILURE;
  }

  // ...and create a b2nd array out of it
  int rc = b2nd_from_schunk(sc, array);
  if (rc < 0) {
    blosc2_schunk_free(sc);
    return rc;
  }

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_open_offset(const char *urlpath, b2nd_array_t **array, int64_t offset) {
  BLOSC_ERROR_NULL(urlpath, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  blosc2_schunk *sc = blosc2_schunk_open_offset(urlpath, offset);
  if (sc == NULL) {
    return BLOSC2_ERROR_FAILURE;
  }

  // ...and create a b2nd array out of it
  int rc = b2nd_from_schunk(sc, array);
  if (rc < 0) {
    blosc2_schunk_free(sc);
    return rc;
  }

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_free(b2nd_array_t *array) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  if (array) {
    if (array->sc != NULL) {
      blosc2_schunk_free(array->sc);
    }
    free(array->dtype);
    free(array);
  }
  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_from_cbuffer(b2nd_context_t *ctx, b2nd_array_t **array, const void *buffer, int64_t buffersize) {
  BLOSC_ERROR_NULL(ctx, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  BLOSC_ERROR(b2nd_empty(ctx, array));

  if (buffersize < (int64_t) (*array)->nitems * (*array)->sc->typesize) {
    BLOSC_TRACE_ERROR("The buffersize (%lld) is smaller than the array size (%lld)",
                        (long long) buffersize, (long long) (*array)->nitems * (*array)->sc->typesize);
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  if ((*array)->nitems == 0) {
    return BLOSC2_ERROR_SUCCESS;
  }

  int64_t start[B2ND_MAX_DIM] = {0};
  int64_t *stop = (*array)->shape;
  int64_t *shape = (*array)->shape;
  BLOSC_ERROR(b2nd_set_slice_cbuffer(buffer, shape, buffersize, start, stop, *array));

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_to_cbuffer(const b2nd_array_t *array, void *buffer,
                    int64_t buffersize) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale((b2nd_array_t *) array));

  if (buffersize < (int64_t) array->nitems * array->sc->typesize) {
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  if (array->nitems == 0) {
    return BLOSC2_ERROR_SUCCESS;
  }

  int64_t start[B2ND_MAX_DIM] = {0};
  const int64_t *stop = array->shape;
  BLOSC_ERROR(b2nd_get_slice_cbuffer(array, start, stop, buffer, array->shape, buffersize));
  return BLOSC2_ERROR_SUCCESS;
}

int b2nd_get_sparse_cbuffer(const b2nd_array_t *array, int64_t ncoords,
                            const int64_t *coords, void *buffer, int64_t buffersize) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale((b2nd_array_t *) array));
  if (ncoords < 0) {
    BLOSC_TRACE_ERROR("ncoords must be non-negative");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }
  if (ncoords == 0) {
    return BLOSC2_ERROR_SUCCESS;
  }
  BLOSC_ERROR_NULL(coords, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);
  if (buffersize < ncoords * array->sc->typesize) {
    BLOSC_TRACE_ERROR("Buffer is smaller than expected");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }
  if (array->ndim == 0) {
    BLOSC_TRACE_ERROR("Sparse indexing is not supported for 0-dimensional arrays");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  int64_t chunks_in_array[B2ND_MAX_DIM] = {0};
  int64_t chunks_in_array_strides[B2ND_MAX_DIM] = {0};
  chunks_in_array_strides[array->ndim - 1] = 1;
  for (int j = 0; j < array->ndim; ++j) {
    chunks_in_array[j] = array->chunkshape[j] == 0 ? 0 : array->extshape[j] / array->chunkshape[j];
  }
  for (int j = array->ndim - 2; j >= 0; --j) {
    chunks_in_array_strides[j] = chunks_in_array_strides[j + 1] * chunks_in_array[j + 1];
  }

  int64_t *storage_coords = malloc((size_t)ncoords * sizeof(int64_t));
  BLOSC_ERROR_NULL(storage_coords, BLOSC2_ERROR_MEMORY_ALLOC);

  int rc = BLOSC2_ERROR_SUCCESS;
  for (int64_t i = 0; i < ncoords; ++i) {
    int64_t coord = coords[i];
    if (coord < 0 || coord >= array->nitems) {
      BLOSC_TRACE_ERROR("Coordinate out of bounds");
      rc = BLOSC2_ERROR_INVALID_PARAM;
      goto cleanup;
    }

    int64_t logical_index[B2ND_MAX_DIM] = {0};
    int64_t nchunk_ndim[B2ND_MAX_DIM] = {0};
    int64_t item_in_chunk[B2ND_MAX_DIM] = {0};
    int64_t nblock_ndim[B2ND_MAX_DIM] = {0};
    int64_t item_in_block[B2ND_MAX_DIM] = {0};
    blosc2_unidim_to_multidim(array->ndim, (int64_t *)array->shape, coord, logical_index);
    for (int j = 0; j < array->ndim; ++j) {
      nchunk_ndim[j] = logical_index[j] / array->chunkshape[j];
      item_in_chunk[j] = logical_index[j] % array->chunkshape[j];
      nblock_ndim[j] = item_in_chunk[j] / array->blockshape[j];
      item_in_block[j] = item_in_chunk[j] % array->blockshape[j];
    }

    int64_t nchunk;
    blosc2_multidim_to_unidim(nchunk_ndim, array->ndim, chunks_in_array_strides, &nchunk);

    int64_t nblock;
    blosc2_multidim_to_unidim(nblock_ndim, array->ndim, array->block_chunk_strides, &nblock);
    int64_t storage_item_in_block;
    blosc2_multidim_to_unidim(item_in_block, array->ndim, array->item_block_strides, &storage_item_in_block);
    storage_coords[i] = nchunk * array->extchunknitems + nblock * array->blocknitems + storage_item_in_block;
  }

  rc = blosc2_schunk_get_sparse_buffer(array->sc, ncoords, storage_coords, buffer);

cleanup:
  free(storage_coords);
  BLOSC_ERROR(rc);
  return BLOSC2_ERROR_SUCCESS;
}



int64_t b2nd_get_slice_nchunks(const b2nd_array_t *array, const int64_t *start, const int64_t *stop, int64_t **chunks_idx) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(start, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(stop, BLOSC2_ERROR_NULL_POINTER);

  int8_t ndim = array->ndim;

  if (array->nitems == 0) {
    *chunks_idx = NULL;
    return 0;
  }

  // 0-dim case
  if (ndim == 0) {
    *chunks_idx = malloc(1 * sizeof(int64_t));
    BLOSC_ERROR_NULL(*chunks_idx, BLOSC2_ERROR_MEMORY_ALLOC);
    (*chunks_idx)[0] = 0;
    return 1;
  }

  int64_t chunks_in_array[B2ND_MAX_DIM] = {0};
  for (int i = 0; i < ndim; ++i) {
    chunks_in_array[i] = array->extshape[i] / array->chunkshape[i];
  }

  int64_t chunks_in_array_strides[B2ND_MAX_DIM];
  chunks_in_array_strides[ndim - 1] = 1;
  for (int i = ndim - 2; i >= 0; --i) {
    chunks_in_array_strides[i] = chunks_in_array_strides[i + 1] * chunks_in_array[i + 1];
  }

  // Check slice bounds
  for (int i = 0; i < ndim; ++i) {
    if (start[i] < 0 || stop[i] < 0) {
      BLOSC_TRACE_ERROR("Slice bounds must be non-negative");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
    if (start[i] >= stop[i] || start[i] >= array->shape[i]) {
      *chunks_idx = NULL;
      return 0;
    }
  }

  // Compute the number of chunks to update
  int64_t update_start[B2ND_MAX_DIM];
  int64_t update_shape[B2ND_MAX_DIM];

  int64_t update_nchunks = 1;
  for (int i = 0; i < ndim; ++i) {
    int64_t slice_stop = stop[i] > array->extshape[i] ? array->extshape[i] : stop[i];
    int64_t pos = 0;
    while (pos <= start[i]) {
      pos += array->chunkshape[i];
    }
    update_start[i] = pos / array->chunkshape[i] - 1;
    while (pos < slice_stop) {
      pos += array->chunkshape[i];
    }
    update_shape[i] = pos / array->chunkshape[i] - update_start[i];
    if (!blosc2_checked_mul_i64_nonneg(update_nchunks, update_shape[i], &update_nchunks)) {
      BLOSC_TRACE_ERROR("The number of chunks spanned by the slice overflows");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
  }

  if (update_nchunks == 0) {
    *chunks_idx = NULL;
    return 0;
  }
  if ((uint64_t)update_nchunks > SIZE_MAX / sizeof(int64_t)) {
    BLOSC_TRACE_ERROR("The number of chunks to allocate exceeds addressable memory");
    return BLOSC2_ERROR_MEMORY_ALLOC;
  }

  int64_t nchunks = 0;
  // The loop below writes at most one index per iteration, so size the buffer
  // from update_nchunks.  sc->nchunks only equals that bound when the shape and
  // chunkshape in the b2nd metalayer agree with the chunks actually stored,
  // which is not true for a crafted container.
  *chunks_idx = malloc((size_t)update_nchunks * sizeof(int64_t));
  BLOSC_ERROR_NULL(*chunks_idx, BLOSC2_ERROR_MEMORY_ALLOC);
  int64_t *ptr = *chunks_idx;
  for (int64_t update_nchunk = 0; update_nchunk < update_nchunks; ++update_nchunk) {
    int64_t nchunk_ndim[B2ND_MAX_DIM] = {0};
    blosc2_unidim_to_multidim(ndim, update_shape, update_nchunk, nchunk_ndim);
    for (int i = 0; i < ndim; ++i) {
      nchunk_ndim[i] += update_start[i];
    }
    int64_t nchunk;
    blosc2_multidim_to_unidim(nchunk_ndim, ndim, chunks_in_array_strides, &nchunk);

    // Check if the chunk is inside the slice domain
    int64_t chunk_start[B2ND_MAX_DIM] = {0};
    int64_t chunk_stop[B2ND_MAX_DIM] = {0};
    for (int i = 0; i < ndim; ++i) {
      chunk_start[i] = nchunk_ndim[i] * array->chunkshape[i];
      chunk_stop[i] = chunk_start[i] + array->chunkshape[i];
      if (chunk_stop[i] > array->shape[i]) {
        chunk_stop[i] = array->shape[i];
      }
    }
    bool chunk_empty = false;
    for (int i = 0; i < ndim; ++i) {
      chunk_empty |= (chunk_stop[i] <= start[i] || chunk_start[i] >= stop[i]);
    }
    if (chunk_empty) {
      continue;
    }

    ptr[nchunks] = nchunk;
    nchunks++;
  }

  if (nchunks == 0) {
    free(ptr);
    *chunks_idx = NULL;
  } else if (nchunks < update_nchunks) {
    int64_t *new_ptr = realloc(ptr, (size_t)nchunks * sizeof(int64_t));
    if (new_ptr != NULL) {
      *chunks_idx = new_ptr;
    }
  }

  return nchunks;
}


// Whether a decompressed chunk (its blocks one after the other, each in C
// order) has the C-order layout of the chunk itself.  That is the case when
// there is a 0 <= k < ndim such that blockshape[i] == 1 for i < k,
// blockshape[k] divides chunkshape[k] and blockshape[i] == chunkshape[i] for
// i > k.
static bool chunk_blocks_in_c_order(const b2nd_array_t *array) {
  int k = 0;
  for (int i = 0; i < array->ndim; ++i) {
    if (array->chunkshape[i] % array->blockshape[i] != 0) {
      return false;
    }
    if (i > k && array->chunkshape[i] != array->blockshape[i]) {
      return false;
    }
    if (i == k && array->blockshape[i] == 1) {
      k++;
    }
  }
  return true;
}


// Whether the whole chunk starting at chunk_start (no padding) lies inside
// [start, stop) and covers one contiguous run of the C-order buffer of shape
// `shape` that holds the slice.  If so, *offset gets the run's byte offset.
static bool chunk_contiguous_in_buffer(const b2nd_array_t *array, const int64_t *chunk_start,
                                       const int64_t *start, const int64_t *stop,
                                       const int64_t *shape, int64_t *offset) {
  // Leading dims where the chunk is one item wide can sit anywhere; past the
  // first wider dim the chunk has to span the buffer.
  bool must_span = false;
  int64_t off = 0;
  for (int i = 0; i < array->ndim; ++i) {
    int64_t extent = array->chunkshape[i];
    if (chunk_start[i] < start[i] || chunk_start[i] + extent > stop[i] ||
        chunk_start[i] + extent > array->shape[i]) {
      return false;
    }
    if (must_span && extent != shape[i]) {
      return false;
    }
    if (extent > 1) {
      must_span = true;
    }
    off = off * shape[i] + (chunk_start[i] - start[i]);
  }
  *offset = off * array->sc->typesize;
  return true;
}


// One chunk of a slice read or write: the slice [start, stop) of the array,
// held in `buffer` (of shape `buffershape`, the slice at its origin), and the
// chunk at [chunk_start, chunk_stop) (stop clipped to the array shape).
// Read-only while the chunk is (de)compressed, so the worker threads can share
// it.
typedef struct {
  const b2nd_array_t *array;
  uint8_t *buffer;
  const int64_t *buffershape;
  const int64_t *start;
  const int64_t *stop;
  const int64_t *chunk_start;
  const int64_t *chunk_stop;
  const int64_t *blocks_in_chunk;
  const int64_t *blockshape;  // that of the array, in 64 bits
  // A write of a chunk that is only partly overwritten: blocks start from the
  // old contents, decompressed into the compressor input.  Otherwise blocks
  // start as zeros (the prefilter output comes zeroed), which is what padding
  // must hold.
  bool keep_old;
} slice_chunk_t;


// The overlap of a block with the slice: [src_start, src_stop) relative to the
// block and [dst_start, dst_stop) relative to the slice.
typedef struct {
  int64_t src_start[B2ND_MAX_DIM];
  int64_t src_stop[B2ND_MAX_DIM];
  int64_t dst_start[B2ND_MAX_DIM];
  int64_t dst_stop[B2ND_MAX_DIM];
  bool whole_block;  // all of the block, padding included
} block_overlap_t;


// Whether block `nblock` of the chunk of `c` overlaps the slice, and where in
// *overlap (if not NULL).
static bool block_slice_overlap(const slice_chunk_t *c, int64_t nblock, block_overlap_t *overlap) {
  int8_t ndim = c->array->ndim;
  int64_t nblock_ndim[B2ND_MAX_DIM] = {0};
  blosc2_unidim_to_multidim(ndim, (int64_t *) c->blocks_in_chunk, nblock, nblock_ndim);
  bool whole_block = true;
  for (int i = 0; i < ndim; ++i) {
    int64_t block_start = c->chunk_start[i] + nblock_ndim[i] * c->blockshape[i];
    int64_t block_stop = block_start + c->blockshape[i];
    if (block_stop > c->chunk_stop[i]) {
      block_stop = c->chunk_stop[i];
    }
    int64_t lo = block_start > c->start[i] ? block_start : c->start[i];
    int64_t hi = block_stop < c->stop[i] ? block_stop : c->stop[i];
    if (lo >= hi) {
      return false;
    }
    whole_block &= lo == block_start && hi == block_start + c->blockshape[i];
    if (overlap != NULL) {
      overlap->src_start[i] = lo - block_start;
      overlap->src_stop[i] = hi - block_start;
      overlap->dst_start[i] = lo - c->start[i];
      overlap->dst_stop[i] = hi - c->start[i];
    }
  }
  if (overlap != NULL) {
    overlap->whole_block = whole_block;
  }
  return true;
}


// Overlap of the chunk at [chunk_start, chunk_stop) with the slice [start,
// stop), relative to the slice; returns its number of items.
static int64_t chunk_slice_box(int8_t ndim, const int64_t *chunk_start, const int64_t *chunk_stop,
                               const int64_t *start, const int64_t *stop, int64_t *box_start,
                               int64_t *box_stop) {
  int64_t nitems = 1;
  for (int i = 0; i < ndim; ++i) {
    box_start[i] = (chunk_start[i] > start[i] ? chunk_start[i] : start[i]) - start[i];
    box_stop[i] = (chunk_stop[i] < stop[i] ? chunk_stop[i] : stop[i]) - start[i];
    nitems *= box_stop[i] - box_start[i];
  }
  return nitems;
}


// Whether a get_slice buffer should be prefaulted with prefault_range() before
// many threads write to it at once.  With transparent huge pages, threads
// writing neighbouring blocks of a fresh buffer fault on the same huge page
// together, and each of them clears a whole huge page before all but one
// throw theirs away: reading 300 MB with 28 threads spent several times its
// wall time in the kernel.  Small-page faults scale with threads, and
// prefaulting them serially costs far more (108 vs 41 ms for 315 MB), so only
// for buffers that get huge pages, which depends on the buffer as much as on
// the system: in THP "madvise" mode only buffers madvised so (NumPy does it
// from 4 MB) do.  Nor for buffers in use already (malloc recycles them), whose
// pages are there, nor for small ones.
static bool buffer_wants_prefault(const uint8_t *buffer, int64_t nbytes, int nthreads) {
#if defined(__linux__)
  // A huge page is 2 MB with 4 KB pages; other page sizes are not probed
  enum { huge_page = 2 << 20, small_page = 4096, npages = huge_page / small_page };
  if (nthreads < 2 || nbytes < 2 * huge_page || sysconf(_SC_PAGESIZE) != small_page) {
    return false;
  }
  // The aligned huge page around the middle lies inside a buffer of 4 MB or more,
  // away from its first page, where malloc writes its chunk header
  uint8_t *block = (uint8_t *) (((uintptr_t) buffer + (uintptr_t) (nbytes / 2)) & ~(uintptr_t) (huge_page - 1));
  unsigned char resident[npages];
  if (mincore(block, huge_page, resident) != 0) {
    return false;
  }
  for (int i = 0; i < npages; i++) {
    if (resident[i] & 1) {
      return false;
    }
  }
  // Fault in one page as a write would, and see whether the whole huge page came
  // with it (best effort: kernels before 5.14 cannot, and then nothing is prefaulted)
  if (madvise(block + huge_page / 2, small_page, MADV_POPULATE_WRITE) != 0 ||
      mincore(block, huge_page, resident) != 0) {
    return false;
  }
  for (int i = 0; i < npages; i++) {
    if ((resident[i] & 1) == 0) {
      return false;
    }
  }
  return true;
#else
  BLOSC_UNUSED_PARAM(buffer);
  BLOSC_UNUSED_PARAM(nbytes);
  BLOSC_UNUSED_PARAM(nthreads);
  return false;
#endif
}


// Fault in the pages of [ptr, ptr + nbytes) from the calling thread without
// changing their contents.  Best effort: errors (e.g. kernels older than
// 5.14) are ignored.
static void prefault_range(uint8_t *ptr, int64_t nbytes) {
#if defined(__linux__)
  long page = sysconf(_SC_PAGESIZE);
  if (page <= 0) {
    return;
  }
  uintptr_t lo = ((uintptr_t) ptr + (uintptr_t) page - 1) & ~((uintptr_t) page - 1);
  uintptr_t hi = ((uintptr_t) ptr + (uintptr_t) nbytes) & ~((uintptr_t) page - 1);
  if (hi > lo) {
    (void) madvise((void *) lo, hi - lo, MADV_POPULATE_WRITE);
  }
#else
  BLOSC_UNUSED_PARAM(ptr);
  BLOSC_UNUSED_PARAM(nbytes);
#endif
}


// Postfilter copying each decompressed block to its place in the slice buffer
// right in the thread that decoded it, while the block is still in cache.
static int slice_scatter_postfilter(blosc2_postfilter_params *params) {
  const slice_chunk_t *c = params->user_data;
  const b2nd_array_t *array = c->array;
  int8_t ndim = array->ndim;
  int32_t typesize = array->sc->typesize;
  if (params->size != array->blocknitems * typesize) {
    BLOSC_TRACE_ERROR("Unexpected block size in b2nd chunk");
    return BLOSC2_ERROR_FAILURE;
  }
  block_overlap_t overlap;
  if (!block_slice_overlap(c, params->nblock, &overlap)) {
    return 0;
  }
  if (params->ctx->special_type == BLOSC2_SPECIAL_UNINIT) {
    // Nothing was decoded into the input; hand out zeros rather than stale memory
    b2nd_zero_box(ndim, typesize, c->buffer, c->buffershape, overlap.dst_start, overlap.dst_stop);
    return 0;
  }
  return b2nd_copy_buffer2(ndim, typesize, params->input, c->blockshape, overlap.src_start,
                           overlap.src_stop, c->buffer, c->buffershape, overlap.dst_start);
}


// Whether the chunk just decompressed with dctx needs the scratch path after
// all: DELTA decodes against the first block of the destination, which the
// scatter path never writes, and instrumented chunks bypass postfilters.
static bool scatter_unsupported(const blosc2_context *dctx) {
  return (dctx->blosc2_flags & BLOSC2_INSTR_CODEC) || filters_contain(dctx->filters, BLOSC_DELTA);
}


// Whether a decompression by dctx that returned `rc` left its destination as
// it was: a missing chunk, or an uninitialized one (unless a postfilter
// computes its items).  A scratch destination then holds stale bytes, of
// another array even (see scratch_malloc()), so it must be zeroed.
static bool decoded_nothing(const blosc2_context *dctx, int rc) {
  return rc == 0 || (dctx->special_type == BLOSC2_SPECIAL_UNINIT && dctx->postfilter == NULL);
}


// Prefilter assembling each block of a chunk from the slice buffer right in
// the compression thread that consumes it, instead of first copying the slice
// into a chunk-sized scratch on the calling thread.
static int slice_gather_prefilter(blosc2_prefilter_params *params) {
  const slice_chunk_t *c = params->user_data;
  const b2nd_array_t *array = c->array;
  int8_t ndim = array->ndim;
  int32_t typesize = array->sc->typesize;
  if (params->output_size != array->blocknitems * typesize) {
    BLOSC_TRACE_ERROR("Unexpected block size in b2nd chunk");
    return BLOSC2_ERROR_FAILURE;
  }
  block_overlap_t overlap;
  bool overlaps = block_slice_overlap(c, params->nblock, &overlap);
  if (c->keep_old && !(overlaps && overlap.whole_block)) {
    memcpy(params->output, params->input, (size_t) params->output_size);
  }
  if (!overlaps) {
    return 0;
  }
  return b2nd_copy_buffer2(ndim, typesize, c->buffer, c->buffershape, overlap.dst_start,
                           overlap.dst_stop, params->output, c->blockshape, overlap.src_start);
}


// A temporary of a slice read or write on `array`, released with
// blosc2_tmp_free(ptr, *capacity) (see schunk_scratch_malloc()).
static uint8_t *scratch_malloc(const b2nd_array_t *array, int32_t nbytes, size_t *capacity) {
  return schunk_scratch_malloc(array->sc, nbytes, capacity);
}


// Compress `src` as chunk `nchunk` and store it.  With `gather`, the blocks
// are assembled by slice_gather_prefilter() and `src` is only read for the
// old contents of partly overwritten blocks.
static int compress_update_chunk(b2nd_array_t *array, int64_t nchunk, const uint8_t *src,
                                 int32_t nbytes, slice_chunk_t *gather) {
  int32_t chunk_nbytes = nbytes + BLOSC2_MAX_OVERHEAD;
  size_t chunk_capacity;
  uint8_t *chunk = scratch_malloc(array, chunk_nbytes, &chunk_capacity);
  BLOSC_ERROR_NULL(chunk, BLOSC2_ERROR_MEMORY_ALLOC);
  // Update current_chunk in case a prefilter is applied
  array->sc->current_nchunk = nchunk;
  blosc2_context *cctx = array->sc->cctx;
  blosc2_prefilter_params params;
  blosc2_prefilter_params *saved_preparams = cctx->preparams;
  if (gather != NULL) {
    memset(&params, 0, sizeof(params));
    params.user_data = gather;
    cctx->prefilter = slice_gather_prefilter;
    cctx->preparams = &params;
  }
  int brc = blosc2_compress_ctx(cctx, src, nbytes, chunk, chunk_nbytes);
  if (gather != NULL) {
    cctx->prefilter = NULL;
    cctx->preparams = saved_preparams;
  }
  if (brc < 0) {
    blosc2_tmp_free(chunk, chunk_capacity);
    BLOSC_TRACE_ERROR("Blosc can not compress the data");
    return BLOSC2_ERROR_FAILURE;
  }
  // A frame stores its own copy of the chunk, so it is lent a reused buffer; an
  // in-memory super-chunk keeps the buffer itself
  bool in_frame = array->sc->frame != NULL;
  int64_t brc_ = in_frame ? schunk_update_chunk_lent(array->sc, nchunk, chunk)
                          : blosc2_schunk_update_chunk(array->sc, nchunk, chunk, false);
  if (in_frame || brc_ < 0) {
    // A failed update leaves the chunk to us
    blosc2_tmp_free(chunk, chunk_capacity);
  }
  if (brc_ < 0) {
    BLOSC_TRACE_ERROR("Blosc can not update the chunk");
    return BLOSC2_ERROR_FAILURE;
  }
  return BLOSC2_ERROR_SUCCESS;
}


/* Set the blocks of a chunk that the slice does not touch in @p maskout (for blosc2_set_maskout()); with the delta
   filter block 0 is needed too as soon as any is.  Returns how many blocks the slice touches. */
static int64_t slice_chunk_maskout(const slice_chunk_t *c, int64_t nblocks, bool has_delta, bool *maskout) {
  int64_t nneeded = 0;
  for (int64_t nblock = 0; nblock < nblocks; ++nblock) {
    maskout[nblock] = !block_slice_overlap(c, nblock, NULL);
    nneeded += !maskout[nblock];
  }
  if (has_delta && nneeded > 0) {
    maskout[0] = false;
  }
  return nneeded;
}


/* Whether a slice read decompresses a chunk that it needs @p nblocks_needed blocks of block by block, straight from
   the (lazy) chunk (the compact path), rather than the whole chunk with a maskout (see get_set_slice()) */
static bool slice_chunk_compact(const b2nd_array_t *array, int64_t nblocks_needed, bool has_delta) {
  bool on_disk = array->sc->storage != NULL && array->sc->storage->urlpath != NULL;
  int64_t frac = on_disk ? 4 : 16;
  int64_t block_nbytes = (int64_t) array->blocknitems * array->sc->typesize;
  int64_t data_nbytes = array->extchunknitems * array->sc->typesize;
  return !has_delta && nblocks_needed * block_nbytes * frac <= data_nbytes;
}


/* The box [chunk_start, chunk_stop) of chunk @p nchunk of @p array, clipped to its shape; whether [start, stop)
   covers only part of it */
static bool chunk_box(const b2nd_array_t *array, int64_t nchunk, const int64_t *start, const int64_t *stop,
                      int64_t *chunk_start, int64_t *chunk_stop) {
  int64_t chunks_in_array[B2ND_MAX_DIM];
  int64_t nchunk_ndim[B2ND_MAX_DIM];
  for (int i = 0; i < array->ndim; ++i) {
    chunks_in_array[i] = array->extshape[i] / array->chunkshape[i];
  }
  blosc2_unidim_to_multidim(array->ndim, chunks_in_array, nchunk, nchunk_ndim);
  bool partial = false;
  for (int i = 0; i < array->ndim; ++i) {
    chunk_start[i] = nchunk_ndim[i] * array->chunkshape[i];
    chunk_stop[i] = chunk_start[i] + array->chunkshape[i] < array->shape[i] ?
                    chunk_start[i] + array->chunkshape[i] : array->shape[i];
    partial |= start[i] > chunk_start[i] || stop[i] < chunk_stop[i];
  }
  return partial;
}


/* Start reading the chunks of [start, stop) of an array in a frame on disk ahead (see blosc2_set_prefetch()); NULL if
   read-ahead is off or does not apply.  Of a chunk the slice covers in part only the blocks it needs, if that is all
   the read takes from the file: with the mmap I/O (the chunk is in the mapping), or on the compact path (the default
   I/O otherwise reads the whole chunk). */
static prefetch_batch* prefetch_slice(const b2nd_array_t *array, const int64_t *start, const int64_t *stop) {
  blosc2_frame_s *frame = (blosc2_frame_s *) array->sc->frame;
  if (!prefetch_applies(frame)) {
    return NULL;
  }
  int8_t ndim = array->ndim;
  int64_t nblocks = array->blocknitems > 0 ? array->extchunknitems / array->blocknitems : 0;
  int64_t *nchunks = NULL;
  int64_t n = b2nd_get_slice_nchunks(array, start, stop, &nchunks);
  int64_t chunk_start[B2ND_MAX_DIM];
  int64_t chunk_stop[B2ND_MAX_DIM];
  int64_t npartial = 0;
  for (int64_t c = 0; c < n && nblocks > 0; ++c) {
    npartial += chunk_box(array, nchunks[c], start, stop, chunk_start, chunk_stop);
  }
  // One maskout per chunk covered in part (NULL for a chunk read whole), all in one allocation
  const bool **maskouts = NULL;
  if (npartial > 0) {
    maskouts = calloc(1, n * sizeof(bool *) + npartial * nblocks * sizeof(bool));
  }
  if (maskouts != NULL) {
    bool *row = (bool *) (maskouts + n);
    int64_t blocks_in_chunk[B2ND_MAX_DIM];
    int64_t blockshape[B2ND_MAX_DIM];
    for (int i = 0; i < ndim; ++i) {
      blocks_in_chunk[i] = array->extchunkshape[i] / array->blockshape[i];
      blockshape[i] = array->blockshape[i];
    }
    blosc2_io_cb *io_cb = blosc2_get_io_cb(array->sc->storage->io->id);
    bool mapped = io_cb != NULL && !io_cb->is_allocation_necessary;
    bool has_delta = filters_contain(array->sc->filters, BLOSC_DELTA);
    slice_chunk_t slice_chunk;
    memset(&slice_chunk, 0, sizeof(slice_chunk));
    slice_chunk.array = array;
    slice_chunk.start = start;
    slice_chunk.stop = stop;
    slice_chunk.chunk_start = chunk_start;
    slice_chunk.chunk_stop = chunk_stop;
    slice_chunk.blocks_in_chunk = blocks_in_chunk;
    slice_chunk.blockshape = blockshape;
    for (int64_t c = 0; c < n; ++c) {
      if (!chunk_box(array, nchunks[c], start, stop, chunk_start, chunk_stop)) {
        continue;  // read whole
      }
      int64_t nneeded = slice_chunk_maskout(&slice_chunk, nblocks, has_delta, row);
      if (mapped || slice_chunk_compact(array, nneeded, has_delta)) {
        maskouts[c] = row;
        row += nblocks;
      }
    }
  }
  prefetch_batch *batch = prefetch_batch_new(frame, nchunks, n, maskouts, nblocks);
  free(maskouts);
  free(nchunks);
  return batch;
}


// The special value (BLOSC2_SPECIAL_ZERO, _NAN, _UNINIT, or 0) of chunks
// nchunks[0..n) of `sc` into special[], without reading chunk data: frames
// code special values in their index, other super-chunks hold their chunks in
// memory.
static int chunks_special(blosc2_schunk *sc, const int64_t *nchunks, int64_t n, uint8_t *special) {
  if (sc->frame != NULL) {
    return frame_get_chunks_special((blosc2_frame_s *) sc->frame, nchunks, n, special);
  }
  for (int64_t k = 0; k < n; ++k) {
    if (nchunks[k] < 0 || nchunks[k] >= sc->nchunks || sc->data[nchunks[k]] == NULL) {
      return BLOSC2_ERROR_INVALID_PARAM;
    }
    const uint8_t *chunk = sc->data[nchunks[k]];
    special[k] = (uint8_t) chunk_special_in_offset(chunk, sw32_(chunk + BLOSC2_CHUNK_CBYTES));
  }
  return BLOSC2_ERROR_SUCCESS;
}


// Setting and getting slices: read (set_slice false) or write the slice [start, stop) of `array` from/to `buffer`, a
// C-order array of shape `shape` (at least the slice's shape) whose first item is the slice's first item.  A read
// fills the rest of the buffer with zeros, unless `slice_only`: then nothing outside the slice is written.  A read
// uses the read-ahead batch @p prefetch, or starts its own if that is NULL.
int get_set_slice(void *buffer, int64_t buffersize, const int64_t *start, const int64_t *stop,
                  const int64_t *shape, b2nd_array_t *array, bool set_slice, bool slice_only,
                  prefetch_batch *prefetch) {
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(start, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(stop, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  if (buffersize < 0) {
    BLOSC_TRACE_ERROR("buffersize is < 0");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  uint8_t *buffer_b = buffer;
  int8_t ndim = array->ndim;

  // 0-dim case
  if (ndim == 0) {
    if (set_slice) {
      int32_t chunk_size = array->sc->typesize + BLOSC2_MAX_OVERHEAD;
      uint8_t *chunk = malloc(chunk_size);
      BLOSC_ERROR_NULL(chunk, BLOSC2_ERROR_MEMORY_ALLOC);
      if (blosc2_compress_ctx(array->sc->cctx, buffer_b, array->sc->typesize, chunk, chunk_size) < 0 ||
          blosc2_schunk_update_chunk(array->sc, 0, chunk, false) < 0) {
        // Neither a failed compression nor a failed update took the chunk
        free(chunk);
        BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
      }

    } else {
      // The item is the whole slice: zero it first (an uninitialized chunk
      // decompresses to nothing), with slice_only nothing else
      memset(buffer_b, 0, slice_only ? (size_t)array->sc->typesize : (size_t)buffersize);
      if (blosc2_schunk_decompress_chunk(array->sc, 0, buffer_b, array->sc->typesize) < 0) {
        BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
      }
    }
    return BLOSC2_ERROR_SUCCESS;
  }

  if (array->nitems == 0) {
    if (!set_slice && !slice_only) {
      memset(buffer_b, 0, (size_t)buffersize);
    }
    return BLOSC2_ERROR_SUCCESS;
  }

  int64_t nelems_slice = 1;
  for (int i = 0; i < array->ndim; ++i) {
    if (stop[i] - start[i] > shape[i]) {
      BLOSC_TRACE_ERROR("The buffer shape can not be smaller than the slice shape");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
    nelems_slice *= stop[i] - start[i];
  }
  int64_t slice_nbytes = nelems_slice * array->sc->typesize;
  // Compute in 64 bits and range-check: the cast used to bind to extchunknitems
  // alone, truncating it before the multiply and sizing buffers from the
  // wrapped value while offsets kept using the full extent (see #795)
  int64_t data_nbytes_64 = 0;
  if (!blosc2_checked_mul_i64_nonneg(array->extchunknitems, array->sc->typesize, &data_nbytes_64) ||
      data_nbytes_64 > INT32_MAX) {
    BLOSC_TRACE_ERROR("Chunk buffer size overflows the maximum of %d bytes", INT32_MAX);
    return BLOSC2_ERROR_INVALID_PARAM;
  }
  int32_t data_nbytes = (int32_t) data_nbytes_64;

  if (buffersize < slice_nbytes) {
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  int64_t buffer_strides[B2ND_MAX_DIM];
  buffer_strides[ndim - 1] = 1;
  for (int i = ndim - 2; i >= 0; --i) {
    buffer_strides[i] = buffer_strides[i + 1] * shape[i + 1];
  }

  bool prefault = false;
  bool slice_zeroed = false;  // all items of the slice are zeros in the buffer already
  if (!set_slice && slice_only) {
    // Only the slice's box gets written, but a fresh buffer still wants its
    // pages faulted in before several threads decompress into it (see
    // buffer_wants_prefault()).  That maps pages and changes no byte.
    int64_t last = 0;
    for (int i = 0; i < ndim; ++i) {
      last += (stop[i] - start[i] - 1) * buffer_strides[i];
    }
    prefault = buffer_wants_prefault(buffer_b, (last + 1) * array->sc->typesize, array->sc->dctx->nthreads);
  }
  else if (!set_slice) {
    bool slice_fills_buffer = true;
    // The get paths below write every item of the slice, so only buffer
    // bytes outside of it need to be pre-initialized to be defined and
    // deterministic.  Skipping the rest saves a pass over the buffer, which
    // for a freshly allocated one is also where all its page faults hit.
    for (int i = 0; i < ndim; ++i) {
      if (start[i] < 0 || stop[i] < start[i] || stop[i] > array->shape[i] ||
          stop[i] - start[i] != shape[i]) {
        slice_fills_buffer = false;
        break;
      }
    }
    if (slice_fills_buffer) {
      memset(buffer_b + slice_nbytes, 0, (size_t)(buffersize - slice_nbytes));
      prefault = buffer_wants_prefault(buffer_b, slice_nbytes, array->sc->dctx->nthreads);
    }
    else {
      memset(buffer_b, 0, (size_t)buffersize);
      slice_zeroed = true;
    }
  }

  // Chunk-sized scratch (see scratch_malloc()), allocated lazily: the compact
  // get path below never needs it, and for large chunks just the malloc/free
  // pair costs O(chunksize) in page-table work (it is way above the malloc
  // mmap threshold), which would dominate small reads.
  uint8_t *data = NULL;
  size_t data_capacity = 0;
  // Block-sized scratch for the compact get path (lazily allocated too).
  uint8_t *block_data = NULL;
  size_t block_data_capacity = 0;
  int32_t block_nbytes = (int32_t) (array->blocknitems * array->sc->typesize);
  bool *block_maskout = NULL;
  int rc = BLOSC2_ERROR_SUCCESS;

  int64_t chunks_in_array[B2ND_MAX_DIM] = {0};
  for (int i = 0; i < ndim; ++i) {
    chunks_in_array[i] = array->extshape[i] / array->chunkshape[i];
  }

  int64_t chunks_in_array_strides[B2ND_MAX_DIM];
  chunks_in_array_strides[ndim - 1] = 1;
  for (int i = ndim - 2; i >= 0; --i) {
    chunks_in_array_strides[i] = chunks_in_array_strides[i + 1] * chunks_in_array[i + 1];
  }

  int64_t blocks_in_chunk[B2ND_MAX_DIM] = {0};
  for (int i = 0; i < ndim; ++i) {
    blocks_in_chunk[i] = array->extchunkshape[i] / array->blockshape[i];
  }
  int32_t nblocks = (int32_t) array->extchunknitems / array->blocknitems;
  int64_t blockshape[B2ND_MAX_DIM];
  for (int i = 0; i < ndim; ++i) {
    blockshape[i] = array->blockshape[i];
  }

  bool blocks_in_c_order = chunk_blocks_in_c_order(array);
  bool has_delta = filters_contain(array->sc->filters, BLOSC_DELTA);
  blosc2_context *dctx = array->sc->dctx;
  // The scatter get path brings its own postfilter, so it cannot serve
  // handles that have one (e.g. python-blosc2's lazy UDFs).
  bool can_scatter = !has_delta && dctx->postfilter == NULL;
  // Likewise for the gather set path and prefilters (python-blosc2 installs
  // some for lazy expressions); DELTA encodes against the first block of the
  // compressor input, which the gather does not fill.
  blosc2_context *cctx = array->sc->cctx;
  bool can_gather = cctx->prefilter == NULL && !filters_contain(cctx->filters, BLOSC_DELTA);

  // Compute the number of chunks to update
  int64_t update_start[B2ND_MAX_DIM];
  int64_t update_shape[B2ND_MAX_DIM];

  int64_t update_nchunks = 1;
  for (int i = 0; i < ndim; ++i) {
    int64_t pos = 0;
    while (pos <= start[i]) {
      pos += array->chunkshape[i];
    }
    update_start[i] = pos / array->chunkshape[i] - 1;
    while (pos < stop[i]) {
      pos += array->chunkshape[i];
    }
    update_shape[i] = pos / array->chunkshape[i] - update_start[i];
    update_nchunks *= update_shape[i];
  }

  prefetch_batch *own_prefetch = set_slice || prefetch != NULL ? NULL : prefetch_slice(array, start, stop);
  prefetch = own_prefetch != NULL ? own_prefetch : prefetch;

  // Chunks of zeros (b2nd_zeros(), sparse data) and uninitialized ones read
  // as zeros without decompression.  Find them from the index first; if they
  // hold a good part of the slice, zero the slice in one pass and skip them
  // (zeroing chunk by chunk writes many short rows: an all-zero 384^3 float16
  // box took 24 ms that way, 1.9 ms in one pass), else zero their boxes only.
  // Not with a postfilter, which may compute the items of special chunks,
  // and not for slices smaller than a block, where decompressing is cheap.
  int64_t *slice_chunks = NULL;  // the slice's chunks in loop order, then...
  uint8_t *zero_chunk = NULL;  // ...whether each reads as zeros (same allocation)
  if (!set_slice && dctx->postfilter == NULL && nelems_slice >= array->blocknitems) {
    slice_chunks = malloc((size_t) update_nchunks * (sizeof(int64_t) + 1));
    if (slice_chunks == NULL) {
      rc = BLOSC2_ERROR_MEMORY_ALLOC;
      goto out;
    }
    zero_chunk = (uint8_t *) (slice_chunks + update_nchunks);
    for (int64_t u = 0; u < update_nchunks; ++u) {
      int64_t idx[B2ND_MAX_DIM] = {0};
      blosc2_unidim_to_multidim(ndim, update_shape, u, idx);
      for (int i = 0; i < ndim; ++i) {
        idx[i] += update_start[i];
      }
      blosc2_multidim_to_unidim(idx, ndim, chunks_in_array_strides, &slice_chunks[u]);
    }
    if (chunks_special(array->sc, slice_chunks, update_nchunks, zero_chunk) < 0) {
      memset(zero_chunk, 0, (size_t) update_nchunks);  // the normal path reports what is wrong
    }
    int64_t zero_nitems = 0;
    for (int64_t u = 0; u < update_nchunks; ++u) {
      zero_chunk[u] = zero_chunk[u] == BLOSC2_SPECIAL_ZERO || zero_chunk[u] == BLOSC2_SPECIAL_UNINIT;
      if (zero_chunk[u]) {
        int64_t cstart[B2ND_MAX_DIM], cstop[B2ND_MAX_DIM], bstart[B2ND_MAX_DIM], bstop[B2ND_MAX_DIM];
        chunk_box(array, slice_chunks[u], start, stop, cstart, cstop);
        zero_nitems += chunk_slice_box(ndim, cstart, cstop, start, stop, bstart, bstop);
      }
    }
    if (!slice_zeroed && 4 * zero_nitems >= nelems_slice) {
      // The slice's box of the buffer (the whole buffer unless slice_only; one memset() then)
      int64_t zstart[B2ND_MAX_DIM] = {0};
      int64_t zstop[B2ND_MAX_DIM];
      for (int i = 0; i < ndim; ++i) {
        zstop[i] = stop[i] - start[i];
      }
      b2nd_zero_box(ndim, array->sc->typesize, buffer_b, shape, zstart, zstop);
      slice_zeroed = true;
    }
  }

  for (int64_t update_nchunk = 0; update_nchunk < update_nchunks; ++update_nchunk) {
    int64_t nchunk_ndim[B2ND_MAX_DIM] = {0};
    blosc2_unidim_to_multidim(ndim, update_shape, update_nchunk, nchunk_ndim);
    for (int i = 0; i < ndim; ++i) {
      nchunk_ndim[i] += update_start[i];
    }
    int64_t nchunk;
    blosc2_multidim_to_unidim(nchunk_ndim, ndim, chunks_in_array_strides, &nchunk);

    // Check if the chunk needs to be updated
    int64_t chunk_start[B2ND_MAX_DIM] = {0};
    int64_t chunk_stop[B2ND_MAX_DIM] = {0};
    for (int i = 0; i < ndim; ++i) {
      chunk_start[i] = nchunk_ndim[i] * array->chunkshape[i];
      chunk_stop[i] = chunk_start[i] + array->chunkshape[i];
      if (chunk_stop[i] > array->shape[i]) {
        chunk_stop[i] = array->shape[i];
      }
    }
    bool chunk_empty = false;
    for (int i = 0; i < ndim; ++i) {
      chunk_empty |= (chunk_stop[i] <= start[i] || chunk_start[i] >= stop[i]);
    }
    if (chunk_empty) {
      continue;
    }
    if (zero_chunk != NULL && zero_chunk[update_nchunk]) {
      if (!slice_zeroed) {
        int64_t box_start[B2ND_MAX_DIM];
        int64_t box_stop[B2ND_MAX_DIM];
        chunk_slice_box(ndim, chunk_start, chunk_stop, start, stop, box_start, box_stop);
        b2nd_zero_box(ndim, array->sc->typesize, buffer_b, shape, box_start, box_stop);
      }
      continue;
    }
    // Decompress each chunk as soon as it has been read ahead, while the later ones are still coming in
    prefetch_batch_wait(prefetch, nchunk);
    slice_chunk_t slice_chunk;
    memset(&slice_chunk, 0, sizeof(slice_chunk));
    slice_chunk.array = array;
    slice_chunk.buffer = buffer_b;
    slice_chunk.buffershape = shape;
    slice_chunk.start = start;
    slice_chunk.stop = stop;
    slice_chunk.chunk_start = chunk_start;
    slice_chunk.chunk_stop = chunk_stop;
    slice_chunk.blocks_in_chunk = blocks_in_chunk;
    slice_chunk.blockshape = blockshape;

    // A whole chunk that is one run of the buffer in its decompressed layout
    // is (de)compressed straight from/into the buffer.
    int64_t run_offset;
    if (blocks_in_c_order &&
        chunk_contiguous_in_buffer(array, chunk_start, start, stop, shape, &run_offset)) {
      uint8_t *run = buffer_b + run_offset;
      if (set_slice) {
        rc = compress_update_chunk(array, nchunk, run, data_nbytes, NULL);
        if (rc < 0) {
          goto out;
        }
      }
      else {
        // All threads start writing their blocks at once; with shares
        // below a huge page several of them hit each one
        if (prefault && data_nbytes / dctx->nthreads < (1 << 20) &&
            block_nbytes < (1 << 20)) {
          prefault_range(run, data_nbytes);
        }
        rc = blosc2_schunk_decompress_chunk(array->sc, nchunk, run, data_nbytes);
        if (rc < 0) {
          BLOSC_TRACE_ERROR("Error decompressing chunk");
          goto out;
        }
        if (decoded_nothing(dctx, rc)) {
          memset(run, 0, (size_t)data_nbytes);
        }
        rc = BLOSC2_ERROR_SUCCESS;
      }
      continue;
    }

    // Compact get path state for this chunk (see below).
    bool use_compact = false;
    uint8_t *lazychunk = NULL;
    bool lazychunk_needs_free = false;
    int32_t lazychunk_cbytes = 0;
    if (set_slice) {
      if (data == NULL) {
        data = scratch_malloc(array, data_nbytes, &data_capacity);
        if (data == NULL) {
          rc = BLOSC2_ERROR_MEMORY_ALLOC;
          goto out;
        }
      }
      // Check if all the chunk is going to be updated and avoid the decompression
      bool decompress_chunk = false;
      for (int i = 0; i < ndim; ++i) {
        decompress_chunk |= (chunk_start[i] < start[i] || chunk_stop[i] > stop[i]);
      }

      // On a partly overwritten chunk the gather copies every block that
      // keeps old items once more, so it only pays when the slice covers a
      // good part of the chunk.
      int64_t box_start[B2ND_MAX_DIM];
      int64_t box_stop[B2ND_MAX_DIM];
      int64_t overlap_nitems = chunk_slice_box(ndim, chunk_start, chunk_stop, start, stop,
                                               box_start, box_stop);
      if (can_gather && (!decompress_chunk || 2 * overlap_nitems >= array->extchunknitems)) {
        // Gather path: the compression threads take the new items straight
        // from the buffer.  Only blocks keeping some old items need the old
        // chunk, and when there are none `data` stays untouched.
        if (decompress_chunk) {
          if (block_maskout == NULL) {
            block_maskout = malloc(nblocks);
            if (block_maskout == NULL) {
              rc = BLOSC2_ERROR_MEMORY_ALLOC;
              goto out;
            }
          }
          for (int nblock = 0; nblock < nblocks; ++nblock) {
            block_overlap_t overlap;
            block_maskout[nblock] = block_slice_overlap(&slice_chunk, nblock, &overlap) &&
                                    overlap.whole_block;
          }
          int err = schunk_decompress_masked(array->sc, nchunk, NULL, 0, block_maskout, nblocks,
                                             NULL, NULL, data, data_nbytes);
          if (err < 0) {
            BLOSC_TRACE_ERROR("Error decompressing chunk");
            rc = BLOSC2_ERROR_FAILURE;
            goto out;
          }
          if (decoded_nothing(dctx, err)) {
            memset(data, 0, data_nbytes);
          }
        }
        slice_chunk.keep_old = decompress_chunk;
        rc = compress_update_chunk(array, nchunk, data, data_nbytes, &slice_chunk);
        if (rc < 0) {
          goto out;
        }
        continue;
      }

      if (decompress_chunk) {
        int err = blosc2_schunk_decompress_chunk(array->sc, nchunk, data, data_nbytes);
        if (err < 0) {
          BLOSC_TRACE_ERROR("Error decompressing chunk");
          rc = BLOSC2_ERROR_FAILURE;
          goto out;
        }
        if (decoded_nothing(dctx, err)) {
          memset(data, 0, data_nbytes);
        }
      } else {
        // Avoid writing non zero padding from previous chunk
        memset(data, 0, data_nbytes);
      }
    } else {
      if (block_maskout == NULL) {
        block_maskout = malloc(nblocks);
        if (block_maskout == NULL) {
          rc = BLOSC2_ERROR_MEMORY_ALLOC;
          goto out;
        }
      }
      // Delta filter encodes subsequent blocks relative to the reference block (block 0): if any block in the chunk
      // is needed, block 0 must be decompressed as reference
      int32_t nblocks_needed = (int32_t) slice_chunk_maskout(&slice_chunk, nblocks, has_delta, block_maskout);

      // Compact get path: when only a fraction of the chunk's blocks is
      // needed, decompress just those blocks -- one at a time, straight
      // from the (lazy)chunk -- instead of decompressing into a chunk-sized
      // scratch.  This keeps the working buffer at one block, so small reads
      // from arrays with large chunks stay O(request), not O(chunksize).
      // Larger requests keep the maskout path, which decompresses the needed
      // blocks in parallel.
      //
      // The threshold depends on the storage backend.  On disk, the maskout
      // path reads the *whole* compressed chunk per call while the compact
      // path only reads the touched blocks, so compact wins by 10-100x well
      // past needed == nblocks/4 for typical data.  In memory there is no
      // I/O to save: for poorly-compressible data the maskout path's
      // parallel decompression overtakes the compact path's serial one at
      // around 2-4 needed blocks, so stay conservative there (1/16 keeps
      // the possible loss window narrow while still capturing the common
      // 1-2 block reads, where compact always wins or ties).
      //
      // If DELTA is used, blocks cannot be decompressed independently; keep maskout path.
      use_compact = slice_chunk_compact(array, nblocks_needed, has_delta);
      if (use_compact) {
        lazychunk_cbytes = blosc2_schunk_get_lazychunk(array->sc, nchunk, &lazychunk,
                                                       &lazychunk_needs_free);
        if (lazychunk_cbytes < 0) {
          BLOSC_TRACE_ERROR("Error getting the lazy chunk");
          rc = BLOSC2_ERROR_FAILURE;
          goto out;
        }
        if (block_data == NULL) {
          block_data = scratch_malloc(array, block_nbytes, &block_data_capacity);
          if (block_data == NULL) {
            if (lazychunk_needs_free) {
              free(lazychunk);
            }
            rc = BLOSC2_ERROR_MEMORY_ALLOC;
            goto out;
          }
        }
      } else {
        if (data == NULL) {
          data = scratch_malloc(array, data_nbytes, &data_capacity);
          if (data == NULL) {
            rc = BLOSC2_ERROR_MEMORY_ALLOC;
            goto out;
          }
        }
        bool scattered = false;
        if (can_scatter) {
          // Scatter path: the needed blocks go from the worker threads that
          // decode them straight to the buffer.  `data` only satisfies the
          // decompressor's destination size and stays untouched.
          int64_t box_start[B2ND_MAX_DIM];
          int64_t box_stop[B2ND_MAX_DIM];
          chunk_slice_box(ndim, chunk_start, chunk_stop, start, stop, box_start, box_stop);
          if (prefault) {
            int64_t box_last[B2ND_MAX_DIM];
            for (int i = 0; i < ndim; ++i) {
              box_last[i] = box_stop[i] - 1;
            }
            int64_t first;
            int64_t last;
            blosc2_multidim_to_unidim(box_start, ndim, buffer_strides, &first);
            blosc2_multidim_to_unidim(box_last, ndim, buffer_strides, &last);
            prefault_range(buffer_b + first * array->sc->typesize,
                           (last + 1 - first) * array->sc->typesize);
          }
          int err = schunk_decompress_masked(array->sc, nchunk, NULL, 0, block_maskout, nblocks,
                                             slice_scatter_postfilter, &slice_chunk, data, data_nbytes);
          if (err < 0) {
            BLOSC_TRACE_ERROR("Error decompressing chunk");
            rc = BLOSC2_ERROR_FAILURE;
            goto out;
          }
          if (err == 0) {
            // Missing chunk: nothing was decoded
            b2nd_zero_box(ndim, array->sc->typesize, buffer_b, shape, box_start, box_stop);
          }
          scattered = err == 0 || !scatter_unsupported(dctx);
        }
        if (scattered) {
          continue;
        }
        int err = schunk_decompress_masked(array->sc, nchunk, NULL, 0, block_maskout, nblocks,
                                           NULL, NULL, data, data_nbytes);
        if (err < 0) {
          BLOSC_TRACE_ERROR("Error decompressing chunk");
          rc = BLOSC2_ERROR_FAILURE;
          goto out;
        }
        if (decoded_nothing(dctx, err)) {
          memset(data, 0, data_nbytes);
        }
      }
    }

    // Iterate over blocks

    for (int nblock = 0; nblock < nblocks; ++nblock) {
      block_overlap_t overlap;
      if (!block_slice_overlap(&slice_chunk, nblock, &overlap)) {
        continue;
      }

      uint8_t *dst;
      if (use_compact) {
        // Decompress just this block from the (lazy)chunk.
        int grc = blosc2_getitem_bytes_ctx(array->sc->dctx, lazychunk, lazychunk_cbytes,
                                           (int32_t) ((int64_t) nblock * block_nbytes), block_nbytes,
                                           block_data, block_nbytes);
        if (grc < 0) {
          BLOSC_TRACE_ERROR("Error decompressing block");
          if (lazychunk_needs_free) {
            free(lazychunk);
          }
          rc = BLOSC2_ERROR_FAILURE;
          goto out;
        }
        if (decoded_nothing(dctx, grc)) {
          memset(block_data, 0, block_nbytes);
        }
        dst = block_data;
      } else {
        dst = &data[nblock * array->blocknitems * array->sc->typesize];
      }

      if (set_slice) {
        b2nd_copy_buffer2(ndim, array->sc->typesize,
                          buffer_b, shape, overlap.dst_start, overlap.dst_stop,
                          dst, blockshape, overlap.src_start);
      } else {
        b2nd_copy_buffer2(ndim, array->sc->typesize,
                          dst, blockshape, overlap.src_start, overlap.src_stop,
                          buffer_b, shape, overlap.dst_start);
      }
    }

    if (use_compact && lazychunk_needs_free) {
      free(lazychunk);
    }

    if (set_slice) {
      rc = compress_update_chunk(array, nchunk, data, data_nbytes, NULL);
      if (rc < 0) {
        goto out;
      }
    }
  }

  out:
  free(slice_chunks);
  prefetch_batch_free(own_prefetch);
  blosc2_tmp_free(data, data_capacity);
  blosc2_tmp_free(block_data, block_data_capacity);
  free(block_maskout);

  return rc;
}


// get_set_slice() holding the frame lock (shared to read, exclusive to write)
// from the refresh to the last chunk, so a locked handle works on the chunks
// of the shape it just refreshed to: with a lock per chunk access, a writer
// shrinking the array in between made a read fail ("nchunk exceeds the number
// of chunks").  A write can span several chunks, each updated with its own
// blosc2_schunk_update_chunk() call; under one lock (as b2nd_resize() already
// does for its metalayer+chunks sequence) locked handles -- including plain
// readers -- see the whole slice atomically instead of a chunk-wise interleave
// with other writers (plans/todo-locking-swmr.md item 2 / python-blosc2's
// todo/locking-mwmr.md item 2).  A no-op for unlocked handles, which keep
// SWMR's transient errors.  A write takes the lock through
// frame_begin_updates(): chunks that change size leave holes in a contiguous
// frame while the slice is written, closed in one pass at the end, instead of
// moving the rest of the frame once per chunk.
static int locked_get_set_slice(void *buffer, int64_t buffersize, const int64_t *start,
                                const int64_t *stop, const int64_t *shape, b2nd_array_t *array,
                                bool set_slice, bool slice_only, prefetch_batch *prefetch) {
  blosc2_frame_s *frame = (blosc2_frame_s *) array->sc->frame;
  BLOSC_ERROR(set_slice ? frame_begin_updates(frame) : frame_lock(frame, false));
  int rc = refresh_if_stale(array);
  if (rc >= 0) {
    rc = get_set_slice(buffer, buffersize, start, stop, shape, array, set_slice, slice_only, prefetch);
  }
  if (set_slice) {
    int end_rc = frame_end_updates(frame, array->sc);
    rc = (rc < 0) ? rc : end_rc;
  }
  else {
    frame_unlock(frame);
  }
  BLOSC_ERROR(rc);

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_get_slice_cbuffer(const b2nd_array_t *array, const int64_t *start, const int64_t *stop,
                           void *buffer, const int64_t *buffershape, int64_t buffersize) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(start, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(stop, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffershape, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);

  return locked_get_set_slice(buffer, buffersize, start, stop, buffershape, (b2nd_array_t *) array,
                              false, false, NULL);
}


int b2nd_get_slice_cbuffer_into(const b2nd_array_t *array, const int64_t *start, const int64_t *stop,
                                void *buffer, const int64_t *buffershape, int64_t buffersize) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(start, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(stop, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffershape, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);

  // The slice must lie inside the array (an empty one writes nothing), and
  // its box inside the buffer: the bytes from `buffer` to the slice's last
  // item, with the strides of `buffershape`, must be within `buffersize`.
  // get_set_slice() checks that buffershape holds the slice.
  bool empty = false;
  for (int i = 0; i < array->ndim; ++i) {
    if (start[i] < 0 || stop[i] < start[i] || stop[i] > array->shape[i]) {
      BLOSC_TRACE_ERROR("The slice must lie inside the array");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
    empty |= stop[i] == start[i];
  }
  if (empty) {
    return BLOSC2_ERROR_SUCCESS;
  }
  int64_t last_offset = 0;
  int64_t stride = 1;
  int64_t term;
  for (int i = array->ndim - 1; i >= 0; --i) {
    if (!blosc2_checked_mul_i64_nonneg(stop[i] - start[i] - 1, stride, &term) ||
        !blosc2_checked_add_i64_nonneg(last_offset, term, &last_offset) ||
        (i > 0 && !blosc2_checked_mul_i64_nonneg(stride, buffershape[i], &stride))) {
      BLOSC_TRACE_ERROR("Buffer shape overflows");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
  }
  int64_t needed;
  if (!blosc2_checked_mul_i64_nonneg(last_offset + 1, array->sc->typesize, &needed) || buffersize < needed) {
    BLOSC_TRACE_ERROR("The buffer is too small for the slice");
    return BLOSC2_ERROR_INVALID_PARAM;
  }

  return locked_get_set_slice(buffer, buffersize, start, stop, buffershape, (b2nd_array_t *) array,
                              false, true, NULL);
}


int b2nd_set_slice_cbuffer(const void *buffer, const int64_t *buffershape, int64_t buffersize,
                           const int64_t *start, const int64_t *stop,
                           b2nd_array_t *array) {
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(start, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(stop, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);

  return locked_get_set_slice((void *) buffer, buffersize, start, stop, buffershape, array, true, false, NULL);
}


static int get_slice_chunks(b2nd_context_t *ctx, b2nd_array_t **array, const b2nd_array_t *src,
                            const int64_t *start, prefetch_batch *prefetch);


int b2nd_get_slice(b2nd_context_t *ctx, b2nd_array_t **array, const b2nd_array_t *src, const int64_t *start,
                   const int64_t *stop) {
  BLOSC_ERROR_NULL(src, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(start, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(stop, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale((b2nd_array_t *) src));

  ctx->ndim = src->ndim;
  for (int i = 0; i < src->ndim; ++i) {
    ctx->shape[i] = stop[i] - start[i];
  }

  // Add data
  BLOSC_ERROR(b2nd_empty(ctx, array));

  if ((*array)->nitems == 0) {
    return BLOSC2_ERROR_SUCCESS;
  }

  // Read the chunks of the whole source slice ahead, not only those of one result chunk at a time
  prefetch_batch *prefetch = prefetch_slice(src, start, stop);
  int rc = get_slice_chunks(ctx, array, src, start, prefetch);
  prefetch_batch_free(prefetch);
  return rc;
}


/* Fill the chunks of the result of b2nd_get_slice() one after the other from the source slice.
   The chunk-sized buffer comes from the thread's scratch cache (see blosc2_tmp_malloc()), also
   for an in-memory result: unlike the compression buffers of schunk_scratch_malloc(), it never
   becomes a chunk of the array, and freed per call glibc trims it and faults it in again. */
static int get_slice_chunks(b2nd_context_t *ctx, b2nd_array_t **array, const b2nd_array_t *src,
                            const int64_t *start, prefetch_batch *prefetch) {
  int8_t ndim = (*array)->ndim;
  int64_t chunks_in_array[B2ND_MAX_DIM] = {0};
  for (int i = 0; i < ndim; ++i) {
    chunks_in_array[i] = (*array)->extshape[i] / (*array)->chunkshape[i];
  }
  int64_t nchunks = (*array)->sc->nchunks;
  for (int64_t nchunk = 0; nchunk < nchunks; ++nchunk) {
    int64_t nchunk_ndim[B2ND_MAX_DIM] = {0};
    blosc2_unidim_to_multidim(ndim, chunks_in_array, nchunk, nchunk_ndim);

    // Check if the chunk needs to be updated
    int64_t chunk_start[B2ND_MAX_DIM] = {0};
    int64_t chunk_stop[B2ND_MAX_DIM] = {0};
    int64_t chunk_shape[B2ND_MAX_DIM] = {0};
    for (int i = 0; i < ndim; ++i) {
      chunk_start[i] = nchunk_ndim[i] * (*array)->chunkshape[i];
      chunk_stop[i] = chunk_start[i] + (*array)->chunkshape[i];
      if (chunk_stop[i] > (*array)->shape[i]) {
        chunk_stop[i] = (*array)->shape[i];
      }
      chunk_shape[i] = chunk_stop[i] - chunk_start[i];
    }

    int64_t src_start[B2ND_MAX_DIM] = {0};
    int64_t src_stop[B2ND_MAX_DIM] = {0};
    for (int i = 0; i < ndim; ++i) {
      src_start[i] = chunk_start[i] + start[i];
      src_stop[i] = chunk_stop[i] + start[i];
    }
    if (ctx->b2_storage->cparams->typesize <= 0) {
      BLOSC_TRACE_ERROR("Invalid typesize");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
    size_t buffersize = (size_t)ctx->b2_storage->cparams->typesize;
    for (int i = 0; i < ndim; ++i) {
      if (chunk_shape[i] < 0) {
        BLOSC_TRACE_ERROR("Invalid chunk shape");
        return BLOSC2_ERROR_INVALID_PARAM;
      }
      if (!blosc2_checked_mul_size(buffersize, (size_t)chunk_shape[i], &buffersize)) {
        BLOSC_TRACE_ERROR("Buffer size overflows size limits");
        return BLOSC2_ERROR_INVALID_PARAM;
      }
    }
    if (buffersize == 0 || buffersize > (size_t)INT64_MAX) {
      BLOSC_TRACE_ERROR("Buffer size is out of range");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
    size_t capacity;
    uint8_t *buffer = blosc2_tmp_malloc(buffersize, &capacity);
    if (buffer == NULL) {
      b2nd_free(*array);
      *array = NULL;
      BLOSC_ERROR(BLOSC2_ERROR_MEMORY_ALLOC);
    }
    int g_rc = locked_get_set_slice(buffer, (int64_t) buffersize, src_start, src_stop, chunk_shape,
                                    (b2nd_array_t *) src, false, false, prefetch);
    if (g_rc < 0) {
      blosc2_tmp_free(buffer, capacity);
      b2nd_free(*array);
      *array = NULL;
      return g_rc;
    }
    int s_rc = b2nd_set_slice_cbuffer(buffer, chunk_shape, (int64_t)buffersize, chunk_start,
                                      chunk_stop, *array);
    blosc2_tmp_free(buffer, capacity);
    if (s_rc < 0) {
      b2nd_free(*array);
      *array = NULL;
      return s_rc;
    }
  }

  return BLOSC2_ERROR_SUCCESS;
}

/**
 * @brief Return a view of a b2nd array.
 *
 * @param array The memory pointer of the array which will be viewed.
 * @param view The memory pointer where the view will be created.
 * @param ctx1 The b2nd context for the new array, containing new shape and other metadata.
 *
 * @return An error code.
 *
 * @note This doesn't support slices of arrays and is only useful for adding (or removing) dimensions.
 *
 */
int view_new(const b2nd_array_t *array, b2nd_array_t **view, b2nd_context_t *ctx1) {

  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(view, BLOSC2_ERROR_NULL_POINTER);

  // The view is not contiguous (points to the original contiguous cframe which has different shape)
  // so we set contiguous to false, which forces a copy when calling to_cframe
  ctx1->b2_storage->contiguous = false;


  /* Fill view with zeros */
  BLOSC_ERROR(b2nd_zeros(ctx1, view));
  // Free the chunks in base array
  for (int i = 0; i < (*view)->sc->nchunks; i++) {
    free((*view)->sc->data[i]);
  }
  free((*view)->sc->data);
  (*view)->sc->view = true;
  (*view)->sc->data = array->sc->data; // point view to the same data
  (*view)->sc->frame = array->sc->frame; // if original array is contiguous, point to frame
  (*view)->sc->nvlmetalayers = array->sc->nvlmetalayers; //
  for (int i = 0; i< array->sc->nvlmetalayers; i++) {
    (*view)->sc->vlmetalayers[i] = array->sc->vlmetalayers[i]; // add ptrs to vlmetalayers
  }

  return BLOSC2_ERROR_SUCCESS;
}

int b2nd_expand_dims(const b2nd_array_t *array, b2nd_array_t **view, const bool *axis, const uint8_t final_dims) {
  BLOSC_ERROR(refresh_if_stale((b2nd_array_t *) array));
  for (int i = 0; i < array->sc->nmetalayers; ++i) {
    if (strcmp(array->sc->metalayers[i]->name, "b2nd") != 0) {
      BLOSC_TRACE_ERROR("Cannot expand dimensions of an array with non-b2nd metalayers");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
  }
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(view, BLOSC2_ERROR_NULL_POINTER);

  uint8_t old_idx = 0;
  int64_t newshape[B2ND_MAX_DIM];
  int32_t newchunkshape[B2ND_MAX_DIM];
  int32_t newblockshape[B2ND_MAX_DIM];

  for (int i = 0; i < final_dims; ++i) {
    if (axis[i] == true) {
      newshape[i] = 1;
      newchunkshape[i] = 1;
      newblockshape[i] = 1;
    }
    else {
      if (old_idx == array->ndim) {
        BLOSC_TRACE_ERROR("Error in axis list: original array has fewer dimensions than the axis list implies!");
        return BLOSC2_ERROR_INVALID_PARAM;
      }
      newshape[i] = array->shape[old_idx];
      newchunkshape[i] = array->chunkshape[old_idx];
      newblockshape[i] = array->blockshape[old_idx];
      old_idx++;
    }
  }

  //views only deal with cparams/dparams; storage is always in-memory (ephemeral).
  blosc2_cparams cparams = *(array->sc->storage->cparams);
  blosc2_dparams dparams = *(array->sc->storage->dparams);
  blosc2_storage b2_storage1 = {.cparams=&cparams, .dparams=&dparams};

  b2nd_context_t *ctx1 = b2nd_create_ctx(&b2_storage1, final_dims, newshape,
                                        newchunkshape, newblockshape, array->dtype,
                                        array->dtype_format, NULL, 0);

  view_new(array, view, ctx1);
  b2nd_free_ctx(ctx1);

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_squeeze(b2nd_array_t *array, b2nd_array_t **view) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(view, BLOSC2_ERROR_NULL_POINTER);

  bool index[B2ND_MAX_DIM];

  for (int i = 0; i < array->ndim; ++i) {
    if (array->shape[i] != 1) {
      index[i] = false;
    } else {
      index[i] = true;
    }
  }
  BLOSC_ERROR(b2nd_squeeze_index(array, view, index));

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_squeeze_index(b2nd_array_t *array, b2nd_array_t **view, const bool *index) {
  BLOSC_ERROR(refresh_if_stale(array));
  for (int i = 0; i < array->sc->nmetalayers; ++i) {
    if (strcmp(array->sc->metalayers[i]->name, "b2nd") != 0) {
      BLOSC_TRACE_ERROR("Cannot squeeze dimensions of an array with non-b2nd metalayers");
      return BLOSC2_ERROR_INVALID_PARAM;
    }
  }
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(view, BLOSC2_ERROR_NULL_POINTER);

  uint8_t nones = 0;
  int64_t newshape[B2ND_MAX_DIM];
  int32_t newchunkshape[B2ND_MAX_DIM];
  int32_t newblockshape[B2ND_MAX_DIM];

  for (int i = 0; i < array->ndim; ++i) {
    if (index[i] == true) {
      if (array->shape[i] != 1) {
        BLOSC_ERROR(BLOSC2_ERROR_INVALID_INDEX);
      }
    } else {
      newshape[nones] = array->shape[i];
      newchunkshape[nones] = array->chunkshape[i];
      newblockshape[nones] = array->blockshape[i];
      nones += 1;
    }
  }

  //views only deal with cparams/dparams; storage is always in-memory (ephemeral).
  blosc2_cparams cparams = *(array->sc->storage->cparams);
  blosc2_dparams dparams = *(array->sc->storage->dparams);
  blosc2_storage b2_storage1 = {.cparams=&cparams, .dparams=&dparams};

  b2nd_context_t *ctx1 = b2nd_create_ctx(&b2_storage1, nones, newshape,
                                        newchunkshape, newblockshape, array->dtype,
                                        array->dtype_format, NULL, 0);

  view_new(array, view, ctx1);
  b2nd_free_ctx(ctx1);

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_copy(b2nd_context_t *ctx, const b2nd_array_t *src, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(src, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale((b2nd_array_t *) src));

  ctx->ndim = src->ndim;

  for (int i = 0; i < src->ndim; ++i) {
    ctx->shape[i] = src->shape[i];
  }

  bool equals = true;
  for (int i = 0; i < src->ndim; ++i) {
    if (src->chunkshape[i] != ctx->chunkshape[i]) {
      equals = false;
      break;
    }
    if (src->blockshape[i] != ctx->blockshape[i]) {
      equals = false;
      break;
    }
  }

  if (equals) {
    BLOSC_ERROR(array_without_schunk(ctx, array));

    blosc2_schunk *new_sc = blosc2_schunk_copy(src->sc, ctx->b2_storage);

    if (new_sc == NULL) {
      b2nd_free(*array);
      *array = NULL;
      return BLOSC2_ERROR_FAILURE;
    }
    (*array)->sc = new_sc;

  } else {
    int64_t start[B2ND_MAX_DIM] = {0};

    int64_t stop[B2ND_MAX_DIM];
    for (int i = 0; i < src->ndim; ++i) {
      stop[i] = src->shape[i];
    }
    // Copy metalayers
    b2nd_context_t params_meta;
    memcpy(&params_meta, ctx, sizeof(params_meta));
    int j = 0;

    for (int i = 0; i < src->sc->nmetalayers; ++i) {
      if (strcmp(src->sc->metalayers[i]->name, "b2nd") == 0) {
        continue;
      }
      blosc2_metalayer *meta = &params_meta.metalayers[j];
      meta->name = src->sc->metalayers[i]->name;
      meta->content = src->sc->metalayers[i]->content;
      meta->content_len = src->sc->metalayers[i]->content_len;
      j++;
    }
    params_meta.nmetalayers = j;

    // Copy data
    BLOSC_ERROR(b2nd_get_slice(&params_meta, array, src, start, stop));

    // Copy vlmetalayers, with default cparams like blosc2_schunk_copy(): the
    // filters and codec of the new array are for its chunks, and lossy ones
    // would change the content
    if (schunk_copy_vlmetalayers(src->sc, (*array)->sc, NULL) < 0) {
      b2nd_free(*array);
      *array = NULL;
      BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
    }
  }
  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_concatenate(b2nd_context_t *ctx, const b2nd_array_t *src1, const b2nd_array_t *src2,
                     int8_t axis, bool copy, b2nd_array_t **array) {
  BLOSC_ERROR_NULL(src1, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(src2, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale((b2nd_array_t *) src1));
  BLOSC_ERROR(refresh_if_stale((b2nd_array_t *) src2));

  // Validate the axis parameter
  if (axis < 0 || axis >= src1->ndim) {
    BLOSC_TRACE_ERROR("axis parameter is out of bounds: axis=%d, expected range=[0, %d)", axis, src1->ndim - 1);
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  // typesize must be the same for both arrays
  if (src1->sc->typesize != src2->sc->typesize) {
    BLOSC_TRACE_ERROR("The two arrays must have the same typesize");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  // Keep the src1 shape for later use
  int64_t src1_shape[B2ND_MAX_DIM];
  for (int i = 0; i < src1->ndim; ++i) {
    src1_shape[i] = src1->shape[i];
  }

  // Support for 0-dim arrays is not implemented
  if (src1->ndim == 0 || src2->ndim == 0) {
    BLOSC_TRACE_ERROR("Concatenation of 0-dim arrays is not supported");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  // Check that the shapes are compatible for concatenation
  if (src1->ndim != src2->ndim) {
    BLOSC_TRACE_ERROR("The two arrays must have the same number of dimensions");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }
  // Compute the new shape
  int64_t newshape[B2ND_MAX_DIM];
  for (int8_t i = 0; i < src1->ndim; ++i) {
    if (i == axis) {
      newshape[i] = src1->shape[i] + src2->shape[i];
    } else {
      if (src1->shape[i] != src2->shape[i]) {
        BLOSC_TRACE_ERROR("The two arrays must have the same shape in all dimensions except the concatenation axis");
        BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
      }
      newshape[i] = src1->shape[i];
    }
  }

  if (copy) {
    BLOSC_ERROR(b2nd_copy(ctx, src1, array));
  }
  else {
    *array = (b2nd_array_t *)src1;
  }

  // Extend the array, we don't need to specify the start in resize, as we are extending the shape from the end
  BLOSC_ERROR(b2nd_resize(*array, newshape, NULL));

  // Copy the data from the second array
  int64_t start[B2ND_MAX_DIM];
  int64_t stop[B2ND_MAX_DIM];

  // Check if the chunk is aligned with dest chunks, and has the same blockshape
  bool aligned = true;
  for (int8_t i = 0; i < src2->ndim; ++i) {
    if (src1->chunkshape[i] != src2->chunkshape[i] ||
        src2->blockshape[i] != (*array)->blockshape[i] ||
        (i == axis && (src1_shape[i]) % (*array)->chunkshape[i] != 0)
        ) {
      aligned = false;
      break;
        }
  }
  // ...and get the chunk index in the dest array if aligned
  int64_t chunks_in_array_strides[B2ND_MAX_DIM];
  // Calculate strides for destination array
  chunks_in_array_strides[(*array)->ndim - 1] = 1;
  for (int i = (*array)->ndim - 2; i >= 0; --i) {
    chunks_in_array_strides[i] = chunks_in_array_strides[i + 1] *
                                ((*array)->extshape[i + 1] / (*array)->chunkshape[i + 1]);
  }

  // Copy chunk by chunk
  void *buffer = malloc(src2->sc->typesize * src2->extchunknitems);
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_MEMORY_ALLOC);
  for (int64_t nchunk = 0; nchunk < src2->sc->nchunks; ++nchunk) {
    // Get multidimensional chunk position
    int64_t nchunk_ndim[B2ND_MAX_DIM] = {0};
    int64_t chunkshape[B2ND_MAX_DIM] = {0};
    for (int8_t i = 0; i < src2->ndim; ++i) {
      chunkshape[i] = src2->chunkshape[i];
    }
    int64_t chunks_in_dim[B2ND_MAX_DIM] = {0};
    for (int8_t i = 0; i < src2->ndim; ++i) {
      chunks_in_dim[i] = src2->extshape[i] / src2->chunkshape[i];
    }
    blosc2_unidim_to_multidim(src2->ndim, chunks_in_dim, nchunk, nchunk_ndim);

    if (aligned) {
      // Get the uncompressed chunk buffer from the source array
      bool needs_free = false;
      uint8_t *chunk;
      int32_t cbytes = blosc2_schunk_get_chunk(src2->sc, nchunk, &chunk, &needs_free);
      if (cbytes < 0) {
        BLOSC_TRACE_ERROR("Error getting chunk from source array");
        BLOSC_ERROR(BLOSC2_ERROR_FAILURE);
      }
      // Update the chunk in the destination array
      // We need to free only if needs_free is true or copy is false
      // bool needs_copy = !needs_free || copy;
      // BLOSC_ERROR(blosc2_schunk_update_chunk((*array)->sc, nchunk_dest, chunk, needs_copy));
      // if (needs_free && !copy) {
      //   free(chunk);
      // }
      // TODO: the above makes some tests to crash, so always force a copy; try to optimize this later
      int64_t nchunk_dest = 0;
      nchunk_ndim[axis] += src1_shape[axis] / (*array)->chunkshape[axis];
      for ( int i =0; i< src2->ndim; i++) {
        nchunk_dest += nchunk_ndim[i] * chunks_in_array_strides[i];
      }
      int64_t urc = blosc2_schunk_update_chunk((*array)->sc, nchunk_dest, chunk, true);
      if (needs_free) {
        free(chunk);
      }
      BLOSC_ERROR(urc);
    }
    else {

      // Set positions for each dimension
      for (int8_t i = 0; i < src2->ndim; ++i) {
        start[i] = nchunk_ndim[i] * src2->chunkshape[i];
        stop[i] = start[i] + src2->chunkshape[i];
        if (stop[i] > src2->shape[i]) {
          stop[i] = src2->shape[i];  // Handle boundary chunks
        }
      }
      // Load chunk into buffer
      BLOSC_ERROR(b2nd_get_slice_cbuffer(src2, start, stop, buffer, chunkshape, src2->sc->chunksize));

      // Apply chunk offset only for concatenation axis
      start[axis] += src1_shape[axis];
      stop[axis] += src1_shape[axis];

      // Copy the chunk to the correct position
      BLOSC_ERROR(b2nd_set_slice_cbuffer(buffer, chunkshape,
                                         src2->sc->typesize * src2->extchunknitems,
                                         start, stop, *array));
    }
  }

  free(buffer);

  return BLOSC2_ERROR_SUCCESS;
}

int b2nd_save(const b2nd_array_t *array, char *urlpath) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(urlpath, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale((b2nd_array_t *) array));

  // The chunks as stored, like b2nd_to_cframe() and b2nd_save_append() (unlike
  // b2nd_copy(), which applies a postfilter), in the layout of the array
  blosc2_storage b2_storage = BLOSC2_STORAGE_DEFAULTS;
  b2_storage.urlpath = urlpath;
  b2_storage.contiguous = array->sc->storage->contiguous;
  blosc2_schunk *sc = schunk_copy_as_stored(array->sc, &b2_storage);
  if (sc == NULL) {
    BLOSC_TRACE_ERROR("Error saving the b2nd array");
    return BLOSC2_ERROR_FAILURE;
  }
  blosc2_schunk_free(sc);

  return BLOSC2_ERROR_SUCCESS;
}

int64_t b2nd_save_append(const b2nd_array_t *array, const char *urlpath) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  return blosc2_schunk_append_file(array->sc, urlpath);
}

int b2nd_print_meta(const b2nd_array_t *array) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  int8_t ndim;
  int64_t shape[B2ND_MAX_DIM];
  int32_t chunkshape[B2ND_MAX_DIM];
  int32_t blockshape[B2ND_MAX_DIM];
  char *dtype;
  int8_t dtype_format;
  uint8_t *smeta;
  int32_t smeta_len;
  if (blosc2_meta_get(array->sc, "b2nd", &smeta, &smeta_len) < 0) {
    // Try with a caterva metalayer; we are meant to be backward compatible with it
    if (blosc2_meta_get(array->sc, "caterva", &smeta, &smeta_len) < 0) {
      BLOSC_ERROR(BLOSC2_ERROR_METALAYER_NOT_FOUND);
    }
  }
  int rc = b2nd_deserialize_meta(smeta, smeta_len, &ndim, shape, chunkshape, blockshape,
                                 &dtype, &dtype_format);
  free(smeta);
  BLOSC_ERROR(rc);

  printf("b2nd metalayer parameters:\n Ndim:       %d", ndim);
  printf("\n shape:      %" PRId64 "", shape[0]);
  for (int i = 1; i < ndim; ++i) {
    printf(", %" PRId64 "", shape[i]);
  }
  printf("\n chunkshape: %d", chunkshape[0]);
  for (int i = 1; i < ndim; ++i) {
    printf(", %d", chunkshape[i]);
  }
  if (dtype != NULL) {
    printf("\n dtype: %s", dtype);
    free(dtype);
  }

  printf("\n blockshape: %d", blockshape[0]);
  for (int i = 1; i < ndim; ++i) {
    printf(", %d", blockshape[i]);
  }
  printf("\n");

  return BLOSC2_ERROR_SUCCESS;
}


int extend_shape(b2nd_array_t *array, const int64_t *new_shape, const int64_t *start) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(new_shape, BLOSC2_ERROR_NULL_POINTER);

  int8_t ndim = array->ndim;
  int64_t diffs_shape[B2ND_MAX_DIM];
  int64_t diffs_sum = 0;
  for (int i = 0; i < ndim; i++) {
    diffs_shape[i] = new_shape[i] - array->shape[i];
    diffs_sum += diffs_shape[i];
    if (diffs_shape[i] < 0) {
      BLOSC_TRACE_ERROR("The new shape must be greater than the old one");
      BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
    }
    if (array->shape[i] == INT64_MAX) {
      BLOSC_TRACE_ERROR("Cannot extend array with shape[%d] = %" PRId64, i, (int64_t)INT64_MAX);
      BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
    }
  }
  if (diffs_sum == 0) {
    // Shapes are equal. Do nothing.
    return BLOSC2_ERROR_SUCCESS;
  }

  int64_t old_nchunks = array->sc->nchunks;
  // aux array to keep old shapes
  b2nd_array_t *aux = malloc(sizeof(b2nd_array_t));
  BLOSC_ERROR_NULL(aux, BLOSC2_ERROR_MEMORY_ALLOC);
  aux->sc = NULL;
  BLOSC_ERROR(update_shape(aux, ndim, array->shape, array->chunkshape, array->blockshape));

  // SWMR ordering for growth: make the data (special chunks) exist first and
  // publish the new shape in the metalayer last, so a concurrent reader never
  // sees a shape that points at chunks that are not there yet.
  BLOSC_ERROR(update_shape_struct(array, ndim, new_shape, array->chunkshape, array->blockshape));

  int64_t nchunks = array->extnitems / array->chunknitems;
  int64_t nchunks_;
  int64_t nchunk_ndim[B2ND_MAX_DIM];
  blosc2_cparams *cparams;
  BLOSC_ERROR(blosc2_schunk_get_cparams(array->sc, &cparams));
  void *chunk;
  int64_t csize;
  if (nchunks != old_nchunks) {
    if (start == NULL) {
      start = aux->shape;
    }
    int64_t chunks_in_array[B2ND_MAX_DIM] = {0};
    for (int i = 0; i < ndim; ++i) {
      chunks_in_array[i] = array->extshape[i] / array->chunkshape[i];
    }
    for (int64_t i = 0; i < nchunks; ++i) {
      blosc2_unidim_to_multidim(ndim, chunks_in_array, i, nchunk_ndim);
      for (int j = 0; j < ndim; ++j) {
        if (start[j] <= (array->chunkshape[j] * nchunk_ndim[j])
            && (array->chunkshape[j] * nchunk_ndim[j]) < (start[j] + new_shape[j] - aux->shape[j])) {
          chunk = malloc(BLOSC_EXTENDED_HEADER_LENGTH);
          BLOSC_ERROR_NULL(chunk, BLOSC2_ERROR_MEMORY_ALLOC);
          csize = blosc2_chunk_zeros(*cparams, array->sc->chunksize, chunk, BLOSC_EXTENDED_HEADER_LENGTH);
          if (csize < 0) {
            free(aux);
            free(cparams);
            BLOSC_TRACE_ERROR("Blosc error when creating a chunk");
            return BLOSC2_ERROR_FAILURE;
          }
          nchunks_ = blosc2_schunk_insert_chunk(array->sc, i, chunk, false);
          if (nchunks_ < 0) {
            // A failed insert leaves the chunk to us
            free(chunk);
            free(aux);
            free(cparams);
            BLOSC_TRACE_ERROR("Blosc error when inserting a chunk");
            return BLOSC2_ERROR_FAILURE;
          }
          break;
        }
      }
    }
  }
  free(aux);
  free(cparams);

  // Data is in place; now publish the grown shape (shape last, see above)
  BLOSC_ERROR(publish_shape_meta(array));

  return BLOSC2_ERROR_SUCCESS;
}


int shrink_shape(b2nd_array_t *array, const int64_t *new_shape, const int64_t *start) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(new_shape, BLOSC2_ERROR_NULL_POINTER);

  int8_t ndim = array->ndim;
  int64_t diffs_shape[B2ND_MAX_DIM];
  int64_t diffs_sum = 0;
  for (int i = 0; i < ndim; i++) {
    diffs_shape[i] = new_shape[i] - array->shape[i];
    diffs_sum += diffs_shape[i];
    if (diffs_shape[i] > 0) {
      BLOSC_TRACE_ERROR("The new shape must be smaller than the old one");
      BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
    }
    if (array->shape[i] == 0) {
      continue;
    }
  }
  if (diffs_sum == 0) {
    // Shapes are equal. Do nothing.
    return BLOSC2_ERROR_SUCCESS;
  }

  int64_t old_nchunks = array->sc->nchunks;
  // aux array to keep old shapes
  b2nd_array_t *aux = malloc(sizeof(b2nd_array_t));
  BLOSC_ERROR_NULL(aux, BLOSC2_ERROR_MEMORY_ALLOC);
  aux->sc = NULL;
  BLOSC_ERROR(update_shape(aux, ndim, array->shape, array->chunkshape, array->blockshape));

  BLOSC_ERROR(update_shape(array, ndim, new_shape, array->chunkshape, array->blockshape));

  // Delete chunks if needed
  int64_t chunks_in_array_old[B2ND_MAX_DIM] = {0};
  for (int i = 0; i < ndim; ++i) {
    chunks_in_array_old[i] = aux->extshape[i] / aux->chunkshape[i];
  }
  if (start == NULL) {
    start = new_shape;
  }

  int64_t nchunk_ndim[B2ND_MAX_DIM] = {0};
  int64_t nchunks_;
  for (int i = (int) old_nchunks - 1; i >= 0; --i) {
    blosc2_unidim_to_multidim(ndim, chunks_in_array_old, i, nchunk_ndim);
    for (int j = 0; j < ndim; ++j) {
      if (start[j] <= (array->chunkshape[j] * nchunk_ndim[j])
          && (array->chunkshape[j] * nchunk_ndim[j]) < (start[j] + aux->shape[j] - new_shape[j])) {
        nchunks_ = blosc2_schunk_delete_chunk(array->sc, i);
        if (nchunks_ < 0) {
          free(aux);
          BLOSC_TRACE_ERROR("Blosc error when deleting a chunk");
          return BLOSC2_ERROR_FAILURE;
        }
        break;
      }
    }
  }
  free(aux);

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_resize(b2nd_array_t *array, const int64_t *new_shape,
                const int64_t *start) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(new_shape, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale(array));

  for (int i = 0; i < array->ndim; ++i) {
    if (new_shape[i] < 0) {
      BLOSC_TRACE_ERROR("`new_shape` cannot have negative entries");
      BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
    }
    if (new_shape[i] != array->shape[i] && (array->chunkshape[i] <= 0 || array->chunknitems <= 0)) {
      BLOSC_TRACE_ERROR("Cannot resize array with zero chunkshape");
      BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
    }
  }

  if (start != NULL) {
    for (int i = 0; i < array->ndim; ++i) {
      if (start[i] < 0 || start[i] > array->shape[i]) {
        BLOSC_TRACE_ERROR("`start` must be in [0, shape] in all dims");
        BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
      }
      if ((new_shape[i] > array->shape[i] && start[i] != array->shape[i])
          || (new_shape[i] < array->shape[i]
              && (start[i] + array->shape[i] - new_shape[i]) != array->shape[i])) {
        // Chunks cannot be cut unless they are in the last position
        if (array->chunkshape[i] <= 0 || start[i] % array->chunkshape[i] != 0) {
          BLOSC_TRACE_ERROR("If array end is not being modified "
                              "`start` must be a multiple of chunkshape in all dims");
          BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
        }
        if ((new_shape[i] - array->shape[i]) % array->chunkshape[i] != 0) {
          BLOSC_TRACE_ERROR("If array end is not being modified "
                              "`(new_shape - shape)` must be multiple of chunkshape in all dims");
          BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
        }
      }
    }
  }

  // Get shrunk shape
  int64_t shrunk_shape[B2ND_MAX_DIM] = {0};
  for (int i = 0; i < array->ndim; ++i) {
    if (new_shape[i] <= array->shape[i]) {
      shrunk_shape[i] = new_shape[i];
    } else {
      shrunk_shape[i] = array->shape[i];
    }
  }

  // A resize is a sequence (metalayer update + chunk inserts/deletes); hold
  // the exclusive frame lock across it so locked handles see it atomically.
  // For unlocked handles this is a no-op and the data-first/shape-last
  // ordering in extend_shape/shrink_shape keeps readers safe.  The updated
  // boundary chunks leave holes until the end (see locked_get_set_slice()).
  blosc2_frame_s *frame = (blosc2_frame_s *) array->sc->frame;
  BLOSC_ERROR(frame_begin_updates(frame));
  int rc = shrink_shape(array, shrunk_shape, start);
  if (rc >= 0) {
    rc = extend_shape(array, new_shape, start);
  }
  int end_rc = frame_end_updates(frame, array->sc);
  BLOSC_ERROR(rc);
  BLOSC_ERROR(end_rc);

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_insert(b2nd_array_t *array, const void *buffer, int64_t buffersize,
                int8_t axis, int64_t insert_start) {

  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale(array));

  if (axis < 0 || axis >= array->ndim) {
    BLOSC_TRACE_ERROR("`axis` must be in [0, ndim)");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }
  if (insert_start < 0 || insert_start > array->shape[axis] || buffersize < 0) {
    BLOSC_TRACE_ERROR("`insert_start` must be in [0, shape[axis]] and `buffersize` non-negative");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  int64_t axis_size = array->sc->typesize;
  int64_t buffershape[B2ND_MAX_DIM];
  for (int i = 0; i < array->ndim; ++i) {
    if (i != axis) {
      axis_size *= array->shape[i];
      buffershape[i] = array->shape[i];
    }
  }
  if (axis_size <= 0 || buffersize % axis_size != 0) {
    BLOSC_TRACE_ERROR("`buffersize` must be multiple of the array cross-section");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }
  int64_t newshape[B2ND_MAX_DIM];
  memcpy(newshape, array->shape, array->ndim * sizeof(int64_t));
  newshape[axis] += buffersize / axis_size;
  buffershape[axis] = newshape[axis] - array->shape[axis];
  int64_t start[B2ND_MAX_DIM] = {0};
  start[axis] = insert_start;

  if (insert_start == array->shape[axis]) {
    BLOSC_ERROR(b2nd_resize(array, newshape, NULL));
  } else {
    BLOSC_ERROR(b2nd_resize(array, newshape, start));
  }

  int64_t stop[B2ND_MAX_DIM];
  memcpy(stop, array->shape, sizeof(int64_t) * array->ndim);
  stop[axis] = start[axis] + buffershape[axis];
  BLOSC_ERROR(b2nd_set_slice_cbuffer(buffer, buffershape, buffersize, start, stop, array));

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_append(b2nd_array_t *array, const void *buffer, int64_t buffersize,
                int8_t axis) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffer, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale(array));

  if (axis < 0 || axis >= array->ndim || buffersize < 0) {
    BLOSC_TRACE_ERROR("`axis` must be in [0, ndim) and `buffersize` non-negative");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  int32_t chunksize = array->sc->chunksize;
  if (chunksize <= 0) {
    BLOSC_TRACE_ERROR("Cannot append to array with non-positive chunksize");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }
  int64_t nchunks_append = buffersize / chunksize;
  // Check whether chunkshape and blockshape are compatible with accelerated path.
  // Essentially, we are checking whether the buffer is a multiple of the chunksize
  // and that the chunkshape and blockshape are the same, except for the first axis.
  // Also, axis needs to be the first one.
  bool compat_chunks_blocks = true;
  for (int i = 1; i < array->ndim; ++i) {
    if (array->chunkshape[i] != array->blockshape[i]) {
      compat_chunks_blocks = false;
      break;
    }
  }
  if (axis > 0) {
    compat_chunks_blocks = false;
  }
  // General case where a buffer has a different size than the chunksize
  if (!compat_chunks_blocks || buffersize % chunksize != 0 || nchunks_append != 1) {
    BLOSC_ERROR(b2nd_insert(array, buffer, buffersize, axis, array->shape[axis]));
    return BLOSC2_ERROR_SUCCESS;
  }

  // Accelerated path for buffers that are of the same size as the chunksize
  // printf("accelerated path\n");

  // Append the buffer to the underlying schunk. This is very fast, as
  // it doesn't need to do internal partitioning.
  BLOSC_ERROR(blosc2_schunk_append_buffer(array->sc, (void*)buffer, buffersize));

  // Finally, resize the array
  int64_t newshape[B2ND_MAX_DIM];
  memcpy(newshape, array->shape, array->ndim * sizeof(int64_t));
  newshape[axis] += nchunks_append * array->chunkshape[axis];
  BLOSC_ERROR(b2nd_resize(array, newshape, NULL));

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_delete(b2nd_array_t *array, const int8_t axis,
                int64_t delete_start, int64_t delete_len) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale(array));

  if (axis < 0 || axis >= array->ndim) {
    BLOSC_TRACE_ERROR("axis must be in [0, ndim)");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }
  if (delete_start < 0 || delete_len < 0 || delete_len > array->shape[axis] ||
      delete_start > array->shape[axis] - delete_len) {
    BLOSC_TRACE_ERROR("Invalid delete range");
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }


  int64_t newshape[B2ND_MAX_DIM];
  memcpy(newshape, array->shape, array->ndim * sizeof(int64_t));
  newshape[axis] -= delete_len;
  int64_t start[B2ND_MAX_DIM] = {0};
  start[axis] = delete_start;

  if (delete_start == (array->shape[axis] - delete_len)) {
    BLOSC_ERROR(b2nd_resize(array, newshape, NULL));
  } else {
    BLOSC_ERROR(b2nd_resize(array, newshape, start));
  }

  return BLOSC2_ERROR_SUCCESS;
}

// Indexing

typedef struct {
    int64_t value;
    int64_t index;
} b2nd_selection_t;


int compare_selection(const void *a, const void *b) {
  int res = (int) (((b2nd_selection_t *) a)->value - ((b2nd_selection_t *) b)->value);
  // In case values are equal, sort by index
  if (res == 0) {
    res = (int) (((b2nd_selection_t *) a)->index - ((b2nd_selection_t *) b)->index);
  }
  return res;
}


// The dimension whose consecutive selected items copy_block_buffer_data() batches into one memcpy() for a block:
// the innermost one, or further out where the dimensions inside it merge into it.  A dimension merges into the one
// outside it when the block's selection in it is the block's whole extent in order, at consecutive buffer positions
// that fill the buffer's extent too: then its items follow on contiguously in both the block and the buffer (e.g.
// the channels of a channels-last image, which then merge with the pixels of a block row).
static int8_t block_selection_batch_dim(const b2nd_array_t *array, const int64_t *buffershape,
                                        const int64_t *block_selection_size, b2nd_selection_t **block_selection) {
  for (int8_t dim = (int8_t) (array->ndim - 1); dim > 0; --dim) {
    int64_t n = block_selection_size[dim];
    if (n != array->blockshape[dim] || n != buffershape[dim]) {
      return dim;
    }
    const b2nd_selection_t *sel = block_selection[dim];
    for (int64_t j = 1; j < n; ++j) {
      if (sel[j].value != sel[j - 1].value + 1 || sel[j].index != sel[j - 1].index + 1) {
        return dim;
      }
    }
  }
  return 0;
}


int copy_block_buffer_data(b2nd_array_t *array,
                           int8_t ndim,
                           int8_t batch_dim,
                           int64_t *block_selection_size,
                           b2nd_selection_t **chunk_selection,
                           b2nd_selection_t **p_block_selection_0,
                           b2nd_selection_t **p_block_selection_1,
                           uint8_t *block,
                           uint8_t *buffer,
                           int64_t *buffershape,
                           int64_t *bufferstrides,
                           bool get) {
  p_block_selection_0[ndim] = chunk_selection[ndim];
  p_block_selection_1[ndim] = chunk_selection[ndim];
  while (p_block_selection_1[ndim] - p_block_selection_0[ndim] < block_selection_size[ndim]) {
    if (ndim == batch_dim) {
      // --- leaf: batch consecutive elements of batch_dim, each with the dimensions merged into it (see
      // block_selection_batch_dim()), into one memcpy() ---

      // The merged dimensions start where the block's selection starts.
      for (int i = ndim + 1; i < array->ndim; ++i) {
        p_block_selection_1[i] = chunk_selection[i];
      }
      int32_t typesize = array->sc->typesize;
      // Bytes of one element of batch_dim with the dimensions merged into it
      size_t batch_nbytes = (size_t) (array->item_block_strides[ndim] * typesize);
      b2nd_selection_t *first = p_block_selection_1[ndim];
      b2nd_selection_t *end = p_block_selection_0[ndim] + block_selection_size[ndim];
      while (first < end) {
        // Extend the batch while the next element is adjacent to the previous one in both the block buffer (value)
        // and the output buffer (index).
        b2nd_selection_t *last = first + 1;
        while (last < end && last->value == last[-1].value + 1 && last->index == last[-1].index + 1) {
          last++;
        }

        // Start positions of the batch; outer dimensions keep using their current recursive selection pointers.
        p_block_selection_1[ndim] = first;
        int64_t start_block = 0;
        int64_t start_buffer = 0;
        for (int i = 0; i < array->ndim; ++i) {
          start_block += p_block_selection_1[i]->value % array->chunkshape[i] % array->blockshape[i] *
                         array->item_block_strides[i];
          start_buffer += p_block_selection_1[i]->index * bufferstrides[i];
        }
        size_t nbytes = (size_t) (last - first) * batch_nbytes;
        if (get) {
          memcpy(&buffer[start_buffer * typesize], &block[start_block * typesize], nbytes);
        } else {
          memcpy(&block[start_block * typesize], &buffer[start_buffer * typesize], nbytes);
        }
        first = last;
      }
      p_block_selection_1[ndim] = end;
    } else {
      BLOSC_ERROR(copy_block_buffer_data(array, (int8_t) (ndim + 1), batch_dim, block_selection_size,
                                         chunk_selection,
                                         p_block_selection_0, p_block_selection_1, block,
                                         buffer, buffershape, bufferstrides, get)
      );
      p_block_selection_1[ndim]++;
    }
  }
  return BLOSC2_ERROR_SUCCESS;
}


int iter_block_copy(b2nd_array_t *array, int8_t ndim,
                    int64_t *chunk_selection_size,
                    b2nd_selection_t **ordered_selection,
                    b2nd_selection_t **chunk_selection_0,
                    b2nd_selection_t **chunk_selection_1,
                    uint8_t *data,
                    uint8_t *buffer,
                    int64_t *buffershape,
                    int64_t *bufferstrides,
                    bool get) {
  chunk_selection_0[ndim] = ordered_selection[ndim];
  chunk_selection_1[ndim] = ordered_selection[ndim];
  while (chunk_selection_1[ndim] - ordered_selection[ndim] < chunk_selection_size[ndim]) {
    int64_t block_index_ndim = ((*chunk_selection_1[ndim]).value % array->chunkshape[ndim]) / array->blockshape[ndim];
    while (chunk_selection_1[ndim] - ordered_selection[ndim] < chunk_selection_size[ndim] &&
           block_index_ndim == ((*chunk_selection_1[ndim]).value % array->chunkshape[ndim]) / array->blockshape[ndim]) {
      chunk_selection_1[ndim]++;
    }
    if (ndim == array->ndim - 1) {
      int64_t block_chunk_strides[B2ND_MAX_DIM];
      block_chunk_strides[array->ndim - 1] = 1;
      for (int i = array->ndim - 2; i >= 0; --i) {
        block_chunk_strides[i] = block_chunk_strides[i + 1] * (array->extchunkshape[i + 1] / array->blockshape[i + 1]);
      }
      int64_t block_index[B2ND_MAX_DIM];
      for (int i = 0; i < array->ndim; ++i) {
        block_index[i] = ((*chunk_selection_0[i]).value % array->chunkshape[i]) / array->blockshape[i];
      }
      int64_t nblock = 0;
      for (int i = 0; i < array->ndim; ++i) {
        nblock += block_index[i] * block_chunk_strides[i];
      }
      b2nd_selection_t **p_block_selection_0 = malloc(array->ndim * sizeof(b2nd_selection_t *));
      BLOSC_ERROR_NULL(p_block_selection_0, BLOSC2_ERROR_MEMORY_ALLOC);
      b2nd_selection_t **p_block_selection_1 = malloc(array->ndim * sizeof(b2nd_selection_t *));
      BLOSC_ERROR_NULL(p_block_selection_1, BLOSC2_ERROR_MEMORY_ALLOC);
      int64_t *block_selection_size = malloc(array->ndim * sizeof(int64_t));
      BLOSC_ERROR_NULL(block_selection_size, BLOSC2_ERROR_MEMORY_ALLOC);
      for (int i = 0; i < array->ndim; ++i) {
        block_selection_size[i] = chunk_selection_1[i] - chunk_selection_0[i];
      }

      int8_t batch_dim = block_selection_batch_dim(array, buffershape, block_selection_size, chunk_selection_0);
      BLOSC_ERROR(copy_block_buffer_data(array,
                                         (int8_t) 0,
                                         batch_dim,
                                         block_selection_size,
                                         chunk_selection_0,
                                         p_block_selection_0,
                                         p_block_selection_1,
                                         &data[nblock * array->blocknitems * array->sc->typesize],
                                         buffer,
                                         buffershape,
                                         bufferstrides,
                                         get)
      );
      free(p_block_selection_0);
      free(p_block_selection_1);
      free(block_selection_size);
    } else {
      BLOSC_ERROR(iter_block_copy(array, (int8_t) (ndim + 1), chunk_selection_size,
                                  ordered_selection, chunk_selection_0, chunk_selection_1,
                                  data, buffer, buffershape, bufferstrides, get)
      );
    }
    chunk_selection_0[ndim] = chunk_selection_1[ndim];

  }

  return BLOSC2_ERROR_SUCCESS;
}


int iter_block_maskout(b2nd_array_t *array, int8_t ndim,
                       int64_t *sel_block_size,
                       b2nd_selection_t **o_selection,
                       b2nd_selection_t **p_o_sel_block_0,
                       b2nd_selection_t **p_o_sel_block_1,
                       bool *maskout) {
  p_o_sel_block_0[ndim] = o_selection[ndim];
  p_o_sel_block_1[ndim] = o_selection[ndim];
  while (p_o_sel_block_1[ndim] - o_selection[ndim] < sel_block_size[ndim]) {
    int64_t block_index_ndim = ((*p_o_sel_block_1[ndim]).value % array->chunkshape[ndim]) / array->blockshape[ndim];
    while (p_o_sel_block_1[ndim] - o_selection[ndim] < sel_block_size[ndim] &&
           block_index_ndim == ((*p_o_sel_block_1[ndim]).value % array->chunkshape[ndim]) / array->blockshape[ndim]) {
      p_o_sel_block_1[ndim]++;
    }
    if (ndim == array->ndim - 1) {
      int64_t block_chunk_strides[B2ND_MAX_DIM];
      block_chunk_strides[array->ndim - 1] = 1;
      for (int i = array->ndim - 2; i >= 0; --i) {
        block_chunk_strides[i] = block_chunk_strides[i + 1] * (array->extchunkshape[i + 1] / array->blockshape[i + 1]);
      }
      int64_t block_index[B2ND_MAX_DIM];
      for (int i = 0; i < array->ndim; ++i) {
        block_index[i] = ((*p_o_sel_block_0[i]).value % array->chunkshape[i]) / array->blockshape[i];
      }
      int64_t nblock = 0;
      for (int i = 0; i < array->ndim; ++i) {
        nblock += block_index[i] * block_chunk_strides[i];
      }
      maskout[nblock] = false;
    } else {
      BLOSC_ERROR(iter_block_maskout(array, (int8_t) (ndim + 1), sel_block_size,
                                     o_selection, p_o_sel_block_0, p_o_sel_block_1,
                                     maskout)
      );
    }
    p_o_sel_block_0[ndim] = p_o_sel_block_1[ndim];

  }

  return BLOSC2_ERROR_SUCCESS;
}


int iter_chunk(b2nd_array_t *array, int8_t ndim,
               int64_t *selection_size,
               b2nd_selection_t **ordered_selection,
               b2nd_selection_t **p_ordered_selection_0,
               b2nd_selection_t **p_ordered_selection_1,
               uint8_t *buffer,
               int64_t *buffershape,
               int64_t *bufferstrides,
               bool get,
               uint8_t *chunk_data,
               int32_t chunk_data_nbytes,
               prefetch_batch *prefetch) {
  p_ordered_selection_0[ndim] = ordered_selection[ndim];
  p_ordered_selection_1[ndim] = ordered_selection[ndim];
  while (p_ordered_selection_1[ndim] - ordered_selection[ndim] < selection_size[ndim]) {
    int64_t chunk_index_ndim = (*p_ordered_selection_1[ndim]).value / array->chunkshape[ndim];
    while (p_ordered_selection_1[ndim] - ordered_selection[ndim] < selection_size[ndim] &&
           chunk_index_ndim == (*p_ordered_selection_1[ndim]).value / array->chunkshape[ndim]) {
      p_ordered_selection_1[ndim]++;
    }
    if (ndim == array->ndim - 1) {
      int64_t chunk_array_strides[B2ND_MAX_DIM];
      chunk_array_strides[array->ndim - 1] = 1;
      for (int i = array->ndim - 2; i >= 0; --i) {
        chunk_array_strides[i] = chunk_array_strides[i + 1] *
                                 (array->extshape[i + 1] / array->chunkshape[i + 1]);
      }
      int64_t chunk_index[B2ND_MAX_DIM];
      for (int i = 0; i < array->ndim; ++i) {
        chunk_index[i] = (*p_ordered_selection_0[i]).value / array->chunkshape[i];
      }
      int64_t nchunk = 0;
      for (int i = 0; i < array->ndim; ++i) {
        nchunk += chunk_index[i] * chunk_array_strides[i];
      }

      int64_t nblocks = array->extchunknitems / array->blocknitems;
      b2nd_selection_t **p_chunk_selection_0 = malloc(array->ndim * sizeof(b2nd_selection_t *));
      b2nd_selection_t **p_chunk_selection_1 = malloc(array->ndim * sizeof(b2nd_selection_t *));
      int64_t *chunk_selection_size = malloc(array->ndim * sizeof(int64_t));
      bool *maskout = NULL;
      int data_nbytes = chunk_data_nbytes;
      uint8_t *data = chunk_data;
      int rc = BLOSC2_ERROR_SUCCESS;
      if (p_chunk_selection_0 == NULL || p_chunk_selection_1 == NULL || chunk_selection_size == NULL) {
        rc = BLOSC2_ERROR_MEMORY_ALLOC;
        goto chunk_done;
      }
      for (int i = 0; i < array->ndim; ++i) {
        chunk_selection_size[i] = p_ordered_selection_1[i] - p_ordered_selection_0[i];
      }

      if (get) {
        maskout = malloc(nblocks);
        if (maskout == NULL) {
          rc = BLOSC2_ERROR_MEMORY_ALLOC;
          goto chunk_done;
        }
        for (int i = 0; i < nblocks; ++i) {
          maskout[i] = true;
        }

        rc = iter_block_maskout(array, (int8_t) 0,
                                chunk_selection_size,
                                p_ordered_selection_0,
                                p_chunk_selection_0,
                                p_chunk_selection_1,
                                maskout);
        if (rc < 0) {
          goto chunk_done;
        }

        if (blosc2_set_maskout(array->sc->dctx, maskout, (int) nblocks) !=
            BLOSC2_ERROR_SUCCESS) {
          BLOSC_TRACE_ERROR("Error setting the maskout");
          rc = BLOSC2_ERROR_FAILURE;
          goto chunk_done;
        }
      }
      prefetch_batch_wait(prefetch, nchunk);
      if (blosc2_schunk_decompress_chunk(array->sc, nchunk, data, data_nbytes) < 0) {
        BLOSC_TRACE_ERROR("Error decompressing chunk");
        // A read that failed before decompressing leaves the mask on the context
        ctx_clear_maskout(array->sc->dctx);
        rc = BLOSC2_ERROR_FAILURE;
        goto chunk_done;
      }
      rc = iter_block_copy(array, 0, chunk_selection_size,
                           p_ordered_selection_0, p_chunk_selection_0, p_chunk_selection_1,
                           data, buffer, buffershape, bufferstrides, get);
      if (rc < 0) {
        goto chunk_done;
      }

      if (!get) {
        if (blosc2_schunk_update_buffer(array->sc, nchunk, data, data_nbytes) < 0) {
          BLOSC_TRACE_ERROR("Error compressing and updating chunk");
          rc = BLOSC2_ERROR_FAILURE;
          goto chunk_done;
        }
      }

      chunk_done:
      free(maskout);
      free(chunk_selection_size);
      free(p_chunk_selection_0);
      free(p_chunk_selection_1);
      BLOSC_ERROR(rc);
    } else {
      BLOSC_ERROR(iter_chunk(array, (int8_t) (ndim + 1), selection_size,
                             ordered_selection, p_ordered_selection_0, p_ordered_selection_1,
                             buffer, buffershape, bufferstrides, get, chunk_data, chunk_data_nbytes,
                             prefetch));
    }

    p_ordered_selection_0[ndim] = p_ordered_selection_1[ndim];
  }
  return BLOSC2_ERROR_SUCCESS;
}


/* Start reading the chunks an orthogonal selection touches ahead (see blosc2_set_prefetch()), in the order iter_chunk()
   visits them: per axis the chunks of the sorted selection, combined in C order.  NULL if read-ahead is off or does
   not apply. */
static prefetch_batch* prefetch_selection(const b2nd_array_t *array, b2nd_selection_t **ordered_selection,
                                          const int64_t *selection_size) {
  if (!prefetch_applies((blosc2_frame_s *) array->sc->frame) || array->nitems == 0) {  // empty: chunk shape has a 0
    return NULL;
  }
  int8_t ndim = array->ndim;
  int64_t *axis_chunks[B2ND_MAX_DIM] = {NULL};
  int64_t naxis_chunks[B2ND_MAX_DIM] = {0};
  int64_t strides[B2ND_MAX_DIM];
  int64_t n = 1;
  int64_t *nchunks = NULL;
  prefetch_batch *batch = NULL;
  for (int i = ndim - 1; i >= 0; --i) {
    strides[i] = i == ndim - 1 ? 1 : strides[i + 1] * (array->extshape[i + 1] / array->chunkshape[i + 1]);
  }
  for (int i = 0; i < ndim; ++i) {
    axis_chunks[i] = malloc((selection_size[i] > 0 ? selection_size[i] : 1) * sizeof(int64_t));
    if (axis_chunks[i] == NULL) {
      goto out;
    }
    for (int64_t j = 0; j < selection_size[i]; ++j) {
      int64_t value = ordered_selection[i][j].value;
      int64_t c = value / array->chunkshape[i];
      if (naxis_chunks[i] == 0 || axis_chunks[i][naxis_chunks[i] - 1] != c) {
        axis_chunks[i][naxis_chunks[i]++] = c;
      }
    }
    if (!blosc2_checked_mul_i64_nonneg(n, naxis_chunks[i], &n) ||
        (uint64_t) n > SIZE_MAX / sizeof(int64_t)) {
      goto out;  // read-ahead is optional; never wrap its chunk-list allocation
    }
  }
  nchunks = n > 0 ? malloc(n * sizeof(int64_t)) : NULL;
  if (nchunks != NULL) {
    int64_t index[B2ND_MAX_DIM] = {0};
    for (int64_t k = 0; k < n; ++k) {
      nchunks[k] = 0;
      for (int i = 0; i < ndim; ++i) {
        nchunks[k] += axis_chunks[i][index[i]] * strides[i];
      }
      for (int i = ndim - 1; i >= 0 && ++index[i] == naxis_chunks[i]; --i) {
        index[i] = 0;
      }
    }
    batch = prefetch_batch_new((blosc2_frame_s *) array->sc->frame, nchunks, n, NULL, 0);
  }

  out:
  free(nchunks);
  for (int i = 0; i < ndim; ++i) {
    free(axis_chunks[i]);
  }
  return batch;
}


/* Strides of the C-order buffer that an orthogonal selection is copied to or from, after checking that
   the buffer holds the selection: no axis of buffershape smaller than the selection's, and buffersize
   reaching the selection's last item.  A larger buffer is fine (the items go to the first
   selection_size[i] positions of each axis); an empty selection needs none. */
static int check_selection_buffer_strides(int8_t ndim, int32_t typesize, const int64_t *selection_size,
                                          const int64_t *buffershape, int64_t buffersize, void *buffer,
                                          int64_t *bufferstrides, bool *empty_out) {
  bool empty = false;
  int64_t last = 0;  // buffer offset of the selection's last item
  int64_t stride = 1;
  for (int i = ndim - 1; i >= 0; --i) {
    if (selection_size[i] < 0 || buffershape[i] < selection_size[i]) {
      BLOSC_TRACE_ERROR("Selection size %" PRId64 " of axis %d is negative or larger than the buffer shape %" PRId64,
                        selection_size[i], i, buffershape[i]);
      BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
    }
    bufferstrides[i] = stride;
    if (!blosc2_checked_mul_i64_nonneg(stride, buffershape[i], &stride)) {
      BLOSC_TRACE_ERROR("Buffer shape overflows");
      BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
    }
    // selection_size[i] <= buffershape[i], so last stays below stride: no overflow
    if (selection_size[i] == 0) {
      empty = true;
    } else {
      last += (selection_size[i] - 1) * bufferstrides[i];
    }
  }
  if (!empty && buffer == NULL) {
    BLOSC_TRACE_ERROR("Buffer cannot be NULL for a non-empty selection");
    BLOSC_ERROR(BLOSC2_ERROR_NULL_POINTER);
  }
  int64_t needed;
  if (!empty && (!blosc2_checked_mul_i64_nonneg(last + 1, typesize, &needed) || buffersize < needed)) {
    BLOSC_TRACE_ERROR("A buffer of %" PRId64 " bytes is too small for the selection", buffersize);
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }
  if (empty_out != NULL) {
    *empty_out = empty;
  }
  return BLOSC2_ERROR_SUCCESS;
}


int orthogonal_selection(b2nd_array_t *array, int64_t **selection, int64_t *selection_size, void *buffer,
                         int64_t *buffershape, int64_t buffersize, bool get) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(selection, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(selection_size, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR_NULL(buffershape, BLOSC2_ERROR_NULL_POINTER);
  BLOSC_ERROR(refresh_if_stale(array));

  int8_t ndim = array->ndim;

  for (int i = 0; i < ndim; ++i) {
    BLOSC_ERROR_NULL(selection[i], BLOSC2_ERROR_NULL_POINTER);
    // Validate allocation counts before reading any selection entries.  Both
    // ordered_selection and prefetch's axis_chunks use these counts.
    if (selection_size[i] < 0 ||
        (uint64_t) selection_size[i] > SIZE_MAX / sizeof(b2nd_selection_t) ||
        (uint64_t) selection_size[i] > SIZE_MAX / sizeof(int64_t)) {
      BLOSC_TRACE_ERROR("Selection metadata size overflows");
      BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
    }
  }
  for (int i = 0; i < ndim; ++i) {
    // Only [0, shape): negative indexes address memory outside the chunk buffer and the block mask
    for (int64_t j = 0; j < selection_size[i]; ++j) {
      if (selection[i][j] < 0 || selection[i][j] >= array->shape[i]) {
        BLOSC_TRACE_ERROR("Index %" PRId64 " is out of bounds for axis %d with size %" PRId64,
                          selection[i][j], i, array->shape[i]);
        BLOSC_ERROR(BLOSC2_ERROR_INVALID_INDEX);
      }
    }
  }

  bool empty = false;
  int64_t bufferstrides[B2ND_MAX_DIM];
  BLOSC_ERROR(check_selection_buffer_strides(ndim, array->sc->typesize, selection_size, buffershape, buffersize,
                                             buffer, bufferstrides, &empty));
  if (empty) {
    return BLOSC2_ERROR_SUCCESS;
  }

  // Size of the reusable chunk buffer allocated further down.  Computed here,
  // before any allocation, so the error path has nothing to unwind: the cast
  // used to truncate an int64 product into the malloc size while the copy
  // offsets kept using the full extent (see #795).
  int64_t chunk_data_nbytes_64 = 0;
  if (!blosc2_checked_mul_i64_nonneg(array->extchunknitems, array->sc->typesize, &chunk_data_nbytes_64) ||
      chunk_data_nbytes_64 > INT32_MAX) {
    BLOSC_TRACE_ERROR("Chunk buffer size overflows the maximum of %d bytes", INT32_MAX);
    BLOSC_ERROR(BLOSC2_ERROR_INVALID_PARAM);
  }

  // Sort selections
  int rc = BLOSC2_ERROR_SUCCESS;
  prefetch_batch *prefetch = NULL;
  b2nd_selection_t **ordered_selection = calloc(ndim, sizeof(b2nd_selection_t *));
  // Pointers to iterate over ordered_selection data
  b2nd_selection_t **p_ordered_selection_0 = malloc(ndim * sizeof(b2nd_selection_t *));
  b2nd_selection_t **p_ordered_selection_1 = malloc(ndim * sizeof(b2nd_selection_t *));
  // A single chunk decompression buffer, reused for every chunk visited by
  // iter_chunk, instead of malloc/free per chunk.
  int32_t chunk_data_nbytes = (int32_t) chunk_data_nbytes_64;
  uint8_t *chunk_data = malloc(chunk_data_nbytes);
  if (ordered_selection == NULL || p_ordered_selection_0 == NULL || p_ordered_selection_1 == NULL ||
      chunk_data == NULL) {
    rc = BLOSC2_ERROR_MEMORY_ALLOC;
    goto out;
  }
  for (int i = 0; i < ndim; ++i) {
    ordered_selection[i] = malloc(selection_size[i] * sizeof(b2nd_selection_t));
    if (ordered_selection[i] == NULL && selection_size[i] > 0) {
      rc = BLOSC2_ERROR_MEMORY_ALLOC;
      goto out;
    }
    for (int64_t j = 0; j < selection_size[i]; ++j) {
      ordered_selection[i][j].index = j;
      ordered_selection[i][j].value = selection[i][j];
    }
    qsort(ordered_selection[i], selection_size[i], sizeof(b2nd_selection_t), compare_selection);
  }

  prefetch = get ? prefetch_selection(array, ordered_selection, selection_size) : NULL;
  rc = iter_chunk(array, 0,
                  selection_size, ordered_selection,
                  p_ordered_selection_0,
                  p_ordered_selection_1,
                  buffer, buffershape, bufferstrides, get,
                  chunk_data, chunk_data_nbytes, prefetch);

  out:
  prefetch_batch_free(prefetch);
  free(chunk_data);
  free(p_ordered_selection_0);
  free(p_ordered_selection_1);
  if (ordered_selection != NULL) {
    for (int i = 0; i < ndim; ++i) {
      free(ordered_selection[i]);
    }
  }
  free(ordered_selection);
  BLOSC_ERROR(rc);

  return BLOSC2_ERROR_SUCCESS;
}


int b2nd_get_orthogonal_selection(const b2nd_array_t *array, int64_t **selection, int64_t *selection_size, void *buffer,
                                  int64_t *buffershape, int64_t buffersize) {
  return orthogonal_selection((b2nd_array_t *)array, selection, selection_size, buffer, buffershape, buffersize, true);
}


int b2nd_set_orthogonal_selection(b2nd_array_t *array, int64_t **selection, int64_t *selection_size, const void *buffer,
                                  int64_t *buffershape, int64_t buffersize) {
  BLOSC_ERROR_NULL(array, BLOSC2_ERROR_NULL_POINTER);
  // One exclusive lock and one compaction for all the chunks written (see locked_get_set_slice())
  blosc2_frame_s *frame = (blosc2_frame_s *) array->sc->frame;
  BLOSC_ERROR(frame_begin_updates(frame));
  int rc = orthogonal_selection(array, selection, selection_size, (void*)buffer, buffershape, buffersize, false);
  int end_rc = frame_end_updates(frame, array->sc);
  BLOSC_ERROR(rc);
  BLOSC_ERROR(end_rc);

  return BLOSC2_ERROR_SUCCESS;
}


b2nd_context_t *
b2nd_create_ctx(const blosc2_storage *b2_storage, int8_t ndim, const int64_t *shape, const int32_t *chunkshape,
                const int32_t *blockshape, const char *dtype, int8_t dtype_format, const blosc2_metalayer *metalayers,
                int32_t nmetalayers) {
  if (ndim < 0 || ndim > B2ND_MAX_DIM) {
    BLOSC_TRACE_ERROR("ndim must be in [0, %d]", B2ND_MAX_DIM);
    return NULL;
  }

  if (ndim > 0) {
    if (shape == NULL || chunkshape == NULL || blockshape == NULL) {
      BLOSC_TRACE_ERROR("shape, chunkshape and blockshape cannot be NULL when ndim > 0");
      return NULL;
    }
    if (validate_shape_chunkshape_blockshape(ndim, shape, chunkshape, blockshape) < 0) {
      return NULL;
    }
  }

  b2nd_context_t *ctx = malloc(sizeof(b2nd_context_t));
  BLOSC_ERROR_NULL(ctx, NULL);
  blosc2_storage *params_b2_storage = malloc(sizeof(blosc2_storage));
  BLOSC_ERROR_NULL(params_b2_storage, NULL);
  if (b2_storage == NULL) {
    memcpy(params_b2_storage, &BLOSC2_STORAGE_DEFAULTS, sizeof(blosc2_storage));
  }
  else {
    memcpy(params_b2_storage, b2_storage, sizeof(blosc2_storage));
  }
  blosc2_cparams *cparams = malloc(sizeof(blosc2_cparams));
  BLOSC_ERROR_NULL(cparams, NULL);
  // We need a copy of cparams mainly to be able to modify blocksize
  if (params_b2_storage->cparams == NULL) {
    memcpy(cparams, &BLOSC2_CPARAMS_DEFAULTS, sizeof(blosc2_cparams));
  }
  else {
    memcpy(cparams, params_b2_storage->cparams, sizeof(blosc2_cparams));
  }

  if (dtype == NULL) {
    // ctx->dtype = strdup(B2ND_DEFAULT_DTYPE);
    char buf[16] = {0};
    snprintf(buf, sizeof(buf), "|S%d", cparams->typesize);
    ctx->dtype = strdup(buf);
  }
  else {
    ctx->dtype = strdup(dtype);
  }
  ctx->dtype_format = dtype_format;

  params_b2_storage->cparams = cparams;
  ctx->b2_storage = params_b2_storage;
  ctx->ndim = ndim;
  int32_t blocknitems = 1;
  bool blocksize_overflow = false;
  for (int i = 0; i < ndim; i++) {
    ctx->shape[i] = shape[i];
    ctx->chunkshape[i] = chunkshape[i];
    ctx->blockshape[i] = blockshape[i];
    if (!blosc2_checked_mul_i32_nonneg(blocknitems, ctx->blockshape[i], &blocknitems)) {
      blocksize_overflow = true;
      break;
    }
  }
  // update_shape_struct() rejects this too, but only once an array is built out
  // of the context; catching it here keeps cparams->blocksize from wrapping
  if (blocksize_overflow ||
      !blosc2_checked_mul_i32_nonneg(blocknitems, cparams->typesize, &cparams->blocksize)) {
    BLOSC_TRACE_ERROR("blockshape product overflows the maximum blocksize");
    free(ctx->dtype);
    free(cparams);
    free(params_b2_storage);
    free(ctx);
    return NULL;
  }

  ctx->nmetalayers = nmetalayers;
  for (int i = 0; i < nmetalayers; ++i) {
    ctx->metalayers[i] = metalayers[i];
  }

#if defined(HAVE_ZFP)
  #include "blosc2/codecs-registry.h"
  if ((ctx->b2_storage->cparams->compcode >= BLOSC_CODEC_ZFP_FIXED_ACCURACY) &&
      (ctx->b2_storage->cparams->compcode <= BLOSC_CODEC_ZFP_FIXED_RATE)) {
    for (int i = 0; i < BLOSC2_MAX_FILTERS; ++i) {
      if ((ctx->b2_storage->cparams->filters[i] == BLOSC_SHUFFLE) ||
          (ctx->b2_storage->cparams->filters[i] == BLOSC_BITSHUFFLE)) {
        BLOSC_TRACE_ERROR("ZFP cannot be run in presence of SHUFFLE / BITSHUFFLE");
        return NULL;
      }
    }
  }
#endif /* HAVE_ZFP */

  return ctx;
}


int b2nd_free_ctx(b2nd_context_t *ctx) {
  ctx->b2_storage->cparams->schunk = NULL;
  free(ctx->b2_storage->cparams);
  free(ctx->b2_storage);
  free(ctx->dtype);
  free(ctx);

  return BLOSC2_ERROR_SUCCESS;
}
